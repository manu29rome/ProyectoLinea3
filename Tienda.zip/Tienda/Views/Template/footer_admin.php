 <!-- Essential javascripts for application to work-->
 <script>
 const base_url="<?php base_url();?>";
 </script>   
 <script src="Assets/js/jquery-3.3.1.min.js"></script>
    <script src="Assets/js/popper.min.js"></script>
    <script src="Assets/js/bootstrap.min.js"></script>
    <script src="Assets/js/main.js"></script>
    <script src="Assets/js/function_admin.js"></script>
    <script src="Assets/js/plugins/pace.min.js"></script>
    <script type="text/javascript" src="Assets/js/plugins/sweetalert.min.js"></script>
    <script type="text/javascript" src="Assets/js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="Assets/js/plugins/dataTables.bootstrap.min.js"></script>
    <script src="Assets/js/<?php echo $data['page_functions_js']?>"></script>
    


  </body>
</html>