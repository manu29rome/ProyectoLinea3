<div class="modal" id="modalpago" tabindex="-1" style="margin-top: 8%;">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header d" style="background-color: black; color: white;">
        <h5 class="modal-title">Numero de Pedido: </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          Recializa el pago por medio de los siguientes medios de pago. Enviando como asunto el numero de pedido que aparece en la parte superior. <br>
          <br><a><img style="height: 80px"src="Assets/Images/davi.jpg"><samp style="color: #cc0033;">[DAVIPLATA]&nbsp;</samp> N: 3164777658</a><BR>
          <a><img style="height: 80px"src="Assets/Images/NEQU.png"><samp style="color:#990099;">[NEQUI]&nbsp;  </samp> N: 3164777658</a>
          <br>
           <div class="flex-w flex-t p-t-27 p-b-33" >
							<div class="size-208">
								<span class="mtext-101 cl2">
									Total $:
								</span>
							</div>
                                                    <div class="size-209">
								<span class="mtext-110 cl2">
									 <?php echo $data['total'] ?>
								</span>
							</div>
						</div>
      </div>
      <div class="modal-footer">
        <a class="btn btn-danger" href="#" data-dismiss="modal"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancelar</a>&nbsp;&nbsp;&nbsp;
        <button type="button" onclick="comprar()" class="btn btn-primary"><i class="fa fa-fw fa-lg fa-check-circle"></i>Pago Efectuado</button>
      </div>
    </div>
  </div>
</div>

     