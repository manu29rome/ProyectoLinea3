<!-- Modal -->

<div class="modal fade" id="modalFormRolPermisos"  tabindex="-1" role="dialog"  aria-hidden="true">
 
    <div class="modal-dialog modal-dialog-centered"   role="document">
    <div class="modal-content " >
      <div class="modal-header headerResgister " >
         
        <h5 class="modal-title" id="titleModal">Permisos Rol</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="x">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <form name="formRolPermisos" id="formper">
              <input type="hidden" id="idRol2" name="idRol2" value="">
              <input type="hidden" id="boton" name="boton" value="">
               <div class="col-md-14">
          <div class="">
            <div class="tile-body">
              <div class="table-responsive">
                <table  class="table table-hover table-bordered tabla" id="tableRolPermisos" >
                  <thead>
                    <tr>
                      <th>Opciones</th>
                      <th>Ver</th>
                      <th>Editar</th>
                      <th>Eliminar</th>
                      <th>Añadir</th>
                    </tr>
                  </thead>
                  <tbody>
                   
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
              
              
                  <div class="tile-footer">
                      <button id="btnActionFormper" onclick="Cerrar()" class="btn btn-primary Actualizar" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i><span id="btnText">Listo</span></button>
              
            </div>
              </form>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>