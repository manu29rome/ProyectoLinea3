<!-- Modal -->
<div class="modal fade bd-example-modal-lg" id="modalFormsubCategorias" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog modal-lg " role="document">
    <div class="modal-content ">
      <div class="modal-header headerResgister ">
         
        <h5 class="modal-title " id="titleModal">Nuevo Subcategoria</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="x">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
          <form name="formsubCategorias" id="formsubCategorias">
              <input type="hidden" id="idsubCa" name="subidCa" value="">
              <input type="hidden" id="subidCama" name="subidCama" value="">
              <input type="hidden" id="subfoto" name="subfoto" value="">
               <input type="hidden" id="nom" name="nom" value="0">
               <input type="hidden" id="nom1" name="nom1" value="0">
              <label class="control-label">Los campos con (<label style="color: red">*</label>) son obligatorios</label>
              <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                  <label class="control-label">Nombre <label style="color: red">*</label></label>
                  <input class="form-control" id="subtxtNombreca" name="subtxtNombreca" type="text" placeholder="Nombre de la subcategoria" >
                </div>
                
                <div class="form-group">
                  <label class="control-label">Descripcion <label style="color: red">*</label></label>
                  <textarea class="form-control" id="subtxtDescripcionca" name="subtxtDescripcionca" rows="2" placeholder="Descripcion de la subcategoria" ></textarea>
                </div>
                  <div class="form-group">
                    <label for="exampleSelect1">Estado <label style="color: red">*</label></label>
                    <select class="form-control" id="sublistStatusca" name="sublistStatusca" >
                        <option value="1">Activo</option>
                        <option value="2">Inactivo</option>
                    </select>
                  </div>
                  <div class="form-group" >
                  <label for="Listsubca">Categoria <label style="color: red">*</label></label><br>
                  <?php echo$data['select']?> ?>
                  <select  class="form-control " id="Listsubca" name="Listsubca" > 
                  </select>
                  </div>
                  </div>
                  
                  <div class="col-md-6">
                      <div id="boton">
                      
                  </div>
                      <div class="imag" style="  text-align: center; padding: 5px;"> 
                  </div>
                     <div class="ima" style=" text-align: center; padding: 5px;">    
                  </div>
                      
              <input class="form-control" id="subimagenca"  style="display: none; " name="subimagenca" type="file" placeholder="brr" >
              <br>  
                  </div>
                  
              </div>
                  
                   
                 
                  
                 
              
              
                  <div class="tile-footer">
                      <button id="btnActionForm" class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i><span id="btnText">Guardar</span></button>
              &nbsp;&nbsp;&nbsp;<a class="btn btn-danger" href="#" data-dismiss="modal"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancelar</a>
            </div>
              </form>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>