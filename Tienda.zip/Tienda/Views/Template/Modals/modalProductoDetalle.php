<!-- Modal1 -->
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<div class="wrap-modal1 js-modal1 p-t-60 p-b-20" >
		<div class="overlay-modal1 js-hide-modal1 "></div>
		<div class="container " >
                    <form action="" method="POST" id="producto">
			<div class="bg0 p-t-60 p-b-30 p-lr-15-lg how-pos3-parent modal-dialog modal-lg">
                            <button type="button" class="how-pos3 hov3 trans-04 js-hide-modal1" style="color:#6633ff">
					<img src="Assets/tienda/images/icons/icon-close.png" alt="CLOSE">
				</button>

				<div class="row">
					<div class="col-md-6 col-lg-7 p-b-30">
						<div class="p-l-25 p-r-30 p-lr-0-lg">
                                                    <input type="hidden" id="idpro" name="idpro" value="">
							<div class="wrap-slick3 flex-sb flex-w" id="imagenes">
                                                            <div class="wrap-slick3-dots"> </div>
                                                            
                                                            <div class="wrap-slick3-arrows flex-sb-m flex-w" id="boton"> </div>

                                                                <div class="slick3 gallery-lb" >


								</div>
							</div>
						</div>
					</div>
					
					<div class="col-md-6 col-lg-5 p-b-30">
						<div class="p-r-50 p-t-5 p-lr-0-lg">
                                                    <h4 class="mtext-105 cl2 js-name-detail p-b-14" >
                                                            <div id="titulo">
                                                                
                                                            </div>
								
							</h4>
                                                        
							<span class="mtext-106 cl2" id="precio">
								
							</span>

                                                    <p class="stext-102 cl3 p-t-23 " id="detalle">
								
							</p>
                                                        <br>
                                                        <div class="mtext-106 cl2" id="cantidad">
								
							</div>
							<!--  -->
							<div class="p-t-33">
								
								<div class="flex-w flex-r-m p-b-10">
									<div class="size-204 flex-w flex-m respon6-next" >
										<div class="wrap-num-product flex-w m-r-20 m-tb-10">
											<div class="btn-num-product-down cl8 hov-btn3 trans-04 flex-c-m">
												<i class="fs-16 zmdi zmdi-minus"></i>
											</div>

                                                                                    <input class="mtext-104 cl3 txt-center num-product"  type="number" name="num-product" id="num-product" value="1">

											<div class="btn-num-product-up cl8 hov-btn3 trans-04 flex-c-m">
												<i class="fs-16 zmdi zmdi-plus"></i>
											</div>
										</div>

                                                                            <button type="button" class="flex-c-m stext-101 cl0 size-101 bg1 bor1 hov-btn1 p-lr-15 trans-04 " onclick="carri();">
											Añadir_<i class="zmdi zmdi-shopping-cart"></i>
										</button>
                                                                                                                                        
                         
									</div>
								</div>	

							<!--  -->
							
						</div>
					</div>
				</div>
			</div>
		</div>
                        </form>
	</div>
								</div>
<script src="Assets/js/detalle.js"></script>
	
		
	