<!-- Modal -->
<div class="modal fade" id="modalFormUsuarioVer" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content ">
        <div class="modal-header headerResgister btn-success " style="background: #00cc33">
         
        <h5 class="modal-title" id="titleModal">Informacion de Usuario</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="x">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <form name="formUsuario" id="formUsuario" class="form-horizontal">
              <input type="hidden" id="idUsuario1" name="idUsuario" value="">
              <input type="hidden" id="rol1" name="rol1" value="">
               
              
                  
                      <label for="txtIdentificacion"style="width: 30%">Identificacion:</label>
                      <input type="text" class="" id="txtIdentificacion1" name="txtIdentificacion" disabled=»disabled» style="border: white; width: 60%;">
                  <br>
                  
                  
                      <label for="txtNombre"style="width: 30%">Nombre:</label>
                      <input type="text" class="" id="txtNombre1" name="txtNombre" disabled=»disabled» style="border: white; width: 60%;" >
                  <br>
                      <label for="txtApellido"style="width: 30%">Apellido:</label>
                      <input type="text" class="" id="txtApellido1" name="txtApellido" disabled=»disabled» style="border: white; width: 60%;" >
                  <br>
                  
             

              
                      <label for="txtTelefono"style="width: 30%">Telefono:</label>
                      <input type="text" class="" id="txtTelefono1" name="txtTelefono" disabled=»disabled» style="border: white; width: 60%;">
                  <br>
                      <label for="txtEmail"style="width: 30%">Email:</label>
                      <input type="text" class="" id="txtEmail1" name="txtEmail" disabled=»disabled» style="border: white; width: 60%;" >
                  <br>
             
              
                  
                  <label for="ListRolid"style="width: 30%">Rol usuario:</label>
                   <input type="text" class="" id="ListRolid1" name="ListRolid1" disabled=»disabled» style="border: white; width: 60%;" >
                  <br>
                  <label for="txtStatus"style="width: 30%;">Status:</label>
                   <input type="text" class="" id="ListStatus1" name="ListStatus1" disabled=»disabled» style="border: white; width: 60%;" >
                  <br>

              
                  
                      <label for="txtPassword" style="width: 30%;"  >Password:</label>
                      <input type="text" class="" id="txtPassword1" name="txtPassword" disabled=»disabled» style="border: white; width: 60%;" >
                   <br>
                  <br>

              
             
                  <div class="tile-footer">
              
              <button id="btnActionForm" class="btn " style="background: #00cc33; color: white;" type="button" data-dismiss="modal"><i class="fa fa-fw fa-lg fa-check-circle"></i><span id="btnText">Cerrar</span></button>

            </div>
              </form>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>