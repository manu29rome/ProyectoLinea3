<!-- Modal -->

<div class="modal fade" id="modalFormUsuario" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header headerResgister ">
         
        <h5 class="modal-title" id="titleModal">Nuevo Usuario</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="x">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <form name="formUsuario" id="formUsuario" class="form-horizontal">
              <input type="hidden" id="idUsuario" name="idUsuario" value="">
              <p class="text-primary">Todos los campos son obligatorios</p>
               
              <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="txtIdentificacion">Nº Identificacion (CC-TI-OTRO)</label>
                      <input type="text" class="form-control" onkeypress="return solonumeros(event)" id="txtIdentificacion" name="txtIdentificacion" >
                  </div>
                  </div>

                  <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="txtNombre">Primer Nombre</label><br>
                      <input type="text" class="form-control" onkeypress="return sololetras(event)" id="txtNombre" name="txtNombre" >
                  </div>
                  <div class="form-group col-md-6">
                      <label for="txtApellido">Primer Apellido</label><br>
                      <input type="text" class="form-control" onkeypress="return sololetras(event)" id="txtApellido" name="txtApellido" >
                  </div>
                  </div>
             

              <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="txtTelefono">Telefono</label><br>
                      <input type="text" class="form-control" onkeypress="return solonumeros(event)" id="txtTelefono" name="txtTelefono" >
                  </div>
                  <div class="form-group col-md-6">
                      <label for="txtEmail">Email</label><br>
                      <input type="text" class="form-control" id="txtEmail" name="txtEmail" >
                  </div>
              </div>
             
              <div class="form-row">
                  <div class="form-group col-md-6" id="lista">
                  <label for="ListRolid">Rol Usuario</label><br>
                  <?php echo$data['select']?> ?>
                  <select  class="form-control listro" id="ListRolid" name="ListRolid" > 
                  </select>
                  </div>
                  <div class="form-group col-md-6">
                  <label for="txtStatus">Status</label><br>
                  <select  class="form-control" id="ListStatus" name="ListStatus" >
                      <option value="1">Activo</option>
                      <option value="2">Inactivo</option>
                  </select>
                  </div>
              </div>

              <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="txtPassword">Contraseña</label><br>
                      <input type="password" class="form-control" maxlength="10" minlength="8" id="txtPassword" name="txtPassword" >
                      <span style="font-size: 11px;">(Caracteres minimos 8 y maximos 10.)</span>
                  </div>
             </div>
              

              
             
                  <div class="tile-footer">
                      <button id="btnActionForm" class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i><span id="btnText">Guardar</span></button>
              &nbsp;&nbsp;&nbsp;
              
              <button id="btnActionForm" class="btn btn-danger" type="button" data-dismiss="modal"><i class="fa fa-fw fa-lg fa-check-circle"></i><span id="btnText">Cerrar</span></button>

            </div>
              </form>
            </div>
          </div>
      </div>
    </div>
  