<!-- Modal -->
<!-- Include stylesheet -->
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<div class="modal fade bd-example-modal-lg" id="modalFormProductos" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog modal-lg " role="document">
    <div class="modal-content ">
      <div class="modal-header headerResgister ">
         
        <h5 class="modal-title " id="titleModal">Nuevo Producto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="x">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
          <form name="formsProductos" id="formsProductos">
              <input type="hidden" id="idsubCa" name="subidCa" value="">
              <input type="hidden" id="subidCama" name="subidCama" value="">
              <input type="hidden" id="subfoto" name="subfoto" value="">
              <input type="hidden" id="edito" name="edito" value="">
              <input type="hidden" id="codg" name="codg" value="">
              <input type="hidden" id="in" name="in" value="">
              <input type="hidden" id="imagen1" name="imagen1" value="0" >
              <input type="hidden" id="imagen2" name="imagen2" value="0">
              <input type="hidden" id="imagen3" name="imagen3" value="0">
              <input type="hidden" id="nom" name="nom" value="0">
               <input type="hidden" id="nom1" name="nom1" value="0">
               <input type="hidden" id="nom2" name="nom2" value="0">
               <input type="hidden" id="nom3" name="nom3" value="0">
               <input type="hidden" id="nom4" name="nom4" value="0">
               <input type="hidden" id="nom5" name="nom5" value="0">
              <label class="control-label">Los campos con (<label style="color: red">*</label>) son obligatorios</label>
              <div class="row">
                  <div class="col-md-8">
                    <div class="form-group">
                  <label class="control-label">Nombre <label style="color: red">*</label></label>
                  <input class="form-control" id="subtxtNombreca" name="subtxtNombreca" type="text" placeholder="Nombre del Producto" >
                </div>
                
                <div class="form-group">
                    <label class="control-label" id="edi">Descripcion <label style="color: red">*</label></label>
                  <div id="editor" style="height: 161px">
                     
               
                
                  </div>
                  <script type="text/javascript" src="Assets/js/quills.js"></script>
                  <!-- Initialize Quill editor -->
                <script>
                var id = document.querySelector('#idsubCa').value;
                var quill = new Quill('#editor', {theme: 'snow' });
                function eliminar(){
                 var azul = quill.container.firstChild.innerHTML;
                 quill.setContents([]);
                 }  
                 function mostrar(a){
                  quill.container.firstChild.innerHTML = a;    
                 }
                 function guardar(){
                  var azul = quill.container.firstChild.innerHTML;
                  document.querySelector('#edito').value = azul; 
                  var red = document.querySelector('#edito').value;
                
                 }
                </script>
                </div>
                  <div class="form-group" >
                  <label for="Listsubca">SubCategoria <label style="color: red">*</label></label><br>
                  <?php echo$data['select']?> 
                  <select  class="form-control " id="Listsubca" name="Listsubca" > 
                  </select>
                  </div> 
                      
                      </div>
                  
                  
                  <div class="col-md-4">
                 
                 <script type="text/javascript" src="Assets/js/Codigobarras.js"></script>
                 <div class="form-group">
                  <label class="control-label">Codigo de 5 numeros<label style="color: red">*</label></label>
                  <div style="display: flex;" >
                      <input class="form-control" id="txtCodigo" placeholder="Codigo" lang="5" name="txtCodigo"  onkeypress="return solonumeros(event)" maxlength="5" minlength="5" name="txtCodigo" type="text" placeholder="" >
                      <input type="button" onclick="vercodigo()"  value="Ver" class="btn badge-info">
                    </div>
                  

                   </div>
                 
                 <div class="codigo"id="codigoBarras">
                
                 </div>
                 
                 
                 <br>
                      <div class="row"> 
                      <div class="col-md-6">
                  <label class="control-label">Precio <label style="color: red">*</label></label>
                  <input class="form-control" id="txtPrecio" placeholder="Precio" onkeypress="return solonumeros(event)" name="txtprecio" type="text" placeholder="" >
                  </div>
                  <div class="col-md-6">
                  <label class="control-label">Stock <label style="color: red">*</label></label>
                  <input class="form-control" id="txtStock" placeholder="Cantidad" onkeypress="return solonumeros(event)" name="txtStock" type="text" placeholder="" >
                  </div>
                      </div>    <br>
                     
                     
                      
                      <div class="form-group">
                    <label for="exampleSelect1">Estado <label style="color: red">*</label></label>
                    <select class="form-control" id="sublistStatusca" name="sublistStatusca" >
                        <option value="1">Activo</option>
                        <option value="2">Inactivo</option>
                    </select>
                  </div>
                  </div>
                  
                  <div class="form-group col-md-6" id="i">
                     
                   </div>

                  <div class="row">
                      
                      <div class="col-md-4">
                        <div id="boton" >
                      
                  </div>
                       <div class="imag" style="  text-align: center; padding: 5px;"></div>
                       <div class="ima" style=" text-align: center; padding: 5px;"></div>
                        <input class="form-control" id="subimagenca"  style="display: none; " name="subimagenca" type="file" placeholder="brr" >
                      </div>
                      <div class="col-md-4">
                          <div id="boton1">
          
                  </div>
                       <div class="imag2" style="  text-align: center; padding: 5px;"></div>
                       <div class="ima2" style=" text-align: center; padding: 5px;"></div>  
                       <input class="form-control" id="subimagenca2"  style="display: none; " name="subimagenca2" type="file" placeholder="brr" >
                      </div>
                      <div class="col-md-4">
                          <div id="boton2">

                  </div>
                       <div class="imag3" style="  text-align: center; padding: 5px;"></div>
                       <div class="ima3" style=" text-align: center; padding: 5px;"></div>  
                       <input class="form-control" id="subimagenca3"  style="display: none; " name="subimagenca3" type="file" placeholder="brr" >
                      </div>                      
                  </div>
                  
                
              <br>
                  
              </div>
                  
                   
                 
                  
                 
              
              
                  <div class="tile-footer">
                      <button id="btnActionForm" class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i><span id="btnText">Guardar</span></button>
              &nbsp;&nbsp;&nbsp;<a class="btn btn-danger" href="#" data-dismiss="modal"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancelar</a>
            </div>
              </form>
            </div>
          </div>
      </div>
    </div>
