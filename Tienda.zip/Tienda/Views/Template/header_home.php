
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $data['page_tag']; ?></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Assets/tienda/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Assets/tienda/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Assets/tienda/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Assets/tienda/fonts/linearicons-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Assets/tienda/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="Assets/tienda/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Assets/tienda/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Assets/tienda/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="Assets/tienda/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Assets/tienda/vendor/slick/slick.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Assets/tienda/vendor/MagnificPopup/magnific-popup.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Assets/tienda/vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Assets/tienda/css/util.css">
	<link rel="stylesheet" type="text/css" href="Assets/tienda/css/main.css">
<!--===============================================================================================-->
</head>
<body class="animsition">
    <input type="hidden" value="0" id="v_calor">	
	<!-- Header -->
	<header>
		<!-- Header desktop -->
                <div class="container-menu-desktop" id="menu">
			<!-- Topbar -->
			<div class="top-bar">
				<div class="content-topbar flex-sb-m h-full container">
					<div class="left-top-bar">
						Envios a nivel Nacional
					</div>

					<div class="right-top-bar flex-w h-full">

                                            <?php if( $data['nombre'] == "0"){ ?>
                                                <a href="<?php base_url();?>sesion" onclick=""class="flex-c-m p-lr-10 trans-04">
							Mi cuenta
						</a>
                                                            <?php }else{ ?>
                                            <a href="<?php base_url();?>sesion" onclick=""class="flex-c-m p-lr-10 trans-04">
							<?php echo $data['nombre']; ?>
						</a>
                                             <?php }  ?>

                                            <?php if( $data['rol'] != "1"){ ?>
                                            <a href="<?php base_url();?>dashboard" class="flex-c-m trans-04 p-lr-25" >
							ADMIN
						  </a>
                                                            <?php } ?>

						 <?php if( $data['usuario'] != "vacio"){ ?>
                                                        <a href="<?php base_url();?>logout" class="flex-c-m trans-04 p-lr-25" title="Cerrar Sesion">
							<i class="fa fa-sign-out" aria-hidden="true"></i>
						  </a>
                                                            <?php } ?>
                                            
                                                 
						
					</div>
				</div>
			</div>

                        <div class="wrap-menu-desktop" style="background-color: white">
				<nav class="limiter-menu-desktop container">
					
					<!-- Logo desktop -->		
					<a href="#" class="logo">
						
                                            <h1 style="color: black"><strong>SURTI</strong>_VIVER</h1>
					</a>

					<!-- Menu desktop -->
					<div class="menu-desktop">
						<ul class="main-menu">
							<li >
                                                           
                                                            <a  id="inicio"  href="<?php base_url();?>home">Inicio</a>

							</li>
                                                        <li>
								<a href="<?php base_url();?>tienda">Productos</a>
							</li>
							<li>
								<a href="<?php base_url();?>nosotros">Acerca de</a>
							</li>

							<li>
								<a href="<?php base_url();?>contacto">Contacto</a>
							</li>
                                                           <?php if( $data['usuario'] != "vacio"){ ?>
                                                        <li>
								<a href="<?php base_url();?>compra">Carrito</a>
                                                           
							</li>
                                                            <?php } ?>
                                                         <?php if( $data['usuario'] != "vacio"){ ?>
                                                        <li>
								<a href="<?php base_url();?>historial">Compras</a>
                                                           
							</li>
                                                            <?php } ?>	
							
						</ul>
					</div>	

					<!-- Icon header -->
					<div class="wrap-icon-header flex-w flex-r-m" >
						
                                                 
                                            <div id="carritos">
                                                <div class="icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 icon-header-noti js-show-cart"  data-notify="<?php if(isset($data['carri'])){ echo $data['carri'];}else{echo "0";} ?>">
							<i class="zmdi zmdi-shopping-cart"></i>
                                                        
						</div>
                                                </div>
                                                 
                                            <a href="<?php base_url();?>sesion" class="dis-block icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 ">
							<i class="fa fa-user" aria-hidden="true"></i>
                                            </a> 
                                             <?php if( $data['usuario'] != "vacio"){ ?>
                                            <a  onclick="color()" href="#" class="dis-block icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 color" id="color" >
							<i class="fa fa-heart" aria-hidden="true"></i>
                                             </a> <?php } ?>
                                            <script>
                                                function color(){
                                                 let c = document.querySelector('#v_calor').value;
                                                 if(c == 1){
                                                    document.getElementById("color").style.color = "black"; 
                                                    document.querySelector('#v_calor').value = 0;
                                                 }else{
                                                    document.getElementById("color").style.color = "red";
                                                    document.querySelector('#v_calor').value = 1;
                                                }}
                                            </script>
					</div>
				</nav>
			</div>	
                        <br><br>
                </div>
                
		<!-- Header Mobile -->
		<div class="wrap-header-mobile" >
			<!-- Logo moblie -->		
			<div class="logo-mobile">
				<h1 style="color: black; font-size: 15px;"><strong>SURTI</strong>_VIVER</h1>
			</div>

			<!-- Icon header -->
			<div class="wrap-icon-header flex-w flex-r-m m-r-15">
				

				  <?php if( $data['usuario'] != "vacio"){ ?>
                                            <div id="carritos">
						<div class="icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 icon-header-noti js-show-cart" data-notify="<?php echo $data['carri'] ?>">
							<i class="zmdi zmdi-shopping-cart"></i>
						</div>
                                                </div>
                                                 <?php } ?>

				<a href="#" class="dis-block icon-header-item cl2 hov-cl1 trans-04 p-r-11 p-l-10 icon-header-noti" data-notify="0">
					<i class="zmdi zmdi-favorite-outline"></i>
				</a>
			</div>

			<!-- Button show menu -->
			<div class="btn-show-menu-mobile hamburger hamburger--squeeze">
				<span class="hamburger-box">
					<span class="hamburger-inner"></span>
				</span>
			</div>
		</div>


		<!-- Menu Mobile -->
              
                <div class="menu-mobile" style="top: 100px">
                    
			<ul class="topbar-mobile "style="top: 100px">
				<li>
					<div class="left-top-bar">
						Envios a nivel Nacional
					</div>
				</li>

				<li>
					<div class="right-top-bar flex-w h-full">
						
                                                 <?php if( $data['nombre'] == "0"){ ?>
                                                <a href="<?php base_url();?>sesion" onclick=""class="flex-c-m p-lr-10 trans-04">
							Mi cuenta
						</a>
                                                            <?php }else{ ?>
                                            <a href="<?php base_url();?>sesion" onclick=""class="flex-c-m p-lr-10 trans-04">
							<?php echo $data['nombre']; ?>
						</a>
                                             <?php }  ?>

                                            <?php if( $data['rol'] != "1"){ ?>
                                            <a href="<?php base_url();?>dashboard" class="flex-c-m trans-04 p-lr-25" >
							ADMIN
						  </a>
                                                            <?php } ?>

						 <?php if( $data['usuario'] != "vacio"){ ?>
                                                        <a href="<?php base_url();?>logout" class="flex-c-m trans-04 p-lr-25" title="Cerrar Sesion">
							<i class="fa fa-sign-out" aria-hidden="true"></i>
						  </a>
                                                            <?php } ?>

						

                                           
					</div>
				</li>
			</ul>

			<ul class="main-menu-m">
                            <li>
				<a onclick="ver()" id="inicio" href="<?php base_url();?>home">Inicio</a>

							</li>
                                                        <li>
								<a href="<?php base_url();?>tienda">Productos</a>
							</li>
							<li>
								<a href="<?php base_url();?>nosotros">Acerca de</a>
							</li>

							<li>
								<a href="<?php base_url();?>contacto">Contacto</a>
							</li>
                                                           <?php if( $data['usuario'] != "vacio"){ ?>
                                                        <li>
								<a href="<?php base_url();?>compra">Carrito</a>
                                                           
							</li>
                                                            <?php } ?>
                                                         <?php if( $data['usuario'] != "vacio"){ ?>
                                                        <li>
								<a href="<?php base_url();?>historial">Compras</a>
                                                           
							</li>
                                                            <?php } ?>
			</ul>
		</div>

		<!-- Modal Search -->
		<div class="modal-search-header flex-c-m trans-04 js-hide-modal-search">
			<div class="container-search-header">
				<button class="flex-c-m btn-hide-modal-search trans-04 js-hide-modal-search">
					<img src="Assets/tienda/images/icons/icon-close2.png" alt="CLOSE">
				</button>

				<form class="wrap-search-header flex-w p-l-15">
					<button class="flex-c-m trans-04">
						<i class="zmdi zmdi-search"></i>
					</button>
					<input class="plh3" type="text" name="search" placeholder="Buscar...">
				</form>
			</div>
		</div>
	</header>
   