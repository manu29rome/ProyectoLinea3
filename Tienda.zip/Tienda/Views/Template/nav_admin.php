<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="Assets/Images/uploads/usuario (2).png" alt="User Image">
        <div>
          <p class="app-sidebar__user-name"><?php echo $data['page_name'];?></p>
          <p class="app-sidebar__user-designation"><?php echo $data['page_rol'];?></p>
        </div>
      </div>
      <ul class="app-menu">
          
        <li><a class="app-menu__item" href="<?php base_url();?>Dashboard"><i class="app-menu__icon fa fa-home" aria-hidden="true"></i><span class="app-menu__label">Inicio</span></a></li>
          <?php 
           
          if($data['page_verusu']+$data['page_verrol'] != 0){ ?>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-users" aria-hidden="true"></i><span class="app-menu__label">Usuarios</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <?php } ?>
            <ul class="treeview-menu">
            <?php if($data['page_verusu']==1){ ?>
            <li><a class="treeview-item" href="<?php base_url();?>usuarios"><i class="icon fa fa-circle-o"></i> Usuarios</a></li>
            <?php } if($data['page_verrol']==1){ ?>
            <li><a class="treeview-item" href="<?php base_url();?>roles"><i class="icon fa fa-circle-o"></i> Roles</a></li>
          <?php } ?>
          </ul>
        </li>  
        <?php if($data['page_vercli']==1){ ?>
        <li><a class="app-menu__item" href="<?php base_url();?>clientes">
                <i class="app-menu__icon fa fa-user" aria-hidden="true"></i>
                <span class="app-menu__label">Clientes</span>
            </a></li> 
        <?php } ?>    
          <?php if($data['page_vercate']+$data['page_versub']+$data['page_verpro'] != 0){ ?>  
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-shopping-basket" aria-hidden="true"></i><span class="app-menu__label">Tienda</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
          <?php if($data['page_vercate']==1){ ?>
              <li><a class="treeview-item" href="<?php base_url();?>categorias"><i class="icon fa fa-circle-o"></i> Categorias</a></li>
           <?php } if($data['page_versub']==1){ ?>
              <li><a class="treeview-item" href="<?php base_url();?>subcategoria"><i class="icon fa fa-circle-o"></i> SubCategorias</a></li>
            <?php } if($data['page_verpro']==1){ ?>
              <li><a class="treeview-item" href="<?php base_url();?>productos"><i class="icon fa fa-circle-o"></i> Productos</a></li>
              <?php } ?>
          </ul>
        </li>
        <?php }  if($data['page_verped']==1){ ?> 
        <li><a class="app-menu__item" href="<?php base_url();?>pedidos">
                <i class="app-menu__icon fa fa-pencil-square-o" aria-hidden="true"></i>
                <span class="app-menu__label">Pedidos</span>
            </a></li>
            <?php } ?>
              <li><a class="app-menu__item" href="<?php base_url();?>home"><i class="app-menu__icon fa fa-university" aria-hidden="true"></i><span class="app-menu__label">Home</span></a></li>
        <li><a class="app-menu__item" href="<?php base_url();?>logout">
               <i class="app-menu__icon fa fa-sign-out" aria-hidden="true"></i>
                <span class="app-menu__label">Cerrar Sesion</span>
            </a></li>
      </ul>
    </aside>
