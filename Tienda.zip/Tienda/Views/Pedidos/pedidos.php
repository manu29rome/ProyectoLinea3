<?php headerAdmin($data);?>

<main class="app-content">
     <div class="app-title">
          <div >
          <h1>Pedidos</h1>
        </div>
         
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="<?php base_url()?>Dashboard">Inicio</a></li>
        </ul>
      </div>
</main>
  <?php footerAdmin($data);?>
