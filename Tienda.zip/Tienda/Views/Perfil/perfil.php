<?php headerAdmin($data);?>
<main class="app-content">
    <div class="app-title">
          <div >
          <h1><?php echo $data['page_admin']; ?> </h1>
        </div>
         
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="<?php base_url()?>Dashboard">Inicio</a></li>
        </ul>
      </div>
      <div class="row user">
        <div class="col-md-12">
          <div class="profile">

              <div class="cover-image"></div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="tile p-0">
            <ul class="nav flex-column nav-tabs user-tabs">
              <li class="nav-item"><a class="nav-link active" href="#user-timeline" data-toggle="tab">Datos Personales</a></li>
              <li class="nav-item"><a class="nav-link" href="#user-settings" data-toggle="tab">Editar Datos</a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-9">
          <div class="tab-content">
            <div class="tab-pane active" id="user-timeline">
                <div class="tile user-settings">
                    <h4 class="line-head">Datos Personales</h4>
                <label for="txtIdentificacion"style="width: 30%">Identificacion (CC-TI-OTRO):</label>
                <input type="text" value="<?php echo $data['page_identificacion'];?>" class="" id="txtIdentificacion1" name="txtIdentificacion" disabled=»disabled» style="border: white; width: 60%;">
                  <br>
                  
                      <label for="txtNombre"style="width: 30%">Nombre:</label>
                      <input type="text" value="<?php echo $data['page_nombre'];?>" class="" id="txtNombre1" name="txtNombre" disabled=»disabled» style="border: white; width: 60%;" >
                  <br>
                      <label for="txtApellido"style="width: 30%">Apellido:</label>
                      <input type="text" value="<?php echo $data['page_apellido'];?>" class="" id="txtApellido1" name="txtApellido" disabled=»disabled» style="border: white; width: 60%;" >
                  <br>
                  
                      <label for="txtTelefono"style="width: 30%">Telefono:</label>
                      <input type="text" value="<?php echo $data['page_telefono'];?>" class="" id="txtTelefono1" name="txtTelefono" disabled=»disabled» style="border: white; width: 60%;">
                  <br>
                      <label for="txtEmail"style="width: 30%">Email:</label>
                      <input type="text" value="<?php echo $data['page_email'];?>" class="" id="txtEmail1" name="txtEmail" disabled=»disabled» style="border: white; width: 60%;" >
                  <br>
             
                  <label for="ListRolid"style="width: 30%">Rol:</label>
                  <input type="text" value="<?php echo $data['page_rol'];?>" class="" id="ListRolid1" name="ListRolid1" disabled=»disabled» style="border: white; width: 60%;" >
                  <br>
                  
                  </div>
            </div>
            <div class="tab-pane fade" id="user-settings">
              <div class="tile user-settings">
                <h4 class="line-head">Editar Datos</h4>
                <form id="editarUsuario">
                  <div class="row mb-12">
                      <div class="col-md-6">
                      <label>Telefono</label>
                      <input class="form-control" onkeypress="return solonumeros(event)" value="<?php echo $data['page_telefono'];?>" id="txttelefono" name="txttelefono" type="text">
                    </div>
                  </div>
                    <br>
                    
                  <div class="row mb-12">
                       <div class="col-md-6">
                      <label>Nombre</label>
                      <input class="form-control" onkeypress="return sololetras(event)" value="<?php echo $data['page_nombre'];?>" id="txtnombre" name="txtnombre" type="text">
                    <br>
                       </div>
                      
                    <div class="col-md-6">
                      <label>Apellido</label>
                      <input class="form-control" onkeypress="return sololetras(event)" value="<?php echo $data['page_apellido'];?>" id="txtapellido" name="txtapellido" type="text">
                      <br>
                    </div>
                  </div>
                    <div class="row mb-12">
                    <div class="col-md-6">
                      <label>Contraseña</label>
                      <input class="form-control" maxlength="10" minlength="8" value="" id="contraseña" name="contraseña" type="text">
                     <span style="font-size: 11px;">(Caracteres minimos 8 y maximos 10.)</span>
                      <br>
                       <br>
                    </div>
                      
                      <div class="col-md-6">
                      <label>Confirmar Contraseña</label>
                      <input class="form-control" maxlength="10" minlength="8" value="" id="contraseñareset" name="contraseñareset" type="text">
                      <span style="font-size: 11px;">(Caracteres minimos 8 y maximos 10.)</span>
                      </div>
                  </div>
                     
                     <br>
                  <div class="row mb-10">
                    <div class="col-md-12">
                        <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Actualizar</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
<?php footerAdmin($data);?>