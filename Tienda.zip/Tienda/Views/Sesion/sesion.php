<?php headerHome($data);?>
<br>
<br>
<br>
<br>
<div class="row">
    
    <div class="col-md-6 col-xl-4 p-b-30 m-lr-auto" >
      
     <div class="login-box">
         
          <form class="login-form" name="formlogin" id="formlogin" action="">
              <h3 class="login-head"><strong>INICIAR SESION</strong></h3>
          <div class="form-group"><br>
            <label class="control-label">Usuario</label>
            <input id="txtEmail" name="txtEmail" class="form-control" type="text" placeholder="Email" autofocus>
          </div>
          <div class="form-group">
            <label class="control-label">Contraseña</label>
            <input id="txtContraseña" name="txtContraseña" class="form-control" type="password" placeholder="Contraseña">
          </div>
          <div id="alertLogin" class="text-center"></div>
          <div class="form-group btn-container">
              <button type="submit" class="btn btn-info btn-block" ><i class="fa fa-sign-in fa-lg fa-fw"></i>INICIAR SESION</button>
          </div>
          
        </form>
         <form class="forget-form" action="" id="recuperar_contraseña"><br>
             <h3 class="login-head" ><strong>¿Olvidaste tu Contraeña?</strong></h3><br>
          <div class="form-group">
            <label class="control-label">EMAIL</label>
            <input id="txtEmailReset" name="txtEmailReset" class="form-control" type="text" placeholder="Email">
          </div>
          <div class="form-group btn-container">
              <button type="submit" class="btn btn-info btn-block" ><i class="fa fa-unlock fa-lg fa-fw"></i>CONFIRMAR</button>
          </div>
        </form>
      </div>
        </div>
 
    
    
    
    
     <div class="col-md-6 col-xl-4 p-b-30 m-lr-auto">      
         <form class="login-form" name="formlogin" id="formregistro" action="">
         
         <h3 class="login-head"><strong>REGISTRO</strong></h3>
         <br>
         
           <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="txtNombre">Primer Nombre</label>
                      <input type="text" class="form-control" placeholder="Nombre" onkeypress="return sololetras(event)" id="txtnombre" name="txtnombre" >
                  </div>
                  <div class="form-group col-md-6">
                      <label for="txtApellido">Primer Apellido</label>
                      <input type="text" class="form-control" placeholder="Apellido" onkeypress="return sololetras(event)" id="txtapellido" name="txtapellido" >
                  </div></div>
                  
             

          
             <div class="form-row">
                 <div class="form-group col-md-6">
                      <label for="txtIdentificacion">Nº(CC-TI-OTRO)</label>
                      <input type="text" class="form-control" placeholder="Nº Identificacion"onkeypress="return solonumeros(event)" id="txtidentificacion" name="txtidentificacion" >
                  </div> 
               <div class="form-group col-md-6">
                      <label for="txtTelefono">Telefono</label>
                      <input type="text" class="form-control" placeholder="Telefono" onkeypress="return solonumeros(event)" id="txttelefono" name="txttelefono" >
                  </div>  
                 <div class="form-group col-md-12">
                  <label for="txtEmail">Email</label>
                  <input type="text" class="form-control" placeholder="Email" id="txtemail" name="txtemail" >
                  
                  </div>
                   </div> 
             

              <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="txtPassword">Contraseña</label>
                      <input type="password" class="form-control" placeholder="Contraseña" maxlength="16" minlength="12" id="contraseña" name="contraseña" >
                      <span style="font-size: 11px;">(Caracteres minimos 12 y maximos 16, Mayusculas, Minusculas y Simbolos)</span>
                  </div>
                  <div class="form-group col-md-6">
                      <label for="txtPassword">Rectificar Contraseña</label>
                      <input type="password" class="form-control" placeholder="Contraseña" maxlength="16" minlength="12" id="contraseñareset" name="contraseñareset" >
                      
                  </div>
             </div>
              
         <div class="form-row">
             <input type="checkbox"><span style="font-size: 12px"><strong>..Acepto terminos y condiciones</strong></span>
                  
         </div><br>
                  
             

              
             <div class="form-row">
                 <div class="form-group col-md-12">
                  <div class="tile-footer">
                      <button id="btnActionForm" class="btn btn-info" type="submit" style="width: 100%"><i class="fa fa-fw fa-lg fa-check-circle"></i><span id="btnText">REGISTRAR</span></button>
              &nbsp;&nbsp;&nbsp;
              </div>
              </div>
            </div>
         </form>
      </div>                    
       
 
</div>
<?php footerHome($data);?>