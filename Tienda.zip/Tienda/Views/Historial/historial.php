
<?php headerHome($data);?>
<?php Carrito($data);?>	

<section class="bg-img1 txt-center p-lr-15 p-tb-92" style="background-color: #cccccc ">
		<h2 class="ltext-105 cl0 txt-center">
			Compras
		</h2>
	</section>	

 <?php footerHome($data);?>