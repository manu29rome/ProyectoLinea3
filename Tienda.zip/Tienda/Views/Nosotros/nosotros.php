<?php headerHome($data);?>
<?php Carrito($data);?>	

<section class="bg-img1 txt-center p-lr-15 p-tb-92" style="background-image: url('Assets/images/uploads/adorno.jpeg'); ">
		<h2 class="ltext-105 cl0 txt-center">
			Acerca de 
		</h2>
	</section>	


	<!-- Content page -->
	<section class="bg0 p-t-75 p-b-120">
		<div class="container">
			<div class="row p-b-148">
				<div class="col-md-7 col-lg-8">
					<div class="p-t-7 p-r-85 p-r-15-lg p-r-0-md">
						<h3 class="mtext-111 cl2 p-b-16">
							Nuestra Historia
						</h3>

						<p class="stext-113 cl6 p-b-26">
							texto 1
                                                </p>

						<p class="stext-113 cl6 p-b-26">
						        texto 2
                                                </p>

						<p class="stext-113 cl6 p-b-26">
						        texto 3
                                                </p>
					</div>
				</div>

				<div class="col-11 col-md-5 col-lg-4 m-lr-auto">
					<div class="how-bor1 ">
						<div class="hov-img0">
							<img src="Assets/images/uploads/Emote2.jpg" alt="IMG">
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="order-md-2 col-md-7 col-lg-8 p-b-30">
					<div class="p-t-7 p-l-85 p-l-15-lg p-l-0-md">
						<h3 class="mtext-111 cl2 p-b-16">
							Nuestra Mision
						</h3>

						<p class="stext-113 cl6 p-b-26">
							texto 6
						</p>

						<div class="bor16 p-l-29 p-b-9 m-t-22">
							<p class="stext-114 cl6 p-r-40 p-b-11">
								Eres lo que eres y que está donde está por lo que ha pasado en su mente. Cambia lo que eres y cambia en el que está cambiando lo que entra en su mente.
							</p>

							<span class="stext-111 cl8">
								- Zig Ziglar 
							</span>
						</div>
					</div>
				</div>

				<div class="order-md-1 col-11 col-md-5 col-lg-4 m-lr-auto p-b-30">
					<div class="how-bor2">
						<div class="hov-img0">
							<img src="Assets/images/uploads/Emote2.jpg" alt="IMG">
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>	
	

 <?php footerHome($data);?>