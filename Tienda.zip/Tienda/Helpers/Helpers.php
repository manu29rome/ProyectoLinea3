<?php
define('METODO', 'AES-256-CBC');
define('SECRET_KEY', '$JH3Ihhfjkfroo');
define('SECRET_IV', '101712');
function base_url(){
return BASE_URL;
}

function isEmail($email){
    if(filter_var($email, FILTER_VALIDATE_EMAIL)){
        return true; 
    }else{
        return false;
    }
}

function  desencriptar($data=""){
 $key = hash('sha256',SECRET_KEY);
    $iv = substr(hash('sha256',SECRET_IV),0,16);
    $output = openssl_decrypt(base64_decode($data), METODO,$key,0,$iv);
    return $output;   
}

function encriptar($data=""){
    $output = false;
    $key = hash('sha256',SECRET_KEY);
    $iv = substr(hash('sha256',SECRET_IV),0,16);
    $output = openssl_encrypt($data, METODO,$key,0,$iv);
    $output = base64_encode($output);
    return $output;
}

function headerAdmin($data=""){
    $view_header="Views/Template/header_admin.php";
    require_once ($view_header);  
}
function footerAdmin($data=""){
    $view_footer="Views/Template/footer_admin.php";
    require_once ($view_footer);  
}

function headerHome($data=""){
    $view_header="Views/Template/header_home.php";
    require_once ($view_header);  
}
function footerHome($data=""){
    $view_footer="Views/Template/footer_home.php";
    require_once ($view_footer);  
}
function Carrito($data=""){
    $view_footer="Views/Template/carrito.php";
    require_once ($view_footer);  
}


function dep($data){
    $format = print_r('<pre>');
    $format .= print_r($data);
    $format .= print_r('</pre>');
    return $format;
}
function getModal(string $nameModal,$data){
  $view_modal = "Views/Template/Modals/$nameModal.php";
  require_once $view_modal;
}

function strClean($strCadena){
 $string= preg_replace('/\s\s+/', ' ', $strCadena); 
 $string = trim($string);
 $string = stripslashes($string);
 $string = str_ireplace("<script>","",$string);
 $string = str_ireplace("</script>","",$string);
 $string = str_ireplace("<script src>","",$string);
 $string = str_ireplace("<script type=>","",$string);
 $string = str_ireplace("SELECT * FROM","",$string);
 $string = str_ireplace("DELETE FROM","",$string);
 $string = str_ireplace("INSERT INTO","",$string);
 $string = str_ireplace("SELECT COUNT(*) FROM","",$string);
 $string = str_ireplace("DROP TABLE","",$string);
 $string = str_ireplace("OR '1'='1'","",$string);
 $string = str_ireplace('OR "1"="1"',"",$string);
 $string = str_ireplace("IS NULL --","",$string);
 $string = str_ireplace('IS NULL --',"",$string);
 $string = str_ireplace("LIKE '","",$string);
 $string = str_ireplace('LIKE "',"",$string);
 $string = str_ireplace("OR 'a'='a","",$string);
 $string = str_ireplace('OR "a"="a',"",$string);
 $string = str_ireplace("--","",$string);
 $string = str_ireplace("^","",$string);
 $string = str_ireplace("[","",$string);
 $string = str_ireplace("]","",$string);
 $string = str_ireplace("==","",$string);
 return $string;
}
function pasGenerator($Length = 12){
    $pass = "";
    $longitudPass = $Length;
    $cadena = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuwxyz1234567890"; 
    $longitudPass = strlen($cadena);
    for($i = 1;$i<=12;$i++){
        $pas = rand(0,$longitudPass-1);
        $pass .= substr($cadena,$pas,1);
    }
    return $pass."*";
}
function token(){
    $r1 = bin2hex(random_bytes(10));
    $r2 = bin2hex(random_bytes(10));
    $r3 = bin2hex(random_bytes(10));
    $r4 = bin2hex(random_bytes(10));
    $token = $r1."-".$r2."-".$r3."-".$r4;
    return $token;
}

function formaMoney($cantidad){
    $cantidad = number_format($cantidad,2,SPD,SPM);
    return $cantidad;
}
?>

