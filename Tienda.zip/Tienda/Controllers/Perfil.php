<?php

class Perfil extends Controllers {
    public function __construct() {
        parent:: __construct();  
        session_start();
        
        if(empty($_SESSION['login'])){
            header('location:'.base_url().'home');
        }
        if(isset($_SESSION['idUser'])){
         $User = $this->model->selectUsuario($_SESSION['idUser']);   
            if($User['rolid'] == 1){
            header('location:'.base_url().'home');
        }}
        ; }
    
    public function perfil(){
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
                $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $añadir=$Requestper[3]['añadir'];
        $ver=$Requestper[2]['ver'];
        $data['page_nombre']=$RequestUser['nombreus'];
        $data['page_apellido']=$RequestUser['apellidous'];
        $data['page_telefono']=$RequestUser['telefono'];
        $data['page_email']=$RequestUser['email'];
        $data['page_identificacion']=$RequestUser['identificacionus'];
        $data['page_functions_js']="function_perfilU.js";
        $data['page_tag']='Perfil';
        $data['page_title'] = "Perfil";
        $data['page_name'] = $RequestUser['nombreus'];
        $data['page_rol'] = $RequestRol['nombrerol'];
        $data['page_admin'] =$RequestUser['nombreus']." ".$RequestUser['apellidous'] ;
        $data['page_añadir']=$añadir;
        $data['page_verrol']=$Requestper[1]['ver'];
        $data['page_verusu']=$Requestper[2]['ver'];
         $data['page_verpro']=$Requestper[3]['ver'];
         $data['page_vercate']=$Requestper[4]['ver'];
         $data['page_verped']=$Requestper[5]['ver'];
         $data['page_versub']=$Requestper[6]['ver'];
         $data['page_vercli']=$Requestper[7]['ver'];
        $this->views->getView($this,"perfil",$data); 
        }
        
     public function setUsuario(){
    $idus = $_SESSION['idUser'];
    $strNombre= strClean($_POST["txtnombre"]);
    $strApellido= strClean($_POST["txtapellido"]);
    $intTelefono= intval($_POST["txttelefono"]);
    $strcontra = strClean($_POST["contraseñareset"]);
    if($strcontra != ""){
    $strContraseña= encriptar($strcontra);
    }else{
     $strContraseña =  $strcontra;
    }
    
    $request_usuario = $this->model->updateUsuario($idus,$strNombre,$strApellido,$intTelefono,$strContraseña);
    if($request_usuario > 0){
        $arrResponse =array('status' => true,'msg'=>'Datos Actualizados correctamente.'); 
       
    }
    echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
    die(); 
   }
        
}
?>