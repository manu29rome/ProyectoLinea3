<?php
class Usuarios extends Controllers {
    public function __construct() {
        parent:: __construct();  
        session_start();
        if(empty($_SESSION['login'])){
            header('location:'.base_url().'home');
        }
        if(isset($_SESSION['idUser'])){
         $User = $this->model->selectUsuario($_SESSION['idUser']);   
            if($User['rolid'] == 1){
            header('location:'.base_url().'home');
        }else{
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
        $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $permiso = $Requestper[2]['ver'];
        if($permiso == 0){
          header('location:'.base_url().'dashboard');  
        }}}
        ; }
        
    public function usuarios(){
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
        $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $data['page_rol'] = $RequestRol['nombrerol'];
        $data['page_tag']='Usuarios';
        $data['page_title'] = "Usuarios";
        $data['page_name'] = $RequestUser['nombreus'];
        $data['page_functions_js']="function_usuarios.js";
        $data['page_añadir']=$Requestper[2]['añadir'];
        $data['page_verrol']=$Requestper[1]['ver'];
         $data['page_verusu']=$Requestper[2]['ver'];
         $data['page_verpro']=$Requestper[3]['ver'];
         $data['page_vercate']=$Requestper[4]['ver'];
         $data['page_verped']=$Requestper[5]['ver'];
         $data['page_versub']=$Requestper[6]['ver'];
         $data['page_vercli']=$Requestper[7]['ver'];
        $arrData = $this->model->selectUsuariosRol();
        $cadena = '<select  id = "rol" name = "rol"  class="form-control">';
        for($i=0; $i < count($arrData);$i++){
        $cadena = $cadena.'<option value="'.$arrData[$i]['idrol'].'">'.$arrData[$i]['nombrerol'].'</option>' ;
        }
        $cadena.'</select>';
        $data['select'] = $cadena;
        $this->views->getView($this,"usuarios",$data);
    }
   
    public function getUsuario(int $idUsuario){
        $intIdusuario = intval(strClean($idUsuario));
        if($intIdusuario > 0){
          $arrData = $this->model->selectUsuario($intIdusuario);
        if(empty($arrData)){
          $arrResponse = array('status' => false,'msg'=>'Datos no encontrados.' ); 
        }else{
            $contra = $arrData['Password'];
          $arrData['contra'] = "************";
          $arrResponse = array('status' => true,'msg'=>$arrData ); 
        }
        echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
      }
     die();
        }
        
      public function getRol(int $idrol){
        $intIdusuario = intval(strClean($idrol));
     
        if($intIdusuario > 0){
          $arrData = $this->model->selectUsuarioRol($intIdusuario);
        if(empty($arrData)){
          $arrResponse = array('status' => false,'msg'=>'Datos no encontrados.' ); 
        }else{
          
          $arrResponse = array('status' => true,'msg'=>$arrData); 
        }
        echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
      }
     die();
        }
    
   public function getUsuarios(){
    $rol = 0;
    $arrData = $this->model->selectUsuarios(); 
    $idus = $_SESSION['idUser'];
    $RequestUser = $this->model->selectUsuario($idus);
    $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
    
    
    for($i=0; $i < count($arrData);$i++){
    $arrDat = $this->model->selectUsuarioRol($arrData[$i]['rolid']); 
    $arrData[$i]['roles']=$arrDat["nombrerol"];
    if($arrData[$i]['status'] == 1){
     $arrData[$i]['status']='<span class="badge badge-success">Activo'; 
        ;}else{
             $arrData[$i]['status']='<span class="badge badge-danger">Inactivo'; 
        }
        
       $cadena ='<div class="text-center">
       <button class="btn btn-success btn-sm  btnVerUsuario" rl="'.$arrData[$i]['idus'].'" title="ver"><i class="fa fa-eye" aria-hidden="true"></i></button>';
       if($Requestper[2]['editar'] == 1){
        $cadena = $cadena.'<button  class="btn btn-info btn-sm btnEditUsuario"  rl="'.$arrData[$i]['idus'].'" title="Editar"><i class="fa fa-pencil" aria-hidden="true"></i></button>';
       }  if($Requestper[2]['eliminar'] == 1){      
        $cadena = $cadena.'<button class="btn btn-danger btn-sm  btnDeUsuario" rl="'.$arrData[$i]['idus'].'" title="Eliminar"><i class="fa fa-trash" aria-hidden="true"></i></button>
       </div>';}
        $arrData[$i]['options']= $cadena;
        $arrData[$i]['total']= count($arrData);
    }
    echo json_encode($arrData,JSON_UNESCAPED_UNICODE);
    die();

   }
    
   
   public function setUsuario(){
    $intIdUsuario = intval($_POST["idUsuario"]);
    $strNombre= strClean($_POST["txtNombre"]);
    $strApellido= strClean($_POST["txtApellido"]);
    $strEmail= strClean($_POST["txtEmail"]);
    $intTelefono= intval($_POST["txtTelefono"]);
    $intRolid= intval($_POST["rol"]);
    $strPassword= encriptar(strClean($_POST["txtPassword"]));
    $intStatus= intval($_POST["ListStatus"]);
    $intIdentificacion= intval($_POST["txtIdentificacion"]);
    
    if(isEmail($strEmail)){
        if($intIdUsuario == 0){
      $request_usuario = $this->model->insertUsuario($strNombre,$strApellido,$strEmail,$intTelefono,$intRolid,$strPassword,$intStatus,$intIdentificacion);
      $option = 1;
    }else{
      $request_usuario = $this->model->updateUsuario($intIdUsuario,$strNombre,$strApellido,$strEmail,$intTelefono,$intRolid,$strPassword,$intStatus,$intIdentificacion);
      $option = 2;
    }

    if($request_usuario > 0){
      if($option == 1){
        $arrResponse =array('status' => true,'msg'=>'Datos guardados correctamente.');
      }else{
        $arrResponse =array('status' => true,'msg'=>'Datos Actualizados correctamente.');
      }
       
    }else if($request_usuario == "exist"){
       $arrResponse =array('status' => false,'msg'=>'¡Atencion! El Usuario ya existe.'); 
    }else if($request_usuario == "exist1"){
       $arrResponse =array('status' => false,'msg'=>'¡Atencion! El Correo Electronico ya existe..'); 
    }
    else{
         $arrResponse =array('status' => false,'msg'=>'¡Atencion! El Usuario ya existe.');
    }    
    }else{
        $arrResponse =array('status' => false,'msg'=>'¡Atencion! El Email no es valido.');
    }

    echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
    die(); 
   }
   
   public function delUsuario(){
          if($_POST){
           $intIdUsuario = intval($_POST['idUsuario']);
           $requestDelete = $this->model->deleteUsuario($intIdUsuario);
           if($requestDelete == 'ok'){
             $arrResponse = array('status' => true, 'msg' => 'Se ha eliminado el Usuario');
           }else if($requestDelete == 'exist'){
            $arrResponse = array('status' => false, 'msg' => 'Error al eliminar el Usuario');
           }else{
            $arrResponse = array('status' => false, 'msg' => 'No es posible Eliminar el Usuario asociado a un Rol');
           }
           
           echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
          }
          die();
        }
        
        
   
}