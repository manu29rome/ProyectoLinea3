<?php

class Productos extends Controllers {
    public function __construct() {
        parent:: __construct();  
        session_start();
        if(empty($_SESSION['login'])){
            header('location:'.base_url().'home');
        }
        if(isset($_SESSION['idUser'])){
         $User = $this->model->selectUsuario($_SESSION['idUser']);   
            if($User['rolid'] == 1){
            header('location:'.base_url().'home');
        }else{
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
        $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $permiso = $Requestper[3]['ver'];
        if($permiso == 0){
          header('location:'.base_url().'dashboard');  
        }}}
        ; }
    public function productos (){
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
        $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $data['page_rol'] = $RequestRol['nombrerol'];
        $data['page_name'] = $RequestUser['nombreus'];
        $data['page_tag']='Productos';
        $data['page_admin']='Manuel Romero';
        $data['page_añadir']=$Requestper[3]['añadir'];
        $data['page_functions_js']="function_productoss.js";
        $data['page_verrol']=$Requestper[1]['ver'];
         $data['page_verusu']=$Requestper[2]['ver'];
         $data['page_verpro']=$Requestper[3]['ver'];
         $data['page_vercate']=$Requestper[4]['ver'];
         $data['page_verped']=$Requestper[5]['ver'];
         $data['page_versub']=$Requestper[6]['ver'];
         $data['page_vercli']=$Requestper[7]['ver'];
         $arrData = $this->model->selectsubCategorias();
        $cadena = '<select  id = "Listsubca" name = "Listsubca"  class="form-control">';
        for($i=0; $i < count($arrData);$i++){
        $cadena = $cadena.'<option value="'.$arrData[$i]['idsubca'].'">'.$arrData[$i]['subcategoria'].'</option>' ;
        }
        $cadena.'</select>';
        
        $data['select'] = $cadena;
        $this->views->getView($this,"productos",$data);
    }
    
    public function setProductos(){
    $arrData = $this->model->selectProductos(); 
    $idus = $_SESSION['idUser'];
    $RequestUser = $this->model->selectUsuario($idus);
    $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
    for($i=0; $i < count($arrData);$i++){
        $categorias = $this->model->selectsubCategoria($arrData[$i]['idca']);
        $arrData[$i]['subcategorias']=$categorias['subcategoria'];
    if($arrData[$i]['status'] == 1){
     $arrData[$i]['status']='<span class="badge badge-success">Activo'; 
        ;}else{
             $arrData[$i]['status']='<span class="badge badge-danger">Inactivo'; 
        }
        
        $cadena='<div class="text-center">';
        if($Requestper [3]['editar']== 1){
        $cadena = $cadena.'<button  class="btn btn-info btn-sm btnEditProducto"  rl="'.$arrData[$i]['idpro'].'" title="Editar"><i class="fa fa-pencil" aria-hidden="true"></i></button>';
        }if($Requestper [3]['eliminar']== 1){
        $cadena = $cadena.'<button class="btn btn-danger btn-sm  btnDeProducto" rl="'.$arrData[$i]['idpro'].'" title="Eliminar"><i class="fa fa-trash" aria-hidden="true"></i></button>
        </div>';}
        if($Requestper [3]['editar']== 0 && $Requestper [3]['eliminar']== 0){
         $cadena= "=(";   
        }
        $arrData[$i]['options']=$cadena;
        }
        
        
    echo json_encode($arrData,JSON_UNESCAPED_UNICODE);
    die();

   }
    
   public function getProductos(){
       
    $intIdca = intval($_POST['subidCa']);
    $strNombre = strClean($_POST['subtxtNombreca']);
    $strDesctipcion = strClean($_POST['edito']);
    $intPrecio = intval($_POST['txtprecio']);
    $intdato1 = intval($_POST['imagen1']);
    $intdato2 = intval($_POST['imagen2']);
    $intdato3 = intval($_POST['imagen3']);
    $intcantidad = intval($_POST['txtStock']); 
    $intStatus = intval($_POST['sublistStatusca']);
    $intcategoria = intval($_POST['Listsubca']); 
    $imagen1 = $_FILES['subimagenca']["name"]; 
    $imagen2 = $_FILES['subimagenca2']["name"]; 
    $imagen3 = $_FILES['subimagenca3']["name"]; 
    
    $rutap1 = $_FILES['subimagenca']["tmp_name"];
    $tamaño1 = $_FILES['subimagenca']["size"];
    $rutap2 = $_FILES['subimagenca2']["tmp_name"];
    $tamaño2 = $_FILES['subimagenca2']["size"];
    $rutap3 = $_FILES['subimagenca3']["tmp_name"];
    $tamaño3 = $_FILES['subimagenca3']["size"];
    
    $ancho1 = "";
    $ancho2 = "";
    $ancho3 = "";
    $alto1 = "";
    $alto2 = "";
    $alto3 = "";
    
    if($imagen1 == ""){
      $imagen1 = 1;  
    }else{
    $imagen1 = "Assets/Images/Productos/".$imagen1; 
    $image1 = getimagesize($_FILES['subimagenca']["tmp_name"]);    //Sacamos la información
    $ancho1 = $image1[0];
    $alto1=$image1[1];
    }
    
    if($imagen2 == ""){
      $imagen2 = 2;  
    }else{
      $imagen2 = "Assets/Images/Productos/".$imagen2;  
      $image2 = getimagesize($_FILES['subimagenca2']["tmp_name"]);    //Sacamos la información
      $ancho1 = $image2[0];
      $alto1=$image2[1];
    }
    
    if($imagen3 == ""){
      $imagen3 = 3;  
    }else{
      $imagen3 = "Assets/Images/Productos/".$imagen3; 
      $image3 = getimagesize($_FILES['subimagenca3']["tmp_name"]);    //Sacamos la información
      $ancho3 = $image3[0];
      $alto3  = $image3[1];
    }
    
    if($imagen1 == $imagen2 || $imagen1 == $imagen3 || $imagen2 == $imagen3){
        $arraData = array('status' => false,'msg'=>'Se encuetra una imagen con el mismo nombre.');
    }else{
    if($ancho1 == 1200  && $alto1 == 1486 || $ancho1 == ""  && $alto1 == "" ){
      if($ancho2 == 1200  && $alto2 == 1486 || $ancho2 == ""  && $alto2 == ""){
        if($ancho3 == 1200  && $alto3 == 1486 || $ancho3 == ""  && $alto3 == ""){
           
             if($intIdca == 0){   
             $intcodigo = intval($_POST['txtCodigo']); 
             $request_categoria = $this->model->insertProducto($strNombre,$strDesctipcion,$intStatus,$intcategoria,$intcantidad,$intPrecio,$intcodigo,$imagen1,$imagen2,$imagen3);
             $opcion = 1;
              }else{
             
             $intcodigo2 = intval($_POST['codg']); 
             $request_categoria = $this->model->updateProducto($intIdca,$strNombre,$strDesctipcion,$intStatus,$intcategoria,$intcantidad,$intPrecio,$imagen1,$imagen2,$imagen3);
              if ($request_categoria > 0){
             $request_image = $this->model->updateimagen($imagen1,$imagen2,$imagen3,$intcodigo2,$intdato1,$intdato2,$intdato3);
              }
             $opcion = 2;
              }
              
             if ($request_categoria > 0){
                 
             if($opcion == 1){
             $arraData = array('status' => true,'msg'=>'Se ha guardado correctamente los Datos.');}
             if($opcion == 2){
             $arraData = array('status' => true,'msg'=>'Se ha Actualizado correctamente los Datos.');
             
             }
             
             if($imagen1 != 1){
                move_uploaded_file($rutap1,$imagen1); 
             }
             if($imagen2 != 2){
                move_uploaded_file($rutap2,$imagen2); 
             }
             if($imagen3 != 3){
                move_uploaded_file($rutap3,$imagen3); 
             }
             
             }else if($request_categoria == "exist"){
             $arraData = array('status' => false,'msg'=>'Ya existe el Producto.');  
              }else if($request_categoria == "exist1"){
             $arraData = array('status' => false,'msg'=>'Ya existe la imagen uno.');  
              } else if($request_categoria == "exist2"){
             $arraData = array('status' => false,'msg'=>'Ya existe la imagen dos.');  
              } else if($request_categoria == "exist3"){
             $arraData = array('status' => false,'msg'=>'Ya existe la imagen tres.');  
              }
             
    }else{
     $arraData = array('status' => false,'msg'=>'Tamaño de la imagen tres es de ancho 1200px y alto 1486px.');   
      }}else{
     $arraData = array('status' => false,'msg'=>'Tamaño de la imagen dos es de ancho 1200px y alto 1486px.');   
      }}else{
     $arraData = array('status' => false,'msg'=>'Tamaño de la imagen una es de ancho 1200px y alto 1486px.');   
    }
   
    
    }
   echo json_encode($arraData,JSON_UNESCAPED_UNICODE);
    die(); 
   }
   
   public function getProducto(int $idrol){
        $intIdrol = intval($idrol);
        if($intIdrol > 0){
          $arrData = $this->model->selectProducto($intIdrol);
          
          $Data = $this->model->selectProductoImagen($arrData['codigo']);
          
          if(empty($Data)){ 
          }else{
          if(empty($Data[0]['imagen'])){  
          }else{
          $arrData['imagen1']= $Data[0]['imagen'];  
          $imagenes1 = str_replace("Assets/Images/Productos/", "", $Data[0]['imagen'] );
          $arrData['imagen11']= $imagenes1; 
          }
          if(empty($Data[1]['imagen'])){   
          }else{
          $arrData['imagen2']= $Data[1]['imagen'];
          $imagenes2 = str_replace("Assets/Images/Productos/", "", $Data[1]['imagen'] );
          $arrData['imagen22']= $imagenes2;
          }
          if(empty($Data[2]['imagen'])){   
          }else{
          $arrData['imagen3']= $Data[2]['imagen'];
          $imagenes3 = str_replace("Assets/Images/Productos/", "", $Data[2]['imagen'] );
          $arrData['imagen33']= $imagenes3;
          }
          }
        if(empty($arrData)){
          $arrResponse = array('status' => false,'msg'=>'Datos no encontrados.' ); 
        }else{
          $arrResponse = array('status' => true,'msg'=>$arrData ); 
        }        echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        
      }
     die();
        }
        
        public function DelProductos (){
      if($_POST){
          
           $intPro = intval($_POST['subidCa']);
           $request = $this->model->selectProducto($intPro);
           $cod = $request['codigo'];
           $requestDelet = $this->model->selectProductoImagen($cod);
           $requestDelete = $this->model->deleteProducto($intPro);
           
           if($requestDelete == 'ok'){
           if(empty($requestDelet[0]['imagen'])){ }else{
             unlink($requestDelet[0]['imagen']);   
           }
           if(empty($requestDelet[1]['imagen'])){ }else{
             unlink($requestDelet[1]['imagen']);   
           }
           if(empty($requestDelet[2]['imagen'])){ }else{
             unlink($requestDelet[2]['imagen']);   
           }
           if(empty($request['codigo'])){ }else{
             $requestDeleteimagen = $this->model->deleteimagen($cod);   
           }
             $arrResponse = array('status' => true, 'msg' => 'Se ha eliminado el Producto');
           }else if($requestDelete == 'exist'){
            $arrResponse = array('status' => false, 'msg' => 'Error al eliminar el Producto');
           }
           echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
          }
          die(); 
   }

   
}
