<?php

class Subcategoria extends Controllers  {
   public function __construct() {
        parent:: __construct();  
        session_start();
        
        if(empty($_SESSION['login'])){
            header('location:'.base_url().'home');
        }
        if(isset($_SESSION['idUser'])){
         $User = $this->model->selectUsuario($_SESSION['idUser']);   
            if($User['rolid'] == 1){
            header('location:'.base_url().'home');
        }else{
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
        $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $permiso = $Requestper[6]['ver'];
        if($permiso == 0){
          header('location:'.base_url().'dashboard');  
        }}}
        ; }
        
        public function subcategoria(){
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
        $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $data['page_rol'] = $RequestRol['nombrerol'];
        $data['page_tag']='SubCategoria';
        $data['page_title'] = "SubCategorias";
        $data['page_name'] = $RequestUser['nombreus'];
        $data['page_functions_js']="function_subcategorias.js";
        $data['page_añadir']=$Requestper[6]['añadir'];
        $data['page_verrol']=$Requestper[1]['ver'];
         $data['page_verusu']=$Requestper[2]['ver'];
         $data['page_verpro']=$Requestper[3]['ver'];
         $data['page_vercate']=$Requestper[4]['ver'];
         $data['page_verped']=$Requestper[5]['ver'];
         $data['page_versub']=$Requestper[6]['ver'];
         $data['page_vercli']=$Requestper[7]['ver'];
        $arrData = $this->model->selectCategorias();
        $cadena = '<select  id = "Listsubca" name = "Listsubca"  class="form-control">';
        
        for($i=0; $i < count($arrData);$i++){
        $cadena = $cadena.'<option value="'.$arrData[$i]['idca'].'">'.$arrData[$i]['categoria'].'</option>' ;
        }
        $cadena.'</select>';
        
        $data['select'] = $cadena;
        
        $this->views->getView($this,"subcategoria",$data);
    }
   public function getsubCategoria(int $idrol){
        $intIdrol = intval(strClean($idrol));
        if($intIdrol > 0){
          $arrData = $this->model->selectsubCategoria($intIdrol);
          $imagenes = $arrData['imagen'];
          $imagenes = str_replace("Assets/Images/subCategorias/", "", $imagenes);
          $arrData['imagenes'] = $imagenes;
        if(empty($arrData)){
          $arrResponse = array('status' => false,'msg'=>'Datos no encontrados.' ); 
        }else{
          $arrResponse = array('status' => true,'msg'=>$arrData ); 
        }        echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
      }
     die();
        }
    
    public function getsubCategorias(){
    $intIdca = intval($_POST['subidCa']);
    $foto = strClean($_POST['subfoto']);
    $strNombre = strClean($_POST['subtxtNombreca']);
    $strDesctipcion = strClean($_POST['subtxtDescripcionca']);
    $intStatus = intval($_POST['sublistStatusca']);
    $intcategoria = intval($_POST['Listsubca']);
    $valor = intval($_POST['subidCama']);
    $nombre = $_FILES['subimagenca']["name"];
    $rutap = $_FILES['subimagenca']["tmp_name"];
    $tipo = $_FILES['subimagenca']["type"];
    $tamaño = $_FILES['subimagenca']["size"];
    $carpeta = "Assets/Images/subCategorias/";
    $src = $carpeta.$nombre;
    
    if($nombre != ""){
     $image = getimagesize($_FILES['subimagenca']["tmp_name"]);    //Sacamos la información
    $ancho = $image[0];
    $alto=$image[1];
    }else{
        $ancho = "";
        $alto = "";
    }
    if($tipo == "image/JPG" || $tipo == "image/jpeg" || $tipo == "image/png" || $tipo == "image/jpg" || empty($tipo)){
    if($tamaño < 5500000){
    if($ancho == 1200  && $alto == 809 || $src == "Assets/Images/subCategorias/"){
    if($intIdca == 0){
    $request_categoria = $this->model->insertsubCategoria($strNombre,$strDesctipcion,$intStatus,$src,$intcategoria);
    $opcion = 1;
    }else{
    $request_categoria = $this->model->updatesubCategoria($intIdca,$strNombre,$strDesctipcion,$intStatus,$src,$valor,$foto,$intcategoria);
    $opcion = 2;    
    }
    if ($request_categoria >0){
       if($opcion == 1){
       $arraData = array('status' => true,'msg'=>'Se ha guardadao correctamente los Datos.');   
        move_uploaded_file($rutap,$src);
      }else{
         $arraData = array('status' => true,'msg'=>'Se ha Actualizado correctamente los Datos.');   
        move_uploaded_file($rutap,$src);
      }
    } else if($request_categoria == "exist"){
       $arraData = array('status' => false,'msg'=>'Ya existe esa Categoria.'); 
       
    }
    else if($request_categoria == "ok"){
       $arraData = array('status' => false,'msg'=>'La Imagen con ese nombre ya existe.'); 
       
    }
    }else{
      $arraData = array('status' => false,'msg'=>'La imagen debe ser maximo de 1200px de ancho y 809px de alto');    
    }
    }
    else{
       $arraData = array('status' => false,'msg'=>'el Tamaño maximo es de 5mb');  
    }
    }else{
       $arraData = array('status' => false,'msg'=>'No es formato jpg, npj o jpeg');  
    }
    echo json_encode($arraData,JSON_UNESCAPED_UNICODE);
    die(); 
    
    }
    
    public function setsubCategorias(){
    $arrData = $this->model->selectsubCategorias(); 
    $idus = $_SESSION['idUser'];
    $RequestUser = $this->model->selectUsuario($idus);
    $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
    for($i=0; $i < count($arrData);$i++){
        $categorias = $this->model->selectCategoria($arrData[$i]['idca']);
        $arrData[$i]['categorias']=$categorias['categoria'];
    if($arrData[$i]['status'] == 1){
     $arrData[$i]['status']='<span class="badge badge-success">Activo'; 
        ;}else{
             $arrData[$i]['status']='<span class="badge badge-danger">Inactivo'; 
        }
        if($arrData[$i]['imagen'] == "Assets/Images/subCategorias/"){
           $arrData[$i]['imagen']='<img style="height:50px; width: auto;" src="Assets/Images/Categorias/Implementos/caja.jpg">'; 
        }else{
          $arrData[$i]['imagen']='<img style="height:40px;" src="'.$arrData[$i]['imagen'].'">';  
        }
        
        $cadena='<div class="text-center">';
        if($Requestper [6]['editar']== 1){
        $cadena = $cadena.'<button  class="btn btn-info btn-sm btnEditsubCategoria"  rl="'.$arrData[$i]['idsubca'].'" title="Editar"><i class="fa fa-pencil" aria-hidden="true"></i></button>';
        }if($Requestper [6]['eliminar']== 1){
        $cadena = $cadena.'<button class="btn btn-danger btn-sm  btnDesubCategoria" rl="'.$arrData[$i]['idsubca'].'" title="Eliminar"><i class="fa fa-trash" aria-hidden="true"></i></button>
        </div>';}
        if($Requestper [6]['editar']== 0 && $Requestper [6]['eliminar']== 0){
         $cadena = "=(";  
        }
        $arrData[$i]['options']=$cadena;
        }
        
        
    echo json_encode($arrData,JSON_UNESCAPED_UNICODE);
    die();

   }
   
   public function DelsubCategoria (){
      if($_POST){
          
           $intIdCategoria = intval($_POST['subidCa']);
           $request = $this->model->selectsubCategoria($intIdCategoria);
           $foto = $request['imagen'];
           $requestDelete = $this->model->deletesubCategoria($intIdCategoria);
           if($requestDelete == 'ok'){
               if($foto != "Assets/Images/subCategorias/"){
                unlink($foto);    
              }
             $arrResponse = array('status' => true, 'msg' => 'Se ha eliminado la SubCategoria');
           }else if($requestDelete == 'exist'){
            $arrResponse = array('status' => false, 'msg' => 'Error al eliminar la SubCategoria');
           }else if($requestDelete == "si"){
           $arrResponse = array('status' => false,'msg'=>'No es posible Eliminar la SubCategoria asociado a un Producto.'); 
       
           }
           
           
           echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
          }
          die(); 
   }
   
}