<?php


class Clientes extends Controllers{
    public function __construct() {
        parent:: __construct();  
        session_start();
        if(empty($_SESSION['login'])){
            header('location:'.base_url().'home');
        }
        if(isset($_SESSION['idUser'])){
         $User = $this->model->selectUsuario($_SESSION['idUser']);   
            if($User['rolid'] == 1){
            header('location:'.base_url().'home');
        }}
        ; }
    public function clientes (){
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
                $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $añadir=$Requestper[3]['añadir'];
        $data['page_rol'] = $RequestRol['nombrerol'];
        $data['page_name'] = $RequestUser['nombreus'];
        $data['page_tag']='Clientes';
       $data['page_admin']='Manuel Romero';
       $data['page_añadir']=$añadir;
       $data['page_verrol']=$Requestper[1]['ver'];
         $data['page_verusu']=$Requestper[2]['ver'];
         $data['page_verpro']=$Requestper[3]['ver'];
         $data['page_vercate']=$Requestper[4]['ver'];
         $data['page_verped']=$Requestper[5]['ver'];
         $data['page_versub']=$Requestper[6]['ver'];
         $data['page_vercli']=$Requestper[7]['ver'];
        $this->views->getView($this,"clientes",$data);
    }
}
