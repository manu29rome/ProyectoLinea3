<?php

class Home extends Controllers {
    public function __construct() {
        parent:: __construct();  
        session_start();
        
        ; }
    public function home(){
        
        $data['page_id']='1';
        $data['page_tag']='Home';
        $data['page_title'] = "PAGINA PRINCIPAL";
        $data['page_name']="home";
        $data['page_functions_js']="function_homes.js";
        
        $datos = $this->model->selectCategorias();
        $cadena = "";
        $i = 0;
        for($i=0; $i < count($datos);$i++){
        $cadena = $cadena.'<div class="col-md-6 col-xl-4 p-b-30 m-lr-auto">';
        $cadena = $cadena.'<div class="block1 wrap-pic-w">';
        if($datos[$i]['imagen'] != "Assets/Images/Categorias/"){
        $cadena = $cadena.'<img src="'.$datos[$i]['imagen'].'" alt="IMG-BANNER">';
        }else{
        $cadena = $cadena.'<img src="Assets/Images/uploads/Emote.jpg" alt="IMG-BANNER">'; }
        $cadena = $cadena.'<a  class="block1-txt ab-t-l s-full flex-col-l-sb p-lr-38 p-tb-34 trans-03 respon3">';
        $cadena = $cadena.'<div class="block1-txt-child1 flex-col-l">';
        $cadena = $cadena.'<span class="block1-name ltext-102 trans-04 p-b-8">';
        $cadena = $cadena.$datos[$i]['categoria'];
        $cadena = $cadena.'</span>';
        $cadena = $cadena.'<span class="block1-info stext-102 trans-04">';
        $cadena = $cadena.$datos[$i]['descripcionca'];
        $cadena = $cadena.'</span>';
        $cadena = $cadena.'</div>';
        $cadena = $cadena.'<div class="block1-txt-child2 p-b-4 trans-05">';
        $cadena = $cadena.'<div class="block1-link stext-101 cl0 trans-09">';
        $cadena = $cadena.'<button  class=" btnEditCategoria"  rl="'.$datos[$i]['idca'].'" title="Editar"><span style="color:white">Compra Ahora</span></button>';
        $cadena = $cadena.'</div>';
        $cadena = $cadena.'</div>';
        $cadena = $cadena.'</a>';
        $cadena = $cadena.'</div>';
        $cadena = $cadena.'</div>';
        }
         $data['select'] = $cadena;
        
         $cadena2 = "";
        $productos = $this->model->selectProductos(); 
        for($i=0; $i < count($productos);$i++){
        $imagen = $this->model-> selectProductoImagen($productos[$i]['codigo']);
        $cadena2 = $cadena2.'<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item m '.$productos[$i]['idca'].'">';
        $cadena2 = $cadena2.'<div class="block2">';
        $cadena2 = $cadena2.'<div class="block2-pic hov-img0">';
        if(empty($imagen[0]['imagen'])){
        $cadena2 = $cadena2.'<img src="Assets/Images/uploads/Emote2.jpg" alt="IMG-BANNER">';;
        }else{
        $cadena2 = $cadena2.'<img src="'.$imagen[0]['imagen'].'" alt="IMG-PRODUCT">';}
        $cadena2 = $cadena2.'<a  class="block2-btn flex-c-m stext-101 cl0 size-107 bg3 bor2 hov-btn3 p-lr-15 trans-04 m-b-10">';
        $cadena2 = $cadena2.'<button  class=" js-show-modal1 "  rl="'.$productos[$i]['idpro'].'""><span style="color: white">COMPRAR</span></button>';
        $cadena2 = $cadena2.'</a></div>';
        $cadena2 = $cadena2.'<div class="block2-txt flex-w flex-t p-t-14">';
        $cadena2 = $cadena2.'<div class="block2-txt-child1 flex-col-l ">';
        $cadena2 = $cadena2.'<a href="product-detail.html" class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6">';
        $cadena2 = $cadena2.$productos[$i]['producto'];
        $cadena2 = $cadena2.'</a><span class="stext-105 cl3">';
        $cadena2 = $cadena2.'<strong>COP </strong>'.formaMoney($productos[$i]['precio']);
        $cadena2 = $cadena2.'</span></div>';
        $cadena2 = $cadena2.'<div class="block2-txt-child2 flex-r p-t-3">';
        $cadena2 = $cadena2.'<a href="#" class="btn-addwish-b2 dis-block pos-relative js-addwish-b2">';
        $cadena2 = $cadena2.'<img class="icon-heart2 dis-block trans-04 ab-t-l" src="Assets/tienda/images/icons/icon-heart-02.png" alt="ICON">';
        $cadena2 = $cadena2.'</a></div></div></div></div>';
        }
        $data['productos'] = $cadena2;
        
        $cadena3 = "";
        
        $subcategoria = $this->model->selectsubCategorias(); 
        for($i=0; $i < count($subcategoria);$i++){
        $cadena3 = $cadena3.'<button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5 "  data-filter=".'.$subcategoria[$i]['idsubca'].'">'; 
        $cadena3 = $cadena3.$subcategoria[$i]['subcategoria']; 
        $cadena3 = $cadena3.'</button>'; 
        }
        $data['subcategoria'] = $cadena3;
        
        $cadena4 = "";
        for($i=0; $i < count($datos);$i++){
        $cadena4 = $cadena4.'<li class="p-b-10">';
        $cadena4 = $cadena4.'<a href="#" class="stext-107 cl7 hov-cl1 trans-04">'; 
        $cadena4 = $cadena4.$datos[$i]['categoria'];
        $cadena4 = $cadena4.'</a></li>'; 
        }
        $data['listaca'] = $cadena4;
        
        $cadena5 = "";
        for($i=0; $i < count($subcategoria);$i++){
        $cadena5 = $cadena5.'<li class="p-b-10">';
        $cadena5 = $cadena5.'<a href="#" class="stext-107 cl7 hov-cl1 trans-04">'; 
        $cadena5 = $cadena5.$subcategoria[$i]['subcategoria'];
        $cadena5 = $cadena5.'</a></li>'; 
        }
        $data['listasubca'] = $cadena4;
        
        if(empty($_SESSION['idUser'])){
        $data['usuario'] = "vacio";
        $data['nombre'] = "0"; 
        $data['rol'] = "1";
        }else{
           
        $data['usuario'] = $_SESSION['idUser'];
        $usuario = $this->model->selectUsuario($data['usuario']); 
        $data['nombre'] = $usuario['nombreus'];
        $data['rol'] = $usuario['rolid'];
          }
       $total = 0;
       $cadena6 = "";
       
       if(isset($_SESSION['idUser'])){
       $carrito = $this->model->selectCarrito($_SESSION['idUser']);
       if(isset($carrito)){
       for($i=0; $i < count($carrito);$i++){
       $producto = $this->model->selectProducto($carrito[$i]['idpro']); 
       $image = $this->model-> selectProductoImagen($producto['codigo']);
       $cadena6 = $cadena6.'<li class="header-cart-item flex-w flex-t m-b-12">';
       $cadena6 = $cadena6.'<div class="header-cart-item-img">';
       if(isset($image[0]['imagen'])){ 
           $cadena6 = $cadena6.'<img src="'.$image[0]['imagen'].'" alt="IMG"></div>'; }
       else{ 
           $cadena6 = $cadena6.'<img src="Assets/Images/uploads/Emote2.jpg" alt="IMG"></div>'; }
       $cadena6 = $cadena6.'<div class="header-cart-item-txt p-t-8">';
       $cadena6 = $cadena6.'<a href="#" class="header-cart-item-name m-b-18 hov-cl1 trans-04">';
       $cadena6 = $cadena6.$producto['producto'];
       $cadena6 = $cadena6.'</a><span class="header-cart-item-info">';
       $cadena6 = $cadena6.$carrito[$i]['cantidad'].' x '.formaMoney($producto['precio']).' COP';
       $cadena6 = $cadena6.'</span></div></li>';
       $total = $total+($carrito[$i]['cantidad']*$producto['precio']);
       }
       }else if(empty($carrito)){
         $cadena6 = $cadena6.'No tienes todavia articulos en tu Carrito';  
       }
       $data['total'] = formaMoney($total).' COP';
       if(empty($carrito)){
        $data['carri'] = "0";   
       }else{
        $data['carri'] = count($carrito);   
       }
       
       $data['carrito'] = $cadena6;
       }
       
       
      
        $this->views->getView($this,"home",$data);
    }
       
        public function getProducto(string $idrol){
        $intIdrol = intval($idrol);
        if($intIdrol > 0){
          $arrData = $this->model->selectProducto($intIdrol);
         $arrData['valor'] = formaMoney($arrData['precio']);
          $Data = $this->model->selectProductoImagen($arrData['codigo']);
          									
	 $cadena = '';	
         $cadena = $cadena.'<div class="wrap-slick3-dots"> </div>'; 
          $cadena = $cadena.' <div class="wrap-slick3-arrows flex-sb-m flex-w" id="boton"> </div>'; 
          $cadena = $cadena.'<div class="slick3 gallery-lb">';
         
          if(empty($Data)){  
              
          
          $cadena = $cadena.'<div class="item-slick3" data-thumb="Assets/Images/uploads/Emote2.jpg">';
          $cadena = $cadena.'<div class="wrap-pic-w pos-relative">';
          $cadena = $cadena.'<img src="Assets/Images/uploads/Emote2.jpg" alt="IMG-PRODUCT">';
          $cadena = $cadena.'</a></div></div>';
          
          }else{
          for($i=0; $i < count($Data);$i++){
          $cadena = $cadena.'<div class="item-slick3" data-thumb="'.$Data[$i]['imagen'].'">';
          $cadena = $cadena.'<div class="wrap-pic-w pos-relative">';
          $cadena = $cadena.'<img src="'.$Data[$i]['imagen'].'" alt="IMG-PRODUCT">';
          $cadena = $cadena.'</a></div></div>';    
          }
          
          }
          $cadena = $cadena.'</div>';
          $arrData['imagenes']= $cadena;
        
        if(empty($arrData)){
          $arrResponse = array('status' => false,'msg'=>'Datos no encontrados.' ); 
        }else{
          $arrResponse = array('status' => true,'msg'=>$arrData ); 
        }  }else{
            $arrResponse = array('status' => false,'msg'=>'Error.' ); 
        }
      echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
     die();
        }
    
        public function getProductos(){
            if(isset($_SESSION['idUser'])){
            $intIdpro = intval($_POST['idpro']);
            $intCantidad = intval($_POST['num-product']);
            $producto = $this->model->selectCarritos($intIdpro);
            
            if(empty($producto)){
            $request_categoria = $this->model->insertCarrito($intIdpro,$intCantidad,$_SESSION['idUser']);
            if ($request_categoria > 0){
                $arraData = array('status' => true,'msg'=>'Se Añadio correctamente al carrito.');
            }else if($request_categoria == "mayor"){
              $arraData = array('status' => false,'msg'=>'cantidad no existente.');  
            }
            }else{
              $arraData = array('status' => false,'msg'=>'este producto ya se encuentra añadido en el carrito');  
            }
            }else{
              $arraData = array('status' => false,'msg'=>'Antes de Añadir articulos a tu carrito primero inicie sesion.');     
            }
            
            echo json_encode($arraData,JSON_UNESCAPED_UNICODE);
           die(); 
        }
        
        public function getAcutualizar(){
       $total = 0;
       $cadena6 = "";
       $carrito = $this->model->selectCarrito($_SESSION['idUser']);
       if(isset($carrito)){
       for($i=0; $i < count($carrito);$i++){
       $producto = $this->model->selectProducto($carrito[$i]['idpro']); 
       $image = $this->model-> selectProductoImagen($producto['codigo']);
       $cadena6 = $cadena6.'<li class="header-cart-item flex-w flex-t m-b-12">';
       $cadena6 = $cadena6.'<div class="header-cart-item-img">';
       if(isset($image[0]['imagen'])){ 
           $cadena6 = $cadena6.'<img src="'.$image[0]['imagen'].'" alt="IMG"></div>'; }
       else{ 
           $cadena6 = $cadena6.'<img src="Assets/Images/uploads/Emote2.jpg" alt="IMG"></div>'; }
       $cadena6 = $cadena6.'<div class="header-cart-item-txt p-t-8">';
       $cadena6 = $cadena6.'<a href="#" class="header-cart-item-name m-b-18 hov-cl1 trans-04">';
       $cadena6 = $cadena6.$producto['producto'];
       $cadena6 = $cadena6.'</a><span class="header-cart-item-info">';
       $cadena6 = $cadena6.$carrito[$i]['cantidad'].' x '.formaMoney($producto['precio']).' COP';
       $cadena6 = $cadena6.'</span></div></li>';
       $total = $total+($carrito[$i]['cantidad']*$producto['precio']);
       }
       }else if(empty($carrito)){
         $cadena6 = $cadena6.'No tienes todavia articulos en tu Carrito';  
       }
       $arrdata['total'] = formaMoney($total).' COP';
       if(empty($carrito)){
        $arrdata['carri'] = "0";   
       }else{
        $arrdata['carri'] = count($carrito);   
       }
       $arrdata['carrito'] = $cadena6; 
        $arraData = array('status' => true,'msg'=>$arrdata);
        
       echo json_encode($arraData,JSON_UNESCAPED_UNICODE);
           die(); 
        }
}