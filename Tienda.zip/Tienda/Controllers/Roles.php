<?php
class Roles extends Controllers {
    public function __construct() {
        parent:: __construct();  
        session_start();
        if(empty($_SESSION['login'])){
            header('location:'.base_url().'home');
        }
        
        if(isset($_SESSION['idUser'])){
         $User = $this->model->selectUsuario($_SESSION['idUser']);   
            if($User['rolid'] == 1){
            header('location:'.base_url().'home');
        }else{
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
        $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $permiso = $Requestper[1]['ver'];
        if($permiso == 0){
          header('location:'.base_url().'dashboard');  
        }}}
        ; }
    public function Roles(){
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
         $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $data['page_rol'] = $RequestRol['nombrerol'];
        $data['page_functions_js']="function_rol.js";
        $data['page_id']='3';
        $data['page_tag']='Roles Usuarios';
        $data['page_name'] = $RequestUser['nombreus'];
        $data['page_title']="Roles usuarios <small>Tienda Virtual</small>";
        $data['page_añadirrol']=$Requestper[1]['anadir'];
         $data['page_editarrol']=$Requestper[1]['editar'];
          $data['page_eliminarrol']=$Requestper[1]['eliminar'];
          
        $data['page_verrol']=$Requestper[1]['ver'];
         $data['page_verusu']=$Requestper[2]['ver'];
         $data['page_verpro']=$Requestper[3]['ver'];
         $data['page_vercate']=$Requestper[4]['ver'];
         $data['page_verped']=$Requestper[5]['ver'];
         $data['page_versub']=$Requestper[6]['ver'];
         $data['page_vercli']=$Requestper[7]['ver'];
         
        $this->views->getView($this,"roles",$data);
    }
    public function   getPermisos(int $idrol){
        $arrData = $this->model->selectpermiso($idrol );
        for($i=0; $i < count($arrData);$i++){
        if($arrData[$i]['ver'] == 1){
        $arrData[$i]['ver']= '<div name="btnV'.$arrData[$i]['idper'].'" id="btnV'.$arrData[$i]['idper'].'"><button value="1" rl="'.$arrData[$i]['idper'].'" class="btn btn-info btn-sm btnVer"><i class="fa fa-toggle-on" aria-hidden="true"></i></button></div>';
            ;}else{
        $arrData[$i]['ver']= '<div name="btnV'.$arrData[$i]['idper'].'" id="btnV'.$arrData[$i]['idper'].'"><button value="0" rl="'.$arrData[$i]['idper'].'" class="btn btn-secondary btn-sm btnVer" ><i class="fa fa-toggle-off" aria-hidden="true"></i></button></div>';
            } 
        if($arrData[$i]['editar'] == 1){
        $arrData[$i]['editar']= '<div id="btnEd'.$arrData[$i]['idper'].'"><button value="1" rl="'.$arrData[$i]['idper'].'" class="btn btn-info btn-sm btnEd" ><i class="fa fa-toggle-on" aria-hidden="true"></i></button></div>';
            ;}else{
        $arrData[$i]['editar']= '<div id="btnEd'.$arrData[$i]['idper'].'"><button value="0" rl="'.$arrData[$i]['idper'].'" class="btn btn-secondary btn-sm btnEd "><i class="fa fa-toggle-off" aria-hidden="true"></i></button></div>';
            }
        if($arrData[$i]['anadir'] == 1){
        $arrData[$i]['anadir']= '<div id="btnAña'.$arrData[$i]['idper'].'"><button value="1" rl="'.$arrData[$i]['idper'].'" class="btn btn-info btn-sm btnAñadir"><i class="fa fa-toggle-on" aria-hidden="true"></i></button></div>';
            ;}else{
        $arrData[$i]['anadir']= '<div id="btnAña'.$arrData[$i]['idper'].'"><button value="0" rl="'.$arrData[$i]['idper'].'" class="btn btn-secondary btn-sm btnAñadir"><i class="fa fa-toggle-off" aria-hidden="true"></i></button></div>';
            }
        if($arrData[$i]['eliminar'] == 1){
        $arrData[$i]['eliminar']= '<div id="btnEli'.$arrData[$i]['idper'].'"><button value="1" rl="'.$arrData[$i]['idper'].'" class="btn btn-info btn-sm btnEliminar"><i class="fa fa-toggle-on" aria-hidden="true"></i></button></div>';
            ;}else{
        $arrData[$i]['eliminar']= '<div id="btnEli'.$arrData[$i]['idper'].'"><button value="0" rl="'.$arrData[$i]['idper'].'" class="btn btn-secondary btn-sm btnEliminar"><i class="fa fa-toggle-off" aria-hidden="true"></i></i></button></div>';
            }
        
        } 
        echo json_encode($arrData,JSON_UNESCAPED_UNICODE);
        die();
        
    }
    public function getRol(int $idrol){
        $intIdrol = intval(strClean($idrol));
        if($intIdrol > 0){
          $arrData = $this->model->selectRol($intIdrol);
        if(empty($arrData)){
          $arrResponse = array('status' => false,'msg'=>'Datos no encontrados.' ); 
        }else{
          $arrResponse = array('status' => true,'msg'=>$arrData ); 
        }        echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
      }
     die();
        }

        public function getRoles(){
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
         $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
         
        $arrData = $this->model->selectRoles();
        
        for($i=0; $i < count($arrData);$i++){
        if($arrData[$i]['status'] == 1){
         $arrData[$i]['status']='<span class="badge badge-success">Activo'; 
            ;}else{
                 $arrData[$i]['status']='<span class="badge badge-danger">Inactivo'; 
            }
            if($Requestper[1]['editar']+$Requestper[1]['eliminar'] != 0){
            $cadena ='<div class="text-center">';
            if($Requestper[1]['editar'] == 1){
            $cadena = $cadena.'<button class="btn btn-secondary btn-sm  btnPermisosRol" rl="'.$arrData[$i]['idrol'].'" title="Permisos"><i class="fa fa-key" aria-hidden="true"></i></button>
                    <button  class="btn btn-info btn-sm btnEditRol"  rl="'.$arrData[$i]['idrol'].'" title="Editar"><i class="fa fa-pencil" aria-hidden="true"></i></button>';
            }if($Requestper[1]['eliminar'] == 1){
            $cadena = $cadena.'<button  class="btn btn-danger btn-sm  btnDelRol" rl="'.$arrData[$i]['idrol'].'" title="Eliminar"><i class="fa fa-trash" aria-hidden="true"></i></button>
                               </div>';
            } 
            $arrData[$i]['options']=$cadena;
        }else{
            $cadena = '<span><i class="fa fa-frown-o" aria-hidden="true"></i></span>';
            $arrData[$i]['options']=$cadena;
        }
        
            }
        echo json_encode($arrData,JSON_UNESCAPED_UNICODE);
        die();
    }
    
    public function setPerVer() {
     $intIdRol = intval($_POST["idRol2"]);
     $ver = intval($_POST["boton"]);
     $request_ver = $this->model->updatePerVer($intIdRol,$ver);
    }
    public function setPerEditar() {
     $intIdRol = intval($_POST["idRol2"]);
     $editar = intval($_POST["boton"]);
     $request_ver = $this->model->updatePerEditar($intIdRol,$editar);
    }
    public function setPerEliminar() {
     $intIdRol = intval($_POST["idRol2"]);
     $eliminar = intval($_POST["boton"]);
     $request_ver = $this->model->updatePerEliminar($intIdRol,$eliminar);
    }
    public function setPerAñadir() {
     $intIdRol = intval($_POST["idRol2"]);
     $anadir = intval($_POST["boton"]);
     $request_ver = $this->model->updatePerAñadir($intIdRol,$anadir);
    }
    
    public function setRol(){
        $intIdRol = intval($_POST["idRol"]);
        $strRol= strClean($_POST["txtNombre"]);
        $strDescripcion= strClean($_POST["txtDescripcion"]);
        $intStatus= intval($_POST["listStatus"]);
        $opcion0 = "Inicio";
        $opcion1 = "rol";
        $opcion2 = "usuario";
        $opcion3 = "productos";
        $opcion4 = "categorias";
        $opcion5 = "pedidos";
        $opcion6 = "subcategorias";
        $opcion7 = "clientes";
        
        $ver = 0;
        $editar = 0;
        $eliminar = 0;
        $anadir = 0;
        
        if($intIdRol == 0){
          $request_rol = $this->model->insertRol($strRol,$strDescripcion,$intStatus);
          $option = 1;
          $request_per = $this->model->selectRolnombre($strRol);
          $nombre = $request_per['idrol'];
          if(isset($nombre)){
          $request_rols = $this->model->insertPermisos($opcion0,$ver,$editar,$eliminar,$anadir,$nombre);
          $request_rols = $this->model->insertPermisos($opcion1,$ver,$editar,$eliminar,$anadir,$nombre);  
          $request_rols = $this->model->insertPermisos($opcion2,$ver,$editar,$eliminar,$anadir,$nombre); 
          $request_rols = $this->model->insertPermisos($opcion3,$ver,$editar,$eliminar,$anadir,$nombre);  
          $request_rols = $this->model->insertPermisos($opcion4,$ver,$editar,$eliminar,$anadir,$nombre);
          $request_rols = $this->model->insertPermisos($opcion5,$ver,$editar,$eliminar,$anadir,$nombre); 
          $request_rols = $this->model->insertPermisos($opcion6,$ver,$editar,$eliminar,$anadir,$nombre); 
          $request_rols = $this->model->insertPermisos($opcion7,$ver,$editar,$eliminar,$anadir,$nombre); 
          }
          
        }else{
          $request_rol = $this->model->updateRol($intIdRol,$strRol,$strDescripcion,$intStatus);
          $option = 2;
        }
    
        if($request_rol > 0){
          if($option == 1){
            $arrResponse =array('status' => true,'msg'=>'Datos guardados correctamente.');
          }else{
            $arrResponse =array('status' => true,'msg'=>'Datos Actualizados correctamente.');
          }
           
        }else if($request_rol == "exist"){
           $arrResponse =array('status' => false,'msg'=>'¡Arencion! El rol ya existe.'); 
        }else{
             $arrResponse =array('status' => false,'msg'=>'No es posible almacenar los datos.');
        }
        echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        die();
        

        }
        
        public function deleteEvento(){
          if($_POST){
           $intIdRol = intval($_POST['idRol']);
           $requestDelete = $this->model->deleteRol($intIdRol);
           if($requestDelete == 'ok'){
             $arrResponse = array('status' => true, 'msg' => 'Se ha eliminado el Rol');
           }else if($requestDelete == 'exist'){
            $arrResponse = array('status' => false, 'msg' => 'Error al eliminar el Rol');
           }else{
            $arrResponse = array('status' => false, 'msg' => 'No es posible Eliminar el Rol asociado a usuarios');
           }
           
           echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
          }
          die();
        }
    }

    
    
?>