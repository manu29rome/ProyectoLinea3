<?php


class Sesion extends Controllers {
    public function __construct() {
        parent:: __construct();  
        session_start();
        ; }
   
 public function sesion(){
 
$data['page_functions_js']="function_sesion.js";
$data['page_tag']='Registro';
$datos = $this->model->selectCategorias();
$subcategoria = $this->model->selectsubCategorias();
$cadena4 = "";
        for($i=0; $i < count($datos);$i++){
        $cadena4 = $cadena4.'<li class="p-b-10">';
        $cadena4 = $cadena4.'<a href="#" class="stext-107 cl7 hov-cl1 trans-04">'; 
        $cadena4 = $cadena4.$datos[$i]['categoria'];
        $cadena4 = $cadena4.'</a></li>'; 
        }
        $data['listaca'] = $cadena4;
        
        $cadena5 = "";
        for($i=0; $i < count($subcategoria);$i++){
        $cadena5 = $cadena5.'<li class="p-b-10">';
        $cadena5 = $cadena5.'<a href="#" class="stext-107 cl7 hov-cl1 trans-04">'; 
        $cadena5 = $cadena5.$subcategoria[$i]['subcategoria'];
        $cadena5 = $cadena5.'</a></li>'; 
        }
        $data['listasubca'] = $cadena4;
        
        $data['usuario'] = "vacio";
        $data['nombre'] = "0"; 
        $data['rol'] = "1";
  $this->views->getView($this,"sesion",$data);   
 }
 
  public function loginUser(){
      if($_POST){
        if(empty($_POST['txtEmail']) || empty($_POST['txtContraseña'])){
            $arrResponse = array('status' => false, 'msg' => 'Error de datos');
        }else{
            $strUsuario = strtolower(strClean($_POST['txtEmail']));
            $strContraseña = strClean($_POST['txtContraseña']);
            $contra = encriptar($strContraseña);
            if(!isEmail($strUsuario)){ 
                $arrResponse = array('status' => false, 'msg' => 'Ingrese un Email Valido'); 
            }else{
            $RequestUser = $this->model->loginUser($strUsuario,$contra);
            if(empty($RequestUser)){
             $arrResponse = array('status' => false, 'msg' => 'El Usuario y/o Contraseña son Incorrectos');   
            }else{
                $arrData = $RequestUser;
                if($arrData['status'] == 1){
                    $_SESSION['idUser'] = $arrData['idus'];
                    $_SESSION['login']= true;
                    $asunto = 'Aviso de Ingreso';
                     $descripcion   = 'Se ha inicia sesion en su cuenta de serviplass';
                    $de = 'From: surtiplass2022@gmail.com';
                    $respon = mail($_POST['txtEmail'], $asunto, $descripcion, $de);
                    $arrResponse = array('status' => true, 'msg' => 'ok');  
                }else{
                    $arrResponse = array('status' => false, 'msg' => 'El Usuario Inactivo'); 
                }
            }
        }  
        }   
        echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
     }
       die();
    }
  
     public function getUsuario(){
    
    $strNombre= strClean($_POST["txtnombre"]);
    $strApellido= strClean($_POST["txtapellido"]);
    $strEmail= strClean($_POST["txtemail"]);
    $intTelefono= intval($_POST["txttelefono"]);
    $intIdentificacion= intval($_POST["txtidentificacion"]);
    $strcontra = strClean($_POST["contraseñareset"]);
    
    $mayuscula = 0;
    $minuscula = 0;
    $numero = 0;
    $simbolo = 0;
    
    for($i = 0; $i < strlen($strcontra); $i++){
            
            if(!preg_match('`[a-z]`',$strcontra[$i]))
                $minuscula = $minuscula +0;
            else
                $minuscula = $minuscula +1;
            
            if(!preg_match('`[A-Z]`',$strcontra[$i]))
                $mayuscula = $mayuscula +0;
            else
                $mayuscula = $mayuscula +1;
            
            if(!preg_match('`[0-9]`',$strcontra[$i]))
                $numero = $numero +0;
            else
                $numero = $numero +1;
            
            if(preg_match('`[A-Za-z0-9]`',$strcontra[$i]))
                $simbolo = $simbolo +0;
            else
                $simbolo = $simbolo +1;
        }
        if ($minuscula == 0)
        {
            $arrResponse =array('status' => false,'msg'=>'la contraseña no tiene ninguna minuscula');
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
            die();
        }
        
        if ($mayuscula == 0)
        {
            $arrResponse =array('status' => false,'msg'=>'la contraseña no tiene ninguna mayuscula');
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
            die();
        }
        
        if ($numero == 0)
        {
            $arrResponse =array('status' => false,'msg'=>'la contraseña no tiene ninguna caracter numerico');
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
            die();
        }
        
        if ($simbolo == 0)
        {
            $arrResponse =array('status' => false,'msg'=>'la contraseña no tiene ninguna caracter simbolo');
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
            die();
        }
        
        if (strlen($strcontra) < 11)
        {
            $arrResponse =array('status' => false,'msg'=>'la contraseña tiene que tener minimo 12 caracteres');
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
            die();
        }
    
        $strcontra = encriptar($strcontra);
        
    if(isEmail($strEmail)){
    $request_usuario = $this->model->insertUsuario($strNombre,$strApellido,$strEmail,$intTelefono,$strcontra,$intIdentificacion);
    
        
    
    if($request_usuario > 0){
        $arrResponse =array('status' => true,'msg'=>'Datos Guardados correctamente.'); 
       
    }else if($request_usuario == "exist"){
      $arrResponse =array('status' => false,'msg'=>'¡Atencion! El Numero de Identidad ya existe.');  
    }else if($request_usuario == "correo"){
      $arrResponse =array('status' => false,'msg'=>'¡Atencion! Correo electronico ya existe.');  
    }
    
    }else {
        $arrResponse =array('status' => false,'msg'=>'Email invalido.');   
    }
    echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
    die(); 
   }
    
   public function email(){ 
       $strEmail= strClean($_POST["txtEmailReset"]);
       
       if(isEmail($strEmail)){
           $asunto    = 'Recuperacion de contraseña';
        $pas = pasGenerator(12);
        $descripcion   = 'Su nueva contraseña es: '.$pas;
        $de = 'From: surtiplass2022@gmail.com';

        if (mail($strEmail, $asunto, $descripcion, $de))
        {
            $pas = encriptar($pas);
            try{
                $reponse = $this->model->Email($strEmail,$pas);
                $arrResponse =array('status' => true,'msg'=>'Correo enviado satisfactoriamente');
            } catch (Exception $ex) {
                $arrResponse =array('status' => false,'msg'=>'error '.$ex); 
            }
        }
        else
        {
            $arrResponse =array('status' => false,'msg'=>'El correo no pudo ser enviado');  
        }
       }
        else {
           $arrResponse =array('status' => false,'msg'=>'Email invalido.'); 
       }
       

        echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        die(); 
   }
}
