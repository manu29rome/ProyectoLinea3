<?php


class Compra extends Controllers {
    public function __construct() {
        parent:: __construct(); 
        session_start();
        
        if(empty($_SESSION['login'])){
         
            header('location:'.base_url().'home');
        }
        ; }
   
 public function compra(){
  $data['page_id']='4';
        $data['page_tag']='Facturas';
        $data['page_title'] = "PAGINA PRINCIPAL";
        $data['page_name']="facturas";
        $data['page_functions_js']="compra.js";
        $datos = $this->model->selectCategorias();
        
        $subcategoria = $this->model->selectsubCategorias(); 
         $cadena4 = "";
        for($i=0; $i < count($datos);$i++){
        $cadena4 = $cadena4.'<li class="p-b-10">';
        $cadena4 = $cadena4.'<a href="#" class="stext-107 cl7 hov-cl1 trans-04">'; 
        $cadena4 = $cadena4.$datos[$i]['categoria'];
        $cadena4 = $cadena4.'</a></li>'; 
        }
        $data['listaca'] = $cadena4;
        
        $cadena5 = "";
        for($i=0; $i < count($subcategoria);$i++){
        $cadena5 = $cadena5.'<li class="p-b-10">';
        $cadena5 = $cadena5.'<a href="#" class="stext-107 cl7 hov-cl1 trans-04">'; 
        $cadena5 = $cadena5.$subcategoria[$i]['subcategoria'];
        $cadena5 = $cadena5.'</a></li>'; 
        }
        $data['listasubca'] = $cadena4;
        
        if(empty($_SESSION['idUser'])){
        $data['usuario'] = "vacio";
        $data['nombre'] = "0"; 
        $data['rol'] = "1";
        $data['id'] = "0";
        }else{
           
        $data['usuario'] = $_SESSION['idUser'];
        $usuario = $this->model->selectUsuario($data['usuario']); 
        $data['nombre'] = $usuario['nombreus'];
        $data['rol'] = $usuario['rolid'];
          }
          $total = 0;
          $tota2 = 0;
       $cadena7 = "";
       $cadena6 = "";
       if(isset($_SESSION['idUser'])){
       $carrito = $this->model->selectCarrito($_SESSION['idUser']);
       if(isset($carrito)){
       for($i=0; $i < count($carrito);$i++){
       $producto = $this->model->selectProducto($carrito[$i]['idpro']); 
       $image = $this->model-> selectProductoImagen($producto['codigo']);
       $cadena6 = $cadena6.'<li class="header-cart-item flex-w flex-t m-b-12">';
       $cadena6 = $cadena6.'<div class="header-cart-item-img">';
       if(isset($image[0]['imagen'])){ 
           $cadena6 = $cadena6.'<img src="'.$image[0]['imagen'].'" alt="IMG"></div>'; }
       else{ 
           $cadena6 = $cadena6.'<img src="Assets/Images/uploads/Emote2.jpg" alt="IMG"></div>'; }
       $cadena6 = $cadena6.'<div class="header-cart-item-txt p-t-8">';
       $cadena6 = $cadena6.'<a href="#" class="header-cart-item-name m-b-18 hov-cl1 trans-04">';
       $cadena6 = $cadena6.$producto['producto'];
       $cadena6 = $cadena6.'</a><span class="header-cart-item-info">';
       $cadena6 = $cadena6.$carrito[$i]['cantidad'].' x '.formaMoney($producto['precio']).' COP';
       $cadena6 = $cadena6.'</span></div></li>';
       $total = $total+($carrito[$i]['cantidad']*$producto['precio']);
       
       $cadena7 = $cadena7.'<tr class="table_row"><td class="column-1"><div class="how-itemcart1">';
       if(isset($image[0]['imagen'])){
       $cadena7 = $cadena7.'<img src="'.$image[0]['imagen'].'" alt="IMG"></div>';}
       else{
        $cadena7 = $cadena7.'<img src="Assets/Images/uploads/Emote2.jpg" alt="IMG"></div>';}   
       
       $cadena7 = $cadena7.'</td><td class="column-2">'.$producto['producto'].'</td><td class="column-3">'.formaMoney($producto['precio']).' COP</td>';
       $cadena7 = $cadena7.'<td class="column-4">';
       $cadena7 = $cadena7.$carrito[$i]['cantidad'];
       $total2 = $carrito[$i]['cantidad']*$producto['precio'];
       $cadena7 = $cadena7.'</td>';
       $cadena7 = $cadena7.'<td class="column-5"> $'.formaMoney($total2).'</td>';
       $cadena7 = $cadena7.'<td class="column-6"><div style="width: 80px"><button type="button" class="btn btn-danger btn-sm ftnDelp"  rl="'.$carrito[$i]['idcarrito'].'" title="Editar"><i class="fa fa-trash" aria-hidden="true" ></i></button>  </div>  </td></tr>';
     
       }
       }else if(empty($carrito)){
         $cadena6 = $cadena6.'No tienes todavia articulos en tu Carrito';  
       }
       $data['total'] = formaMoney($total).' COP';
       if(empty($carrito)){
        $data['carri'] = "0";   
       }else{
        $data['carri'] = count($carrito);   
       }
       
       $data['carrito'] = $cadena6;
        $data['compra'] = $cadena7;
       }
       
       $departamentos= $this->model->selectDepartamentos();
       $cadena8 = "";
       $cadena8 =  $cadena8.'<select class="js-select2" name="time" id"de" onchange="mun();">';
       for($i=0; $i < count($departamentos);$i++){
       $cadena8 =  $cadena8.'<option value="'.$departamentos[$i]['id'].'">'.$departamentos[$i]['nombre'].'</option>';	
       }
       $cadena8 =  $cadena8.'</select>';
       $data['departamentos'] = $cadena8;
       
       
  $this->views->getView($this,"compra",$data);   
 }
    
 
 public function getComprar(){
     if(isset($_SESSION['idUser'])){
         $p = intval($_POST['np']);
         $total = 0;
         $n = "";
         $nombre = "";
         
     $carrito = $this->model->selectCarrito($_SESSION['idUser']);    
     for($i=0; $i < count($carrito);$i++){
     $producto = $this->model->selectProducto($carrito[$i]['idpro']);
     if($producto['stock'] < $carrito[$i]['cantidad']){  
       $nombre = $nombre.$producto['producto'];
     }
     }
     
     if(empty($nombre)){
     for($i=0; $i < count($carrito);$i++){
     $producto = $this->model->selectProducto($carrito[$i]['idpro']);  
     $total = $producto['stock'] - $carrito[$i]['cantidad'];
     $request = $this->model->updateProducto($total,$carrito[$i]['idpro']);
     $status= $this->model->updateCompra($carrito[$i]['idpro']);
     }
     if($request > 0){
     $arrResponse =array('status' => true,'msg'=>'Compra correctamente.');    
     }else{
     $arrResponse =array('status' => false,'msg'=>'¡Atencion! ya no se encuentra la cantidad de estos productos.');
     }
     
     }else{
     $arrResponse =array('status' => false,'msg'=>'¡Atencion! ya no se encuentra la cantidad de estos productos '.$nombre.'.');
     }
        
     echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
     die(); 
     }
 }
 
 public function getciudad(){
     $p = intval($_POST['time']);
     $arrData = $this->model->selectmun($p);
        $cadena = '<select  id = "mu" name = "mu"  class="form-control">';
        for($i=0; $i < count($arrData);$i++){
        $cadena = $cadena.'<option value="'.$arrData[$i]['id'].'">'.$arrData[$i]['nombre'].'</option>' ;
        }
        $cadena.'</select>';
        $data['p'] = $cadena;
        $arraData = array('status' => true,'msg'=>$data );
        
        echo json_encode($arraData,JSON_UNESCAPED_UNICODE);
    die(); 
 }
 
 public function del(){
     if($_POST){
          
           $intPro = intval($_POST['subidCa']);
           $requestDelete = $this->model->deleteProducto($intPro);
           
         if($requestDelete == 'ok'){
         $arrResponse = array('status' => true, 'msg' => 'Se ha eliminado el Producto');}
           else if($requestDelete == 'exist'){
            $arrResponse = array('status' => false, 'msg' => 'Error al eliminar el Producto');
           }
           echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
     }
          die(); 
 }
 public function codigo(){
     $datos = $this->model->selecCodigo();
     $total = count($datos)-1;
     $cod= $datos[$total]['codigo'];
     $dato['cod'] = $cod+1;
     $guardar = $this->model->Codigo($dato['cod']);
     $dat = array('status' => true, 'msg' => $dato);
    echo json_encode($dat,JSON_UNESCAPED_UNICODE);
   die(); 
 }
     

}

