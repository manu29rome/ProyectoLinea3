<?php


class Historial extends Controllers {
     public function __construct() {
        parent:: __construct();  
         session_start();
        ; }
        
 public function historial() {
    $data['page_id']='5';
       $data['page_tag']='Compras';
        $data['page_title'] = "PAGINA PRINCIPAL";
        $data['page_name']="Compras";
        
        $datos = $this->model->selectCategorias();
        
        $subcategoria = $this->model->selectsubCategorias(); 
         $cadena4 = "";
        for($i=0; $i < count($datos);$i++){
        $cadena4 = $cadena4.'<li class="p-b-10">';
        $cadena4 = $cadena4.'<a href="#" class="stext-107 cl7 hov-cl1 trans-04">'; 
        $cadena4 = $cadena4.$datos[$i]['categoria'];
        $cadena4 = $cadena4.'</a></li>'; 
        }
        $data['listaca'] = $cadena4;
        
        $cadena5 = "";
        for($i=0; $i < count($subcategoria);$i++){
        $cadena5 = $cadena5.'<li class="p-b-10">';
        $cadena5 = $cadena5.'<a href="#" class="stext-107 cl7 hov-cl1 trans-04">'; 
        $cadena5 = $cadena5.$subcategoria[$i]['subcategoria'];
        $cadena5 = $cadena5.'</a></li>'; 
        }
        $data['listasubca'] = $cadena4;
        
        if(empty($_SESSION['idUser'])){
        $data['usuario'] = "vacio";
        $data['nombre'] = "0"; 
        $data['rol'] = "1";
        $data['id'] = "0";
        }else{
           
        $data['usuario'] = $_SESSION['idUser'];
        $usuario = $this->model->selectUsuario($data['usuario']); 
        $data['nombre'] = $usuario['nombreus'];
        $data['rol'] = $usuario['rolid'];
          }
         $total = 0;
       $cadena6 = "";
       if(isset($_SESSION['idUser'])){
       $carrito = $this->model->selectCarrito($_SESSION['idUser']);
       if(isset($carrito)){
       for($i=0; $i < count($carrito);$i++){
       $producto = $this->model->selectProducto($carrito[$i]['idpro']); 
       $image = $this->model-> selectProductoImagen($producto['codigo']);
       $cadena6 = $cadena6.'<li class="header-cart-item flex-w flex-t m-b-12">';
       $cadena6 = $cadena6.'<div class="header-cart-item-img">';
       if(isset($image[0]['imagen'])){ 
           $cadena6 = $cadena6.'<img src="'.$image[0]['imagen'].'" alt="IMG"></div>'; }
       else{ 
           $cadena6 = $cadena6.'<img src="Assets/Images/uploads/Emote2.jpg" alt="IMG"></div>'; }
       $cadena6 = $cadena6.'<div class="header-cart-item-txt p-t-8">';
       $cadena6 = $cadena6.'<a href="#" class="header-cart-item-name m-b-18 hov-cl1 trans-04">';
       $cadena6 = $cadena6.$producto['producto'];
       $cadena6 = $cadena6.'</a><span class="header-cart-item-info">';
       $cadena6 = $cadena6.$carrito[$i]['cantidad'].' x '.formaMoney($producto['precio']).' COP';
       $cadena6 = $cadena6.'</span></div></li>';
       $total = $total+($carrito[$i]['cantidad']*$producto['precio']);
       }
       }else if(empty($carrito)){
         $cadena6 = $cadena6.'No tienes todavia articulos en tu Carrito';  
       }
       $data['total'] = formaMoney($total).' COP';
       if(empty($carrito)){
        $data['carri'] = "0";   
       }else{
        $data['carri'] = count($carrito);   
       }
       
       $data['carrito'] = $cadena6;
 } 
  $this->views->getView($this,"historial",$data);     
 }
}

