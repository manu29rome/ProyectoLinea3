<?php


class Tienda extends Controllers{
    public function __construct() {
        parent:: __construct();  
        session_start();
        
        ; }
      public function tienda(){
  $data['page_id']='1';
        $data['page_tag']='Contacto';
        $data['page_title'] = "PAGINA PRINCIPAL";
        $data['page_name']="contacto";
        $data['page_functions_js']="function_homes.js";
        $datos = $this->model->selectCategorias();
        
        $subcategoria = $this->model->selectsubCategorias(); 
         $cadena2 = "";
        $productos = $this->model->selectProductos(); 
        for($i=0; $i < count($productos);$i++){
        $imagen = $this->model-> selectProductoImagen($productos[$i]['codigo']);
        $cadena2 = $cadena2.'<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item m '.$productos[$i]['idca'].'">';
        $cadena2 = $cadena2.'<div class="block2">';
        $cadena2 = $cadena2.'<div class="block2-pic hov-img0">';
        if(empty($imagen[0]['imagen'])){
        $cadena2 = $cadena2.'<img src="Assets/Images/uploads/Emote2.jpg" alt="IMG-BANNER">';;
        }else{
        $cadena2 = $cadena2.'<img src="'.$imagen[0]['imagen'].'" alt="IMG-PRODUCT">';}
        $cadena2 = $cadena2.'<a href="#" class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 js-show-modal1">';
        $cadena2 = $cadena2.'<button  class=" js-show-modal1 "  rl="'.$productos[$i]['idpro'].'"">Ver Detalles</button>';
        $cadena2 = $cadena2.'</a></div>';
        $cadena2 = $cadena2.'<div class="block2-txt flex-w flex-t p-t-14">';
        $cadena2 = $cadena2.'<div class="block2-txt-child1 flex-col-l ">';
        $cadena2 = $cadena2.'<a href="product-detail.html" class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6">';
        $cadena2 = $cadena2.$productos[$i]['producto'];
        $cadena2 = $cadena2.'</a><span class="stext-105 cl3">';
        $cadena2 = $cadena2.'<strong>COP </strong>'.formaMoney($productos[$i]['precio']);
        $cadena2 = $cadena2.'</span></div>';
        $cadena2 = $cadena2.'<div class="block2-txt-child2 flex-r p-t-3">';
        $cadena2 = $cadena2.'<a href="#" class="btn-addwish-b2 dis-block pos-relative js-addwish-b2">';
        $cadena2 = $cadena2.'<img class="icon-heart2 dis-block trans-04 ab-t-l" src="Assets/tienda/images/icons/icon-heart-02.png" alt="ICON">';
        $cadena2 = $cadena2.'</a></div></div></div></div>';
        }
        $data['productos'] = $cadena2;
         $cadena4 = "";
        for($i=0; $i < count($datos);$i++){
        $cadena4 = $cadena4.'<li class="p-b-10">';
        $cadena4 = $cadena4.'<a href="#" class="stext-107 cl7 hov-cl1 trans-04">'; 
        $cadena4 = $cadena4.$datos[$i]['categoria'];
        $cadena4 = $cadena4.'</a></li>'; 
        }
        $data['listaca'] = $cadena4;
        
        $cadena5 = "";
        for($i=0; $i < count($subcategoria);$i++){
        $cadena5 = $cadena5.'<li class="p-b-10">';
        $cadena5 = $cadena5.'<a href="#" class="stext-107 cl7 hov-cl1 trans-04">'; 
        $cadena5 = $cadena5.$subcategoria[$i]['subcategoria'];
        $cadena5 = $cadena5.'</a></li>'; 
        }
        $data['listasubca'] = $cadena4;
        
        if(empty($_SESSION['idUser'])){
        $data['usuario'] = "vacio";
        $data['nombre'] = "0"; 
        $data['rol'] = "1";
        $data['id'] = "0";
        }else{
           
        $data['usuario'] = $_SESSION['idUser'];
        $usuario = $this->model->selectUsuario($data['usuario']); 
        $data['nombre'] = $usuario['nombreus'];
        $data['rol'] = $usuario['rolid'];
          }
          
        $cadena5 = "";
        for($i=0; $i < count($subcategoria);$i++){
        $cadena5 = $cadena5.'<li class="p-b-10">';
        $cadena5 = $cadena5.'<a href="#" class="stext-107 cl7 hov-cl1 trans-04">'; 
        $cadena5 = $cadena5.$subcategoria[$i]['subcategoria'];
        $cadena5 = $cadena5.'</a></li>'; 
        }
        $data['listasubca'] = $cadena4;
        
        $cadena3 = "";
        $subcategoria = $this->model->selectsubCategorias(); 
        for($i=0; $i < count($subcategoria);$i++){
        $cadena3 = $cadena3.'<button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5" value="" data-filter=".'.$subcategoria[$i]['idsubca'].'">'; 
        $cadena3 = $cadena3.$subcategoria[$i]['subcategoria']; 
        $cadena3 = $cadena3.'</button>'; 
        }
        $data['subcategoria'] = $cadena3;
        
         $total = 0;
       $cadena6 = "";
       if(isset($_SESSION['idUser'])){
       $carrito = $this->model->selectCarrito($_SESSION['idUser']);
       if(isset($carrito)){
       for($i=0; $i < count($carrito);$i++){
       $producto = $this->model->selectProducto($carrito[$i]['idpro']); 
       $image = $this->model-> selectProductoImagen($producto['codigo']);
       $cadena6 = $cadena6.'<li class="header-cart-item flex-w flex-t m-b-12">';
       $cadena6 = $cadena6.'<div class="header-cart-item-img">';
       if(isset($image[0]['imagen'])){ 
           $cadena6 = $cadena6.'<img src="'.$image[0]['imagen'].'" alt="IMG"></div>'; }
       else{ 
           $cadena6 = $cadena6.'<img src="Assets/Images/uploads/Emote2.jpg" alt="IMG"></div>'; }
       $cadena6 = $cadena6.'<div class="header-cart-item-txt p-t-8">';
       $cadena6 = $cadena6.'<a href="#" class="header-cart-item-name m-b-18 hov-cl1 trans-04">';
       $cadena6 = $cadena6.$producto['producto'];
       $cadena6 = $cadena6.'</a><span class="header-cart-item-info">';
       $cadena6 = $cadena6.$carrito[$i]['cantidad'].' x '.formaMoney($producto['precio']).' COP';
       $cadena6 = $cadena6.'</span></div></li>';
       $total = $total+($carrito[$i]['cantidad']*$producto['precio']);
       }
       }else if(empty($carrito)){
         $cadena6 = $cadena6.'No tienes todavia articulos en tu Carrito';  
       }
       $data['total'] = formaMoney($total).' COP';
       if(empty($carrito)){
        $data['carri'] = "0";   
       }else{
        $data['carri'] = count($carrito);   
       }
       
       $data['carrito'] = $cadena6;
      }
  $this->views->getView($this,"tienda",$data);   
 }

}
