<?php

class Categorias extends Controllers {
    public function __construct() {
        parent:: __construct();  
        session_start();
        if(empty($_SESSION['login'])){
            header('location:'.base_url().'home');
        }
        if(isset($_SESSION['idUser'])){
         $User = $this->model->selectUsuario($_SESSION['idUser']);   
            if($User['rolid'] == 1){
            header('location:'.base_url().'home');
        }else{
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
        $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $permiso = $Requestper[4]['ver'];
        if($permiso == 0){
          header('location:'.base_url().'dashboard');  
        }}}
        ; }
    public function categorias (){
        $idus = $_SESSION['idUser'];
        $RequestUser = $this->model->selectUsuario($idus);
        $RequestRol = $this->model->selectRol($RequestUser['rolid']);
        $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
        $data['page_rol'] = $RequestRol['nombrerol'];
        $data['page_name'] = $RequestUser['nombreus'];
        $data['page_tag']='Categorias';
       $data['page_admin']='Manuel Romero';
       $data['page_functions_js']="function_categorias.js";
       $data['page_añadir']=$Requestper[4]['añadir'];
       $data['page_verrol']=$Requestper[1]['ver'];
         $data['page_verusu']=$Requestper[2]['ver'];
         $data['page_verpro']=$Requestper[3]['ver'];
         $data['page_vercate']=$Requestper[4]['ver'];
         $data['page_verped']=$Requestper[5]['ver'];
         $data['page_versub']=$Requestper[6]['ver'];
         $data['page_vercli']=$Requestper[7]['ver'];
        $this->views->getView($this,"categorias",$data);
    }
    
    public function getCategoria(int $idrol){
        $intIdrol = intval(strClean($idrol));
        if($intIdrol > 0){
          $arrData = $this->model->selectCategoria($intIdrol);
          $imagenes = $arrData['imagen'];
          $imagenes = str_replace("Assets/Images/Categorias/", "", $imagenes);
          $arrData['imagenes'] = $imagenes;
        if(empty($arrData)){
          $arrResponse = array('status' => false,'msg'=>'Datos no encontrados.' ); 
        }else{
          $arrResponse = array('status' => true,'msg'=>$arrData ); 
        }        echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
      }
     die();
        }
    
    public function getCategorias(){
    $idus = $_SESSION['idUser'];
    $intIdca = intval($_POST['idCa']);
    $foto = strClean($_POST['foto']);
    $strNombre = strClean($_POST['txtNombreca']);
    $strDesctipcion = strClean($_POST['txtDescripcionca']);
    $intStatus = intval($_POST['listStatusca']);
    $valor = intval($_POST['idCama']);
    $nombre = $_FILES['imagenca']["name"];
    $rutap = $_FILES['imagenca']["tmp_name"];
    $tipo = $_FILES['imagenca']["type"];
    $tamaño = $_FILES['imagenca']["size"];
    $carpeta = "Assets/Images/Categorias/";
    $src = $carpeta.$nombre;
    if($nombre != ""){
     $image = getimagesize($_FILES['imagenca']["tmp_name"]);    //Sacamos la información
    $ancho = $image[0];
    $alto=$image[1];
    }else{
        $ancho = "";
        $alto = "";
    }
    if($tipo == "image/JPG" || $tipo == "image/jpeg" || $tipo == "image/png" || $tipo == "image/jpg" || empty($tipo)){
    if($tamaño < 5500000){
    if($ancho == 1200 && $alto == 809 || $src == "Assets/Images/Categorias/"){
    if($intIdca == 0){
    $request_categoria = $this->model->insertCategoria($strNombre,$strDesctipcion,$intStatus,$src,$idus);
    $opcion = 1;
    }else{
    $request_categoria = $this->model->updateCategoria($intIdca,$strNombre,$strDesctipcion,$intStatus,$src,$valor,$foto);
    $opcion = 2;    
    }
    if ($request_categoria >0){
       if($opcion == 1){
       $arraData = array('status' => true,'msg'=>'Se ha guardadao correctamente los Datos.');   
        move_uploaded_file($rutap,$src);
      }else{
         $arraData = array('status' => true,'msg'=>'Se ha Actualizado correctamente los Datos.');   
        move_uploaded_file($rutap,$src);
      }
    } else if($request_categoria == "exist"){
       $arraData = array('status' => false,'msg'=>'Ya existe esa Categoria.'); 
       
    }
    else if($request_categoria == "ok"){
       $arraData = array('status' => false,'msg'=>'La Imagen con ese nombre ya existe.'); 
       
    }
    }else{
      $arraData = array('status' => false,'msg'=>'La imagen debe ser maximo de 1200px de ancho y 809px de alto');    
    }
    }
    else{
       $arraData = array('status' => false,'msg'=>'el Tamaño maximo es de 5mb');  
    }
    }else{
       $arraData = array('status' => false,'msg'=>'No es formato jpg, npj o jpeg');  
    }
    echo json_encode($arraData,JSON_UNESCAPED_UNICODE);
    die(); 
    
    }
    
    public function setCategorias(){
    $arrData = $this->model->selectCategorias(); 
    $idus = $_SESSION['idUser'];
    $RequestUser = $this->model->selectUsuario($idus);
    $Requestper = $this->model->selectpermiso($RequestUser['rolid']);
    for($i=0; $i < count($arrData);$i++){
    if($arrData[$i]['status'] == 1){
     $arrData[$i]['status']='<span class="badge badge-success">Activo'; 
        ;}else{
             $arrData[$i]['status']='<span class="badge badge-danger">Inactivo'; 
        }
        if($arrData[$i]['imagen'] == "Assets/Images/Categorias/"){
           $arrData[$i]['imagen']='<img style="height:50px; width: auto;" src="Assets/Images/Categorias/Implementos/caja.jpg">'; 
        }else{
          $arrData[$i]['imagen']='<img style="height:40px;" src="'.$arrData[$i]['imagen'].'">';  
        }
        
        $cadena='<div class="text-center">';
        if($Requestper [4]['editar']== 1){
        $cadena = $cadena.'<button  class="btn btn-info btn-sm btnEditCategoria"  rl="'.$arrData[$i]['idca'].'" title="Editar"><i class="fa fa-pencil" aria-hidden="true"></i></button>';
        }if($Requestper [4]['eliminar']== 1){
        $cadena = $cadena.'<button class="btn btn-danger btn-sm  btnDeCategoria" rl="'.$arrData[$i]['idca'].'" title="Eliminar"><i class="fa fa-trash" aria-hidden="true"></i></button>
        </div>';}
        if($Requestper [4]['editar']== 0 && $Requestper [4]['eliminar']== 0){
         $cadena = "=(";   
        }
        $arrData[$i]['options']=$cadena;
        }
        
        
    echo json_encode($arrData,JSON_UNESCAPED_UNICODE);
    die();

   }
   
   public function DelCategoria (){
      if($_POST){
           $intIdCategoria = intval($_POST['idCa']);
           
           $request = $this->model->selectCategoria($intIdCategoria);
           $foto = $request['imagen'];
           $requestDelete = $this->model->deleteCategoria($intIdCategoria);
           if($requestDelete == 'ok'){
               if($foto != "Assets/Images/Categorias/"){
                unlink($foto);    
              }
             $arrResponse = array('status' => true, 'msg' => 'Se ha eliminado el Categoria');
           }else if($requestDelete == 'exist'){
            $arrResponse = array('status' => false, 'msg' => 'Error al eliminar el Categoria');
           }else if($requestDelete == "si"){
           $arrResponse = array('status' => false,'msg'=>'No es posible Eliminar la Categoria asociado a una SubCategoria.'); 
       
           }
           
           
           echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
          }
          die(); 
   }
   
}
