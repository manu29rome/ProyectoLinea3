<?php


class RolesModel extends Mysql {
    public $intIdrol;
    public $strRol;
    public $strDescripcion;
    public $intStatus;
    public $stroption;
    public $intver;
    public $inteditar;
    public $inteliminar;
    public $intañadir;
    public function __construct() {
        parent:: __construct();
        ; }
        
        public function selectUsuario($idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 
 public function selectRoles(){
     $sql = "SELECT * FROM rol Where status != 0";
     $request = $this->select_all($sql);
     return $request;
 }
 
 public function selectpermiso($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM permisosrol WHERE rolid LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }
 
 
 
 public function selectRol($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM rol WHERE idrol LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }
 public function selectRolnombre($idnom){
     $this->strRol = $idnom;
     $sql ="SELECT * FROM `rol` WHERE `nombrerol` LIKE '$this->strRol'";
     $request = $this->select($sql);
return $request;

}
 public function insertPermisos(string $option, int $ver, int $editar, int $eliminar, int $anadir, int $rolid){
   $this->stroption = $option;
   $this->intver = $ver;
   $this->inteditar = $editar;
   $this->inteliminar = $eliminar;
   $this->intanadir = $anadir;
   $this->intIdrol = $rolid;
 
       $query_insert = "INSERT INTO permisosrol (opcionper,ver,editar,eliminar,anadir,rolid) VALUES (?,?,?,?,?,?)";
       $arrData = array($this->stroption, $this->intver, $this->inteditar,$this->inteliminar, $this->intanadir, $this->intIdrol);
       $request_insert = $this->insert($query_insert,$arrData);
       $return = $request_insert;
   
   return $return;
 }
 
  public function insertRol(string $rol, string $descripcion, int $status){
   $return = "";  
   $this->strRol = $rol;
   $this->strDescripcion = $descripcion;
   $this->intStatus = $status;
   $sql = "SELECT * FROM rol WHERE nombrerol = '{$this->strRol}'";
   $request = $this->select_all($sql);
   if(empty($request)){
       $query_insert = "INSERT INTO rol (nombrerol,descripcion,status) VALUES (?,?,?)";
       $arrData = array($this->strRol, $this->strDescripcion, $this->intStatus);
       $request_insert = $this->insert($query_insert,$arrData);
       $return = $request_insert;
   }
   else{
       $return = "exist";
   }
   return $return;
 } 
 public function updateRol(int $idrol,string $rol,string $descripcion,int $status){
$this->intIdrol = $idrol;
$this->strRol = $rol;
$this->strDescripcion = $descripcion;
$this->intStatus = $status;
$sql = "SELECT * FROM rol WHERE nombrerol = '$this->strRol' AND idrol != $this->intIdrol";
$request = $this->select_all($sql);

if(empty($request)){
    $sql = "UPDATE rol SET nombrerol = ?, descripcion = ?, status = ? WHERE idrol = $this->intIdrol";
    $arrData = array($this->strRol,$this->strDescripcion,$this->intStatus);
    $request = $this->update($sql,$arrData);
}else{
    $request = "exist";
}
return $request;
 }
 
  public function updatePerVer(int $idper,string $ver){
$this->intIdrol = $idper;
$this->intver = $ver;

 $sql = "UPDATE permisosrol SET ver = ? WHERE idper = $this->intIdrol";
    $arrData = array($this->intver);
    $request = $this->update($sql,$arrData);

return $request;
 }
 
 public function updatePerEditar(int $idper,string $editar){
$this->intIdrol = $idper;
$this->inteditar = $editar;

 $sql = "UPDATE permisosrol SET editar = ? WHERE idper = $this->intIdrol";
    $arrData = array($this->inteditar);
    $request = $this->update($sql,$arrData);

return $request;
 }
 
  public function updatePerEliminar(int $idper,string $eliminar){
$this->intIdrol = $idper;
$this->inteliminar = $eliminar;

 $sql = "UPDATE permisosrol SET eliminar = ? WHERE idper = $this->intIdrol";
    $arrData = array($this->inteliminar);
    $request = $this->update($sql,$arrData);

return $request;
 }
 
  public function updatePerAñadir(int $idper,string $anadir){
$this->intIdrol = $idper;
$this->intanadir = $anadir;

 $sql = "UPDATE permisosrol SET añadir = ? WHERE idper = $this->intIdrol";
    $arrData = array($this->intanadir);
    $request = $this->update($sql,$arrData);

return $request;
 }

public function deleteRol(int $idrol){
    $this->intIdrol = $idrol;
    $sql = "SELECT * FROM persona WHERE rolid = $this->intIdrol";
    $request = $this->select_all($sql);
    if(empty($request)){
        $sql = "DELETE FROM `rol` WHERE `rol`.`idrol` = $this->intIdrol";
        $sql2 = "DELETE FROM `permisosrol` WHERE `permisosrol`.`rolid` = $this->intIdrol";
        $request2 = $this->delete($sql2);
        $request = $this->delete($sql);
        if($request){
            $request = 'ok';
        }else{
            $request = 'exist';
        }
    }else{
        $request = 'error';
    }
    return $request;
}

}
