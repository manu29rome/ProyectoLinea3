<?php

class CategoriasModel extends Mysql {
    
    private $intIdUsuario;
    private $intIdrol;
    private $strCategoria;
    private $strDescripcion;
    private $intStatus;
    private $strImagen;
    private $intIdca;


    public function __construct() {
        parent:: __construct();
        ; }
    
    public function selectCategoria($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM categorias WHERE idca LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }
  public function selectpermiso($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM permisosrol WHERE rolid LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }  
 
   public function selectUsuario(int $idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 public function selectRol(int $idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM rol WHERE idrol LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }
 public function selectCategorias(){
     $sql = "SELECT * FROM categorias WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;
 }
 public function insertCategoria(string $categoria, string $descripcion, int $status, string $imagen, int $idus) {
    
    $this->intIdUsuario = $idus;
    $this->strCategoria = $categoria;
    $this->strDescripcion = $descripcion;
    $this->intStatus = $status;
    $this->strImagen = $imagen;
    $sql = "SELECT * FROM categorias WHERE categoria LIKE '$this->strCategoria'";
   $request = $this->select_all($sql);
   if(empty($request)){
   $sql = "SELECT * FROM categorias WHERE imagen LIKE '$this->strImagen'";
   $request = $this->select_all($sql);
   
   
   
   if(empty($request)){    
    $query_insert = "INSERT INTO categorias (categoria,descripcionca,status,imagen,idus) VALUES (?,?,?,?,?)";
    $arrData = array($this->strCategoria, $this->strDescripcion, $this->intStatus, $this->strImagen, $this->intIdUsuario);
    $request_insert = $this->insert($query_insert,$arrData);
    return  $request_insert;
   }else if($request[0]["imagen"] == "Assets/Images/Categorias/"){
     $query_insert = "INSERT INTO categorias (categoria,descripcionca,status,imagen,idus) VALUES (?,?,?,?,?)";
    $arrData = array($this->strCategoria, $this->strDescripcion, $this->intStatus, $this->strImagen, $this->intIdUsuario);
    $request_insert = $this->insert($query_insert,$arrData);
    return  $request_insert;  
   }else {
       $request = "ok";
   }
   }else{
       $request = "exist";
   }
    return $request;  
 }
 
 public function updateCategoria(int $id, string $categoria, string $descripcion, int $status, string $imagen, int $valor, string $foto){
    $this->intIdca =$id;
    $this->strCategoria = $categoria;
    $this->strDescripcion = $descripcion;
    $this->intStatus = $status;
    $this->strImagen = $imagen;
    
 
 if($valor == 1){
     unlink("Assets/Images/Categorias/".$foto); 
    $this->strImagen = "Assets/Images/Categorias/"; 
    $sql = "UPDATE categorias SET categoria = ?, descripcionca = ?, status = ?, imagen = ? WHERE idca = $this->intIdca";
    $arrData = array($this->strCategoria, $this->strDescripcion, $this->intStatus, $this->strImagen);
    $request = $this->update($sql,$arrData);
    return $request; 
 }else{
    
    if($imagen == "Assets/Images/Categorias/"){
    $sql = "UPDATE categorias SET categoria = ?, descripcionca = ?, status = ? WHERE idca = $this->intIdca";
    $arrData = array($this->strCategoria, $this->strDescripcion, $this->intStatus);
    $request = $this->update($sql,$arrData);
    return $request;
   } else{
    $sql = "SELECT * FROM categorias WHERE imagen LIKE '$this->strImagen'";
    $request_c = $this->select_all($sql);
    if(empty($request_c)){
    $sql = "UPDATE categorias SET categoria = ?, descripcionca = ?, status = ?, imagen = ? WHERE idca = $this->intIdca";
    $arrData = array($this->strCategoria, $this->strDescripcion, $this->intStatus, $this->strImagen);
    $request = $this->update($sql,$arrData);
    if($foto != ""){
     unlink("Assets/Images/Categorias/".$foto);    
    }
    return $request;
    }else{
     $request_c = "ok";   
    }
    return $request_c;
 }
   
 }
 
 }
 
 public function deleteCategoria(int $idCa){
     $this->intIdca = $idCa;
     $sql = "SELECT * FROM subcategorias WHERE idca = $this->intIdca";
    $request = $this->select_all($sql);
    if(empty($request)){
        $sql = "DELETE FROM `categorias` WHERE `categorias`.`idca` = $this->intIdca";
        $request = $this->delete($sql);
        if($request){
            $request = 'ok';
        }else{
            $request = 'exist';
        }
    }else{
          $request = 'si';  
        }
    return $request;
 }
 
 
}
