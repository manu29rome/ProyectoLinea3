<?php

class PerfilModel extends Mysql {
    private $intIdUsuario;
    private $intIdrol;
    private $strNombre;
    private $strApellido;
    private $strEmail;
    private $intTelefono;
    private $intIdentificacion;
    private $strContraseña;

    public function __construct() {
        parent:: __construct();
        ; }
        
   public function selectUsuario($idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 public function selectRol($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM rol WHERE idrol LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }
 
 public function selectpermiso($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM permisosrol WHERE rolid LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }
 
   public function updateUsuario(int $idusuario, string $nombre, string $apellido,int $telefono, string $contraseña){
$this->intIdUsuario = $idusuario;
$this->strNombre = $nombre;
$this->strApellido = $apellido;
$this->intTelefono = $telefono;
$this->strContraseña = $contraseña;
if(empty($contraseña)){
    $sql = "UPDATE persona SET nombreus = ?, apellidous = ?, telefono = ? WHERE idus = $this->intIdUsuario";
    $arrData = array($this->strNombre,$this->strApellido,$this->intTelefono);
    $request = $this->update($sql,$arrData);

return $request;
 } else{
     $sql = "UPDATE persona SET nombreus = ?, apellidous = ?,  Password = ?, telefono = ?  WHERE idus = $this->intIdUsuario";
    $arrData = array($this->strNombre,$this->strApellido, $this->strContraseña, $this->intTelefono);
    $request = $this->update($sql,$arrData);

return $request; 
 }
   }
   
   
}
