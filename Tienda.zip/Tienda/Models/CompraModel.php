<?php


class CompraModel extends Mysql{
    public function __construct() {
        parent:: __construct();
        ; }

 public function selectUsuario($idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 
 public function selectCategorias(){
     $sql = "SELECT * FROM categorias WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;
 }
 public function selectDepartamentos(){
     $sql = "SELECT * FROM departamentos";
     $request = $this->select_all($sql);
     return $request;
 }

 public function selectsubCategorias(){
     $sql = "SELECT * FROM subcategorias WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;
 }
    public function selectCarrito($idus){
     $this->intIdUsuario = $idus;
     $sql ="SELECT * FROM carrito WHERE idus = $this->intIdUsuario AND status != 1" ;
     $request = $this->select_all($sql);
     return $request;
 }
  public function selectProducto($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM productos WHERE idpro LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 } 
 public function selectProductoImagen($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM imagenes WHERE codigo LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }
 
 public function updateProducto($cantidad, $id){
  $this->intcantidad = $cantidad;   
  $this->intid = $id;
  
  $sql = "UPDATE productos SET stock = ? WHERE idpro = $this->intid";
  $arrData = array($this->intcantidad);
  $request = $this->update($sql,$arrData);
  return $request; 
 }
 
 public function updateCompra($id){
  $this->status = "1";   
  $this->intid = $id;
  
  $sql = "UPDATE carrito SET status = ? WHERE idpro = $this->intid";
  $arrData = array($this->status);
  $request = $this->update($sql,$arrData);
  return $request; 
 }
 public function selectmun($p){
     $this->intp= $p;   
   $sql = "SELECT * FROM municipios WHERE departamento_id LIKE '$this->intp'";
   $request = $this->select_all($sql);
   return $request;
 }
 
public function deleteProducto(int $idCa){
     $this->intIdca = $idCa;
   
        $sql = "DELETE FROM `carrito` WHERE `idcarrito` = $this->intIdca";
        $request = $this->delete($sql);
        if($request){
            $request = 'ok';
        }else{
            $request = 'exist';
        }
    
    return $request;
 }
 
  public function selecCodigo(){  
   $sql = "SELECT * FROM codigos";
   $request = $this->select_all($sql);
   return $request;
 }
 
  public function Codigo($p){
     $this->intp= $p;   
   $query_insert = "INSERT INTO codigos (codigo) VALUES (?)";
       $arrData = array($this->intp);
       $request_insert = $this->insert($query_insert,$arrData);
       return  $request_insert;
 }
}
