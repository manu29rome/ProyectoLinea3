<?php

class SubcategoriaModel extends Mysql {
    
    private $intIdUsuario;
    private $intIdrol;
    private $strCategoria;
    private $strDescripcion;
    private $intStatus;
    private $strImagen;
    private $intIdca;
    private $intcate;
    
    public function __construct() {
        parent:: __construct();
        ; }
        
   public function selectsubCategoria($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM subcategorias WHERE idsubca LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }
 
  public function selectCategoria($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM categorias WHERE idca LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }
 
  public function selectpermiso($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM permisosrol WHERE rolid LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }  
 
   public function selectUsuario(int $idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 public function selectRol(int $idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM rol WHERE idrol LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }
 public function selectsubCategorias(){
     $sql = "SELECT * FROM subcategorias WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;
 }
 
 public function selectCategorias(){
     $sql = "SELECT * FROM categorias WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;
 }
 
 public function insertsubCategoria(string $categoria, string $descripcion, int $status, string $imagen, int $idca) {
    
    $this->intIdca= $idca;
    $this->strCategoria = $categoria;
    $this->strDescripcion = $descripcion;
    $this->intStatus = $status;
    $this->strImagen = $imagen;
    $sql = "SELECT * FROM subcategorias WHERE subcategoria LIKE '$this->strCategoria'";
   $request = $this->select_all($sql);
   if(empty($request)){
   $sql = "SELECT * FROM subcategorias WHERE imagen LIKE '$this->strImagen'";
   $request = $this->select_all($sql);
   
   if(empty($request)){    
    $query_insert = "INSERT INTO subcategorias (subcategoria,descripcion,status,imagen,idca) VALUES (?,?,?,?,?)";
    $arrData = array($this->strCategoria, $this->strDescripcion, $this->intStatus, $this->strImagen, $this->intIdca);
    $request_insert = $this->insert($query_insert,$arrData);
    return  $request_insert;
   }else if($request[0]["imagen"] == "Assets/Images/subCategorias/"){
     $query_insert = "INSERT INTO subcategorias (subcategoria,descripcion,status,imagen,idca) VALUES (?,?,?,?,?)";
    $arrData = array($this->strCategoria, $this->strDescripcion, $this->intStatus, $this->strImagen, $this->intIdca);
    $request_insert = $this->insert($query_insert,$arrData);
    return  $request_insert;  
   }else {
       $request = "ok";
   }
   }else{
       $request = "exist";
   }
    return $request;  
 }
 
 public function updatesubCategoria(int $id, string $categoria, string $descripcion, int $status, string $imagen, int $valor, string $foto, int $idca){
 
    $this->intIdca =$id;
    $this->strCategoria = $categoria;
    $this->strDescripcion = $descripcion;
    $this->intStatus = $status;
    $this->strImagen = $imagen;
    $this->intcate= $idca;
 
 if($valor == 1){
     unlink("Assets/Images/subCategorias/".$foto); 
    $this->strImagen = "Assets/Images/subCategorias/"; 
    $sql = "UPDATE subcategorias SET subcategoria = ?, descripcion = ?, status = ?, imagen = ?, idca = ? WHERE idsubca = $this->intIdca";
    $arrData = array($this->strCategoria, $this->strDescripcion, $this->intStatus, $this->strImagen, $this->intcate);
    $request = $this->update($sql,$arrData);
    return $request; 
 }else{
    
    if($imagen == "Assets/Images/subCategorias/"){
    $sql = "UPDATE subcategorias SET subcategoria = ?, descripcion = ?, status = ?, idca = ? WHERE idsubca = $this->intIdca";
    $arrData = array($this->strCategoria, $this->strDescripcion, $this->intStatus, $this->intcate);
    $request = $this->update($sql,$arrData);
    return $request;
   } else{
    $sql = "SELECT * FROM subcategorias WHERE imagen LIKE '$this->strImagen'";
    $request_c = $this->select_all($sql);
    if(empty($request_c)){
    $sql = "UPDATE subcategorias SET subcategoria = ?, descripcion = ?, status = ?, imagen = ?, idca = ? WHERE idsubca = $this->intIdca";
    $arrData = array($this->strCategoria, $this->strDescripcion, $this->intStatus, $this->strImagen, $this->intcate);
    $request = $this->update($sql,$arrData);
    if($foto != ""){
     unlink("Assets/Images/subCategorias/".$foto);    
    }
    return $request;
    }else{
     $request_c = "ok";   
    }
    return $request_c;
 }
 
   
 }
 }
 
 public function deletesubCategoria(int $idCa){
     $this->intIdca = $idCa;
     $sql = "SELECT * FROM productos WHERE idca = $this->intIdca";
    $request = $this->select_all($sql);
    if(empty($request)){
        $sql = "DELETE FROM `subcategorias` WHERE `subcategorias`.`idsubca` = $this->intIdca";
        $request = $this->delete($sql);
        if($request){
            $request = 'ok';
        }else{
            $request = 'exist';
        }
    }else{
          $request = 'si';  
        }
    return $request;
 }
 
 
}