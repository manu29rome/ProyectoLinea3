<?php

class DashboardModel extends Mysql{
      public function __construct() {
        parent:: __construct();
        ; }
        
   public function selectUsuario($idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 public function selectRol($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM rol WHERE idrol LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }
  public function selectpermiso($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM permisosrol WHERE rolid LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }
 public function selectUsuarios(){
     $sql = "SELECT * FROM persona";
     $request = $this->select_all($sql);
     return $request;
 }
  public function selectProductos(){
     $sql = "SELECT * FROM productos";
     $request = $this->select_all($sql);
     return $request;
 }
}
