<?php

class ProductosModel extends Mysql {
    public function __construct() {
        parent:: __construct();
        ; }
 
 public function selectProducto($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM productos WHERE idpro LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }       
 
 public function selectProductoImagen($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM imagenes WHERE codigo LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }
 
 public function selectUsuario($idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 
 public function selectsubCategoria($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM subcategorias WHERE idsubca LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }
 
public function selectsubCategorias(){
     $sql = "SELECT * FROM subcategorias WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;
 }
 
 public function selectRol($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM rol WHERE idrol LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }
 public function selectpermiso($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM permisosrol WHERE rolid LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }
 
 public function selectProductos(){
     $sql = "SELECT * FROM productos";
     $request = $this->select_all($sql);
     return $request;
 }
  public function insertProducto(string $producto, string $descripcion, int $status, int $categoria, int $cantidad, int $precio, int $codigo, string $imagen1, string $imagen2, string $imagen3) {
    
    $this->strCategoria = $producto;
    $this->strDescripcion = $descripcion;
    $this->intStatus = $status;
    $this->strsubcategoria = $categoria;
    $this->intprecio = $precio;
    $this->intcantidad = $cantidad;
    $this->intcodigo = $codigo;
    $this->strimagen1 = $imagen1;
    $this->strimagen2 = $imagen2;
    $this->strimagen3 = $imagen3;
    
   $sql = "SELECT * FROM productos WHERE codigo LIKE '$this->intcodigo'";
   $request = $this->select_all($sql); 
   if(empty($request)){    
       
   $sql = "SELECT * FROM imagenes WHERE imagen LIKE '$this->strimagen1'";
   $request = $this->select_all($sql);   
   if(empty($request)){ 
       
   $sql = "SELECT * FROM imagenes WHERE imagen LIKE '$this->strimagen2'";
   $request = $this->select_all($sql);   
   if(empty($request)){ 
       
   $sql = "SELECT * FROM imagenes WHERE imagen LIKE '$this->strimagen3'";
   $request = $this->select_all($sql);   
   if(empty($request)){      
    
      if($imagen1 != 1){
       $sql = "INSERT INTO imagenes (imagen,codigo) VALUES (?,?)";
       $arrDa = array($this->strimagen1,$this->intcodigo);
       $request = $this->insert($sql,$arrDa);    
      }
      
       if($imagen2 != 2){
       $sql = "INSERT INTO imagenes (imagen,codigo) VALUES (?,?)";
       $arrDa = array($this->strimagen2,$this->intcodigo);
       $request = $this->insert($sql,$arrDa);    
      }
       if($imagen3 != 3){
       $sql = "INSERT INTO imagenes (imagen,codigo) VALUES (?,?)";
       $arrDa = array($this->strimagen3,$this->intcodigo);
       $request = $this->insert($sql,$arrDa);    
      }
       
    $query_insert = "INSERT INTO productos (codigo,producto,descripcion,stock,precio,status,idca) VALUES (?,?,?,?,?,?,?)";
    $arrData = array($this->intcodigo, $this->strCategoria, $this->strDescripcion, $this->intcantidad, $this->intprecio, $this->intStatus, $this->strsubcategoria);
    $request_insert = $this->insert($query_insert,$arrData);
    return  $request_insert;
   
   }else{
       $request = "exist3";
   }  
   }else{
       $request = "exist2";
   } 
   }else{
       $request = "exist1";
   }
    
   }else{
       $request = "exist";
   }
   return $request; 
  }
  
  public function updateProducto(int $id,string $producto, string $descripcion, int $status, int $categoria, int $cantidad, int $precio,string $imagen1,string $imagen2,string $imagen3) {
    
    $this->intid = $id;
    $this->strCategoria = $producto;
    $this->strDescripcion = $descripcion;
    $this->intStatus = $status;
    $this->strsubcategoria = $categoria;
    $this->intprecio = $precio;
    $this->intcantidad = $cantidad;
    $this->strimagen1 = $imagen1;
    $this->strimagen2 = $imagen2;
    $this->strimagen3 = $imagen3;
    
   $sql = "SELECT * FROM imagenes WHERE imagen LIKE '$this->strimagen1'";
   $request = $this->select_all($sql);   
   if(empty($request)){ 
       
   $sql = "SELECT * FROM imagenes WHERE imagen LIKE '$this->strimagen2'";
   $request = $this->select_all($sql);   
   if(empty($request)){ 
       
   $sql = "SELECT * FROM imagenes WHERE imagen LIKE '$this->strimagen3'";
   $request = $this->select_all($sql);   
   if(empty($request)){  
    
    $sql = "UPDATE productos SET producto = ?, descripcion = ?, stock = ?, precio =?, status = ?, idca = ? WHERE idpro = $this->intid";
    $arrData = array($this->strCategoria, $this->strDescripcion,$this->intcantidad,$this->intprecio, $this->intStatus, $this->strsubcategoria);
    $request = $this->update($sql,$arrData);
    return $request; 
   }else{
       $request = "exist3";
   }  
   }else{
       $request = "exist2";
   } 
   }else{
       $request = "exist1";
   }    
    return $request; 
  }
  
  public function updateimagen(string $imagen1,string $imagen2,string $imagen3, int $codigo, int $dato1,int $dato2,int $dato3){
  
    $this->intcodigo = $codigo;
    $this->strimagen1 = $imagen1;
    $this->strimagen2 = $imagen2;
    $this->strimagen3 = $imagen3;
    $id1 = "";
    $id2 = "";
    $id3 = "";
    
    $sql ="SELECT * FROM imagenes WHERE codigo LIKE '$this->intcodigo'";
    $request = $this->select_all($sql);
    
    if(empty($request[0]['imagen'])){      
    }else{
    $i1= $request[0]['imagen'];
    if(empty($i1)){
    }else{
     if($imagen1 != 1){   
     unlink($i1); 
      }
    }
    $id1 = $request[0]['idima'];
    }
    if($dato1 == 0){
    if($imagen1 != 1){  
     if(empty($i1)){
       $sql = "INSERT INTO imagenes (imagen,codigo) VALUES (?,?)";
       $arrDa = array($this->strimagen1,$this->intcodigo);
       $request = $this->insert($sql,$arrDa); 
     }else{
       $sql = "UPDATE imagenes SET imagen = ? WHERE idima = $id1";
       $arrvalor = array($this->strimagen1);
       $request = $this->update($sql,$arrvalor);
     }  }}else if($dato1 == 1){
        if($dato1 == 1){
         unlink($i1);   
        }
        $sql = "DELETE FROM `imagenes` WHERE `imagenes`.`idima` = $id1";
        $request1 = $this->delete($sql);
    }
     
     if(empty($request[1]['imagen'])){      
    }else{
    $i2= $request[1]['imagen'];
    if(empty($i2)){
    }else{
     if($imagen2 != 2 || $dato2 == 1 ){  
     unlink($i2);   
    }}
    $id2 = $request[1]['idima'];
    }
    if($dato2 == 0){
    if($imagen2 != 2){
     if(empty($i2)){
       $sql = "INSERT INTO imagenes (imagen,codigo) VALUES (?,?)";
       $arrDa = array($this->strimagen2,$this->intcodigo);
       $request = $this->insert($sql,$arrDa); 
     }else{
       $sql = "UPDATE imagenes SET imagen = ? WHERE idima = $id2";
       $arrvalor = array($this->strimagen2);
       $request3 = $this->update($sql,$arrvalor);
     } }}else if($dato2 == 1){
        $sql = "DELETE FROM `imagenes` WHERE `imagenes`.`idima` = $id2";
        $reque = $this->delete($sql);
    }
    
    if(empty($request[2]['imagen'])){      
    }else{
    $i3 = $request[2]['imagen'];
    if(empty($i3)){
    }else{
     if($imagen3 != 3 || $dato3 == 1 ){  
     unlink($i3);   
    }}
    $id3 = $request[2]['idima'];
    }
    if($dato3 == 0){
    if($imagen3 != 3){
     if(empty($i3)){
       $sql = "INSERT INTO imagenes (imagen,codigo) VALUES (?,?)";
       $arrDa = array($this->strimagen3,$this->intcodigo);
       $request = $this->insert($sql,$arrDa); 
     }else{
       $sql = "UPDATE imagenes SET imagen = ? WHERE idima = $id3";
       $arrvalor = array($this->strimagen3);
       $request = $this->update($sql,$arrvalor);
     } }}else if($dato3 == 1){
        if(empty($id3)){}else{
        $sql1 = "DELETE FROM `imagenes` WHERE `imagenes`.`idima` = $id3";
        $reques = $this->delete($sql1);
        }
    }
  } 
  
   
 public function deleteProducto(int $idCa){
     $this->intIdca = $idCa;
   
        $sql = "DELETE FROM `productos` WHERE `productos`.`idpro` = $this->intIdca";
        $request = $this->delete($sql);
        if($request){
            $request = 'ok';
        }else{
            $request = 'exist';
        }
    
    return $request;
 }
  public function deleteimagen(int $idCa){
     $this->intIdca = $idCa;
   
        $sql = "DELETE FROM `imagenes` WHERE `imagenes`.`codigo` = $this->intIdca";
        $request = $this->delete($sql);
        
 }
 
}
