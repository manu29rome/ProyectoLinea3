<?php

class NosotrosModel extends Mysql{
    public function __construct() {
        parent:: __construct();
        ; }

 public function selectUsuario($idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 
 public function selectCategorias(){
     $sql = "SELECT * FROM categorias WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;
 }

 public function selectsubCategorias(){
     $sql = "SELECT * FROM subcategorias WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;
 }
  public function insertMensaje(string $email, string $msg, int $id, string $fecha){
    $return = "";  
    $this->strMsg = $msg;
    $this->strFecha = $fecha;
    $this->strEmail = $email;
    $this->intId = $id;
    $this->intStatus = "0";
    
    $query_insert = "INSERT INTO mensaje (email,msg,idus,fecha,status) VALUES (?,?,?,?,?)";
    $arrData = array($this->strEmail, $this->strMsg,$this->intId,$this->strFecha,$this->intStatus);
    $request_insert = $this->insert($query_insert,$arrData);
    return  $request_insert;
  }
    public function selectCarrito($idus){
     $this->intIdUsuario = $idus;
     $sql ="SELECT * FROM carrito WHERE idus = $this->intIdUsuario AND status != 1";
     $request = $this->select_all($sql);
     return $request;
 }
  public function selectProducto($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM productos WHERE idpro LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 } 
 public function selectProductoImagen($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM imagenes WHERE codigo LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }
}
