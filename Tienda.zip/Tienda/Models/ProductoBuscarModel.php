<?php
class  ProductoBuscarModel extends Mysql{
    public function __construct() {
        parent:: __construct();
        ; }

 public function selectUsuario($idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 
 public function selectCategorias(){
     $sql = "SELECT * FROM categorias WHERE status != 2 ";
     $request = $this->select_all($sql);
     return $request;
 }

  public function selectCategoria(int $idca){
     $this->id = $idca;
     $sql = "SELECT * FROM categorias WHERE idca = $this->id ";
     $request = $this->select($sql);
     return $request;
 }
 public function selectsubCategorias(int $idca){
     $this->id = $idca;
     $sql = "SELECT * FROM subcategorias WHERE idca = $this->id AND status != 2";
     $request = $this->select_all($sql);
     return $request;
 }
  public function selectProductos(int $id){
      $this->id = $id;
     $sql = "SELECT * FROM productos WHERE idca = $this->id AND stock !=0 AND status != 2 ";
     $request = $this->select_all($sql);
     return $request;
 }
  public function selectProductoImagen($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM imagenes WHERE codigo LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }
 
    
}

