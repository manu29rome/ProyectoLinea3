<?php

class HomeModel extends Mysql{
    public function __construct() {
        parent:: __construct();
        ; }

 public function selectUsuario($idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 
  public function selectCarrito($idus){
     $this->intIdUsuario = $idus;
     $sql ="SELECT * FROM carrito WHERE idus = $this->intIdUsuario AND status != 1";
     $request = $this->select_all($sql);
     return $request;
 }
  public function selectCarritos($idpro){
     $this->intIdUsuario = $idpro;
     $sql ="SELECT * FROM carrito WHERE idpro = $this->intIdUsuario AND status LIKE '2'";
     $request = $this->select_all($sql);
     return $request;
 }
 
 
 public function selectCategorias(){
     $sql = "SELECT * FROM categorias WHERE status != 2";
     $request = $this->select_all($sql);
     return $request;
 }
 public function selectProductos(){
     $sql = "SELECT * FROM productos WHERE status != 2 AND stock != 0";
     $request = $this->select_all($sql);
     return $request;
 }
  public function selectProductoImagen($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM imagenes WHERE codigo LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }
 public function selectsubCategorias(){
     $sql = "SELECT * FROM subcategorias WHERE status != 2";
     $request = $this->select_all($sql);
     return $request;
 }
 
  public function selectProducto($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM productos WHERE idpro LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }       
 
 public function insertCarrito($idpro, $cantidad,$idus) {
    $this->intIdpro = $idpro;
    $this->intIdus = $idus;
    $this->intIdcantidad = $cantidad;
    $this->intstatus = "2";
    $sql ="SELECT * FROM productos WHERE idpro LIKE '$this->intIdpro'";
    $request1 = $this->select($sql);
    if($request1['stock'] == $cantidad || $request1['stock'] > $cantidad ){
        
    $query_insert = "INSERT INTO carrito (idpro, cantidad, idus, status) VALUES (?,?,?,?)";
    $arrData = array($this->intIdpro,$this->intIdcantidad,$this->intIdus,$this->intstatus);
    $request = $this->insert($query_insert,$arrData);
    return  $request;    
    }else{
    $request = "mayor";   
    }
    return $request;
     
 }
 
}

?>