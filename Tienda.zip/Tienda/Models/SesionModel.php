<?php

class SesionModel extends Mysql{
    public function __construct() {
        parent:: __construct();
        ; }
  public function loginEmail(string $email) {
     $this->strEmail= $email;
  $sql = "SELECT * FROM persona WHERE email LIKE '$this->strEmail' AND status != 0";
     $request = $this->select($sql);
     return $request;   
 }
        
    public function selectUsuario($idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 public function selectCategorias(){
     $sql = "SELECT * FROM categorias WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;
 }
 public function selectsubCategorias(){
     $sql = "SELECT * FROM subcategorias WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;
 }
        
        public function loginUser(string $usuario, string $contraseña) {
     $this->strContraseña = $contraseña;
     $this->strEmail = $usuario;
     $sql = "SELECT idus,status FROM persona WHERE email LIKE '$this->strEmail' AND Password LIKE '$this->strContraseña' AND status != 0";
     $request = $this->select($sql);
     return $request;
     
 }
 public function insertUsuario(string $nombre, string $apellido, string $email, int $telefono, string $password,  int $identificacion){
   
    $this->strNombre = $nombre;
    $this->strApellido = $apellido;
    $this->strEmail = $email;
    $this->intTelefono = $telefono;
    $this->intRol = 1;
    $this->strPassword = $password;
    $this->intStatus = 1;
    $this->intIdentificacion = $identificacion;
    $sql = "SELECT * FROM persona WHERE identificacionus = '{$this->intIdentificacion}'";
   $request = $this->select_all($sql);
   if(empty($request)){
       
   $sql = "SELECT * FROM persona WHERE email = '{$this->strEmail}'";
   $request = $this->select_all($sql);
   if(empty($request)){
    $query_insert = "INSERT INTO persona (nombreus,apellidous,email,telefono,rolid,Password,status,identificacionus) VALUES (?,?,?,?,?,?,?,?)";
    $arrData = array($this->strNombre, $this->strApellido, $this->strEmail, $this->intTelefono, $this->intRol,  $this->strPassword,$this->intStatus, $this->intIdentificacion);
    $request_insert = $this->insert($query_insert,$arrData);
    $return = $request_insert;
    }else{
       $request = "correo";
   }
   }else{
       $request = "exist";
   }
    return $request;
  }
  public function Email(string $email, string $pass) {
     $this->strEmail= $email;
     $this->strPass= $pass;
     $sql = "UPDATE persona SET Password = ? WHERE email = '$this->strEmail' AND status = 1; ";
     $array = array($this->strPass);
     $request = $this->update($sql,$array);
     return $request;   
 }
}
