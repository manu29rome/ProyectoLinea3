<?php


class UsuariosModel extends Mysql {
    public $intIdUsuario;
    public $strNombre;
    public $strApellido;
    public $strEmail;
    public $intTelefono;
    public $intRol;
    public $strPassword;
    public $intStatus;
    public $intIdentificacion;
    public function __construct() {
        parent:: __construct();
        ; }
        
 public function selectRol($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM rol WHERE idrol LIKE '$this->intIdrol'";
     $request = $this->select($sql);
     return $request;
 }       
  
 public function selectpermiso($idrol){
     $this->intIdrol = $idrol;
     $sql ="SELECT * FROM permisosrol WHERE rolid LIKE '$this->intIdrol'";
     $request = $this->select_all($sql);
     return $request;
 }
 
 public function selectUsuarios(){
     $sql = "SELECT * FROM persona WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;
 }

 public function insertUsuario(string $nombre, string $apellido, string $email, int $telefono, int $rolid, string $password, int $status,  int $identificacion){
    $return = "";  
    $this->strNombre = $nombre;
    $this->strApellido = $apellido;
    $this->strEmail = $email;
    $this->intTelefono = $telefono;
    $this->intRol = $rolid;
    $this->strPassword = $password;
    $this->intStatus = $status;
    $this->intIdentificacion = $identificacion;
    
    $sql = "SELECT * FROM persona WHERE identificacionus = '{$this->intIdentificacion}'";
   $request = $this->select_all($sql);
   if(empty($request)){
       
    $sql = "SELECT * FROM persona WHERE email = '{$this->strEmail}'";
   $request = $this->select_all($sql);
   if(empty($request)){
       
    $query_insert = "INSERT INTO persona (nombreus,apellidous,email,telefono,rolid,Password,status,identificacionus) VALUES (?,?,?,?,?,?,?,?)";
    $arrData = array($this->strNombre, $this->strApellido, $this->strEmail, $this->intTelefono, $this->intRol,  $this->strPassword,$this->intStatus, $this->intIdentificacion);
    $request_insert = $this->insert($query_insert,$arrData);
    return  $request_insert;
   }else{
       $request = "exist1";
   }
    
   }else{
       $request = "exist";
   }
    return $request;
  }
  public function selectUsuario($idUsuario){
     $this->intIdUsuario = $idUsuario;
     $sql ="SELECT * FROM persona WHERE idus = $this->intIdUsuario";
     $request = $this->select($sql);
     return $request;
 }
 
 public function selectUsuariosRol(){
   $sql = "SELECT * FROM rol WHERE status != 0";
     $request = $this->select_all($sql);
     return $request;  
 }
 
 public function selectUsuarioRol(int $rolid){
     $this->intRol = $rolid;
   $sql = "SELECT * FROM rol WHERE idrol = '$this->intRol'";
     $request = $this->select($sql);
     return $request;  
 }
 
  public function updateUsuario(int $idusuario, string $nombre, string $apellido, string $email, int $telefono, int $rolid, string $password, int $status,  int $identificacion){
$this->intIdUsuario = $idusuario;
$this->strNombre = $nombre;
$this->strApellido = $apellido;
$this->strEmail = $email;
$this->intTelefono = $telefono;
$this->intRol = $rolid;
$this->strPassword = $password;
$this->intStatus = $status;
$this->intIdentificacion = $identificacion;
$sql = "SELECT * FROM persona WHERE identificacionus = '$this->intIdentificacion ' AND idus != $this->intIdUsuario";
$request = $this->select_all($sql);

if(empty($request)){
    $sql = "UPDATE persona SET nombreus = ?, apellidous = ?, email = ?, telefono = ?, rolid = ?, Password = ?, status = ?, identificacionus = ? WHERE idus = $this->intIdUsuario";
    $arrData = array($this->strNombre,$this->strApellido,$this->strEmail,$this->intTelefono,$this->intRol,$this->strPassword,$this->intStatus,$this->intIdentificacion);
    $request = $this->update($sql,$arrData);
}else{
    $request = "exist";
}
return $request;
 } 
 
 public function deleteUsuario(int $idusuario){
    $this->intIdUsuario = $idusuario;
        $sql = "DELETE FROM `persona` WHERE `persona`.`idus` = $this->intIdUsuario";
        $request = $this->delete($sql);
        if($request){
            $request = 'ok';
        }else{
            $request = 'error';
        }
    
    return $request;
}
 
}
 ?>