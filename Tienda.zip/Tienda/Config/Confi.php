<?php
const BASE_URL = "http://localhost/Tienda/";
//ZONA HORARIA
date_default_timezone_set("America/Bogota");
const DB_HOST = "localhost";
const DB_NAME = "tienda1";
const DB_USER = "root";
const DB_PASSWORD = "";
const DB_CHARSET = "charset=utf8";
//DINEROo
const SPD = ".";
const SPM = ",";
//SIMBOLO DE DINERO
const MONEY = "COP";
?>

