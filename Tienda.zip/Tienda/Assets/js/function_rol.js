var tableRoles;
document.addEventListener('DOMContentLoaded',function(){
tablaRoles = $('#tableRoles').dataTable({
    "aProcesing":true,
    "aServerSde":true,
    "language":{
        "url":"//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
    },
    "ajax":{
        "url":""+base_url+"Roles/getRoles",
        "dataSrc":""
    },
    "columns":[
        {"data":"idrol"},
        {"data":"nombrerol"},
        {"data":"descripcion"},
        {"data":"status"},
        {"data":"options"}
    ],
    "resonsive":"true",
    "bDestroy":true,
    "iDisplayLength":9999999999999999999999999999999,
    "order":[[0,"desc"]]
});  
var formRol = document.querySelector("#formRol");
formRol.onsubmit = function(e){
   e.preventDefault(); 
   var intIdRol = document.querySelector('#idRol').value;
   var strNombre = document.querySelector("#txtNombre").value;
   var strDescripcion = document.querySelector("#txtDescripcion").value;
   var intStatus = document.querySelector("#listStatus").value;
   if(strNombre == '' || strDescripcion == ''|| intStatus == ''){
       swal("Atencion","Todos los campos son obligatorios","error");
       return false;
   }
   var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Roles/setRol';
   var formData = new FormData(formRol);
   request.open("POST",ajaxUrl,true);
   request.send(formData);
  
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
           $('#modalFormRol').modal("hide");
            formRol.reset();
           swal({
            title: "Roles de usuario",
            text: objData.msg,
            confirmButtonText: "Ok",
         },function(Confirm){
            if(Confirm){
                location.reload();
             }
         });
           }else{
               swal("Error", objData.msg, "error");
           }     
}}}

});



$('#tableRoles').DataTable();
function openModal(){
    document.querySelector('#idRol').value="";
    document.querySelector('#titleModal').innerHTML="Nuevo Rol";
    document.querySelector('#btnText').innerHTML="Guardar";
    document.querySelector('.modal-header').classList.replace("headerUpdate","headerResgister")
    document.querySelector('#btnActionForm').classList.replace("btn-info","btn-primary");
    document.querySelector('#formRol').reset();
    $('#modalFormRol').modal('show');
    
}


 function fntEditRol(){
     var btnEditRol = document.querySelectorAll(".btnEditRol");
     btnEditRol.forEach(function(btnEditRol){
         btnEditRol.addEventListener('click',function(){
            document.querySelector('#titleModal').innerHTML="Actualizar Rol";
            document.querySelector('#btnText').innerHTML="Actualizar";
            document.querySelector('.modal-header').classList.replace("headerResgister","headerUpdate");
            document.querySelector('#btnActionForm').classList.replace("btn-primary","btn-info");
            var idrol = this.getAttribute("rl");
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Roles/getRol/'+idrol;
            request.open("GET",ajaxUrl,true);
            request.send();
            request.onreadystatechange = function(){
                if(request.readyState == 4 && request.status == 200){
                    var objData = JSON.parse(request.responseText);
                    if(objData.status){
                      document.querySelector("#idRol").value = objData.msg.idrol;
                      document.querySelector("#txtNombre").value = objData.msg.nombrerol;
                      document.querySelector("#txtDescripcion").value = objData.msg.descripcion;
                      document.querySelector("#listStatus").value = objData.msg.status;
    
                     $('#modalFormRol').modal('show');
                    }else{
                        swal("Error",objData.msg,"error");
                    }
                }
            } });});
        } 

            function ftnDelRol(){
                var btnDelRol = document.querySelectorAll(".btnDelRol");
                btnDelRol.forEach(function(btnDelRol){
                    btnDelRol.addEventListener('click',function(){
                       var idrol = this.getAttribute("rl");
                       swal({
                       title: "Eliminar Rol",
                       text: "¿Esta seguro de querer Eliminar el Rol?",
                       type: "warning",
                       showCancelButton: true,
                       confirmButtonText: "Si, eliminar!",
                       cancelButtonText: "No, cancelar!",
                       closeOnConfirm: false,
                       closedOnCancel:true
                       },function(isConfirm){
                       if(isConfirm){
                        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
                        var ajaxUrl = base_url+'Roles/DelRol';
                        var strData = "idRol="+idrol;
                        request.open("POST",ajaxUrl,true);
                        request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                        request.send(strData);
                        request.onreadystatechange = function(){
                        if(request.readyState == 4 && request.status == 200){
                        var objData = JSON.parse(request.responseText);
                         if(objData.status){
                             swal({
                                title: "Eliminar!",
                                text: objData.msg,
                                confirmButtonText: "Ok",
                             },function(Confirm){
                                if(Confirm){
                                    location.reload();
                                 }
                             });
                             
                         }else{
                             swal("Atencion!", objData.msg , "error");
                         }
                        }   
                        }
                       }
                       } );
                });
               });
            }

  
  function fntPermisosRol(){
     var btnPermisosRol = document.querySelectorAll(".btnPermisosRol");
     btnPermisosRol.forEach(function(btnPermisosRol){
         btnPermisosRol.addEventListener('click',function(){
             var idrol = this.getAttribute("rl"); 
             
 var tablaRole;  
tablaRole = $('#tableRolPermisos').DataTable({
    "aProcesing":true,
    "aServerSde":true,
    "language":{
        "url":"//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
    },
    "ajax":{
        "url":""+base_url+"Roles/getPermisos/"+idrol,
        "dataSrc":""
    },
    "columns":[
        {"data":"opcionper"},
        {"data":"ver"},
        {"data":"editar"},
        {"data":"eliminar"},
        {"data":"anadir"} 
    ],
    "resonsive":"true",
    "bDestroy":true,
    "iDisplayLength":4,
    "order":[[0,"desc"]]
});
 $('#modalFormRolPermisos').modal('show');     
var formper = document.querySelector("#formper");
formper.onsubmit = function(o){
o.preventDefault();  

var d = document.querySelector("#idRol2").value;

   añadir();
   eliminar();
   ver();
   editar(); 
}
              });   })
     } 
     function Cerrar(){
       $('#modalFormRolPermisos').modal("hide");
           swal({
            title: "Permisos",
            text: "Se Actualizados correctamente",
            confirmButtonText: "Ok",
         },function(Confirm){
                                if(Confirm){
                                    location.reload();
                                 }
                             });  
     }
     
 
function ver(){
  var btnPermisosVER = document.querySelectorAll(".btnVer");
     btnPermisosVER.forEach(function(btnPermisosVER){
         btnPermisosVER.addEventListener('click',function(){
           
           var idrol = this.getAttribute("rl");
           document.querySelector("#idRol2").value = idrol;
           
           var valor = this.getAttribute("value"); 
           if(valor == 0 ){
            var ver = '<button value="1" rl="'+idrol+'" id="btnV'+idrol+'"  class="btn btn-info btn-sm btnVer"><i class="fa fa-toggle-on" aria-hidden="true"></i></button>';
            var valo = 1;
             }else{ 
            var ver = '<button value="0" rl="'+idrol+'" id="btnV'+idrol+'"  class="btn btn-secondary btn-sm btnVer" ><i class="fa fa-toggle-off" aria-hidden="true"></i></button>';
            var valo = 0;
             }
             
           document.querySelector("#btnV"+idrol).innerHTML = ver;
           
           document.querySelector("#boton").value = valo;
           var formper = document.querySelector("#formper");
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Roles/setPerVer';
            var formData = new FormData(formper);
            request.open("POST",ajaxUrl,true);
            request.send(formData);
         })
         }) 
     
}
function editar(){
  var btnPermisosElI = document.querySelectorAll(".btnEd");
     btnPermisosElI.forEach(function(btnPermisosElI){
         btnPermisosElI.addEventListener('click',function(){
           var idrol = this.getAttribute("rl"); 
           document.querySelector("#idRol2").value = idrol;
           var valor = this.getAttribute("value"); 
           
           if(valor == 0 ){
            var edi = '<button value="1" rl="'+idrol+'"  class="btn btn-info btn-sm btnEd"><i class="fa fa-toggle-on" aria-hidden="true"></i></button>';
           var valo = 1;
             }else{   
            var edi = '<button value="0" rl="'+idrol+'" class="btn btn-secondary btn-sm btnEd" ><i class="fa fa-toggle-off" aria-hidden="true"></i></button>';
           var valo= 0;
             }
           document.querySelector("#btnEd"+idrol).innerHTML = edi;
           
           document.querySelector("#boton").value = valo;
           var formper = document.querySelector("#formper");
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Roles/setPerEditar';
            var formData = new FormData(formper);
            request.open("POST",ajaxUrl,true);
            request.send(formData);
           
         })
         }) 
}
function eliminar(){
  var btnPermisosElI = document.querySelectorAll(".btnEliminar");
     btnPermisosElI.forEach(function(btnPermisosElI){
         btnPermisosElI.addEventListener('click',function(){
           var idrol = this.getAttribute("rl"); 
           document.querySelector("#idRol2").value = idrol;
           var valor = this.getAttribute("value"); 
           
           if(valor == 0 ){
            var eli = '<button value="1" rl="'+idrol+'"  class="btn btn-info btn-sm btnEliminar"><i class="fa fa-toggle-on" aria-hidden="true"></i></button>';
           var valo = 1;
             }else{    
            var eli = '<button value="0" rl="'+idrol+'" class="btn btn-secondary btn-sm btnEliminar" ><i class="fa fa-toggle-off" aria-hidden="true"></i></button>';
           var valo = 0;
             }
           document.querySelector("#btnEli"+idrol).innerHTML = eli;
           
           document.querySelector("#boton").value = valo;
           var formper = document.querySelector("#formper");
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Roles/setPerEliminar';
            var formData = new FormData(formper);
            request.open("POST",ajaxUrl,true);
            request.send(formData);
           
           
         })
         }) 
}
function añadir(){
  var btnPermisosElI = document.querySelectorAll(".btnAñadir");
     btnPermisosElI.forEach(function(btnPermisosElI){
         btnPermisosElI.addEventListener('click',function(){
           var idrol = this.getAttribute("rl"); 
           document.querySelector("#idRol2").value = idrol;
           var valor = this.getAttribute("value"); 
           
           if(valor == 0 ){
            var aña = '<button value="1" rl="'+idrol+'"  class="btn btn-info btn-sm btnAñadir"><i class="fa fa-toggle-on" aria-hidden="true"></i></button>';
           var valo = 1;
             }else{   
            var aña = '<button value="0" rl="'+idrol+'" class="btn btn-secondary btn-sm btnAñadir" ><i class="fa fa-toggle-off" aria-hidden="true"></i></button>';
           var valo = 0;
             }
           document.querySelector("#btnAña"+idrol).innerHTML = aña;
           
            document.querySelector("#boton").value = valo;
           var formper = document.querySelector("#formper");
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Roles/setPerAñadir';
            var formData = new FormData(formper);
            request.open("POST",ajaxUrl,true);
            request.send(formData);
           
         })
         }) 
}
$('#tableRolPermisos').DataTable();
$(document).ready(function(){
    setTimeout(() => { 
 fntEditRol();
    ftnDelRol();
    fntPermisosRol();    
    
    }, 500);
})




