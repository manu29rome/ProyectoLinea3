document.addEventListener('DOMContentLoaded',function(){
mun();    
});

function comprar(){
    var formc = document.querySelector(".muni");
                        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
                        var ajaxUrl = base_url+'Compra/getComprar';
                        var formData = new FormData(formc)
                        request.open("POST",ajaxUrl,true);
                        request.send(formData);  
                        request.onreadystatechange = function(){
                        if(request.readyState == 4 && request.status == 200){
                        var objData = JSON.parse(request.responseText);
                         if(objData.status){
                                    location.reload();
                             
                         }else{
                             swal("Atencion!", objData.msg , "error");
                         }
                        }   
                        }
                       
                       
}
function mun(){
   var formc = document.querySelector(".muni");
   
    var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Compra/getciudad';
   var formData = new FormData(formc);
   request.open("POST",ajaxUrl,true);
   request.send(formData);
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
           document.querySelector("#n").innerHTML=objData.msg.p;
           }else{
               swal("Error", objData.msg, "error");
           }     
}}
}

function ftnDelp(){
                var btnDelCategoria = document.querySelectorAll(".ftnDelp");
                btnDelCategoria.forEach(function(btnDelCategoria){
                    btnDelCategoria.addEventListener('click',function(){
                       var idrol = this.getAttribute("rl");
                       
                        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
                        var ajaxUrl = base_url+'Compra/del';
                        var strData = "subidCa="+idrol;
                        request.open("POST",ajaxUrl,true);
                        request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                        request.send(strData);
                        request.onreadystatechange = function(){
                        if(request.readyState == 4 && request.status == 200){
                        var objData = JSON.parse(request.responseText);
                         if(objData.status){
                            
                                    location.reload();
                                
                             
                         }else{
                             swal("Atencion!", objData.msg , "error");
                         }
                        }   
                        }
                       
                       } );
              
               });
            }
$(document).ready(function(){
    setTimeout(() => { 
ftnDelp();
   }, 500);
})

function Abrir(){
    let t = document.querySelector("#tp").value;
    if(t == "0.00 COP"){
        swal("Alert", "No tienes productos en tu carrito", "error");
    }else{
       var formc = document.querySelector(".muni");
    var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Compra/codigo';
    var formData = new FormData(formc);
   request.open("POST",ajaxUrl,true);
   request.send(formData);
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
            document.querySelector("#np").value = objData.msg.cod;
            document.querySelector(".d").innerHTML=' <h5 class="modal-title">Numero de Pedido: '+objData.msg.cod+'</h5>';
           $('#modalpago').modal('show');  
           }else{
               swal("Error", objData.msg, "error");
           }     
}}  
    }
    
                              
}
