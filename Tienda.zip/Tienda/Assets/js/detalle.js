
 var formpro = document.querySelector("#producto");
function carri(){
    var cantidad = document.querySelector('#num-product').value;
    
   if(cantidad != 0){
    var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Home/getProductos';
   var formData = new FormData(formpro);
   request.open("POST",ajaxUrl,true);
   request.send(formData);  
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
             swal("Atencion",objData.msg,"success"); 
             actualizar();
           $('.js-modal1').removeClass('show-modal1');
           
           }else{
               swal("Atencion", objData.msg);
           }     
}}
   
   }else{
               swal("Atencion", "La cantidad minima es 1 articulo", "error");
           }
    }
    
function actualizar(){
    
     var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Home/getAcutualizar';
   var formData = new FormData(formpro);
   request.open("POST",ajaxUrl,true);
   request.send(formData);  
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
             document.querySelector("#carrito").innerHTML=""+objData.msg.carrito;
             document.querySelector("#total").innerHTML=""+objData.msg.total;
document.querySelector("#carritos").innerHTML='<div class="icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 icon-header-noti js-show-cart" data-notify="'+objData.msg.carri+'"><i class="zmdi zmdi-shopping-cart"></i>';
        abrir();
           }else{
               swal("Atencion", objData.msg);
           }     
}}
    
}
function abrir(){
    $('.js-show-cart').on('click',function(){
        $('.js-panel-cart').addClass('show-header-cart');
    });

    $('.js-hide-cart').on('click',function(){
        $('.js-panel-cart').removeClass('show-header-cart');
    });
}
