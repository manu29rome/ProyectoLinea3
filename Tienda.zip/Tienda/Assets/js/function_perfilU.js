var formuser = document.querySelector("#editarUsuario");
formuser.onsubmit = function(e){
   e.preventDefault(); 
   var strNombre = document.querySelector("#txtnombre").value;
   var strApellido= document.querySelector("#txtapellido").value;
   var intTelefono = document.querySelector("#txttelefono").value;
   var strContraseña = document.querySelector("#contraseña").value;
   var strContra = document.querySelector("#contraseñareset").value;
    if(strNombre == "" || strApellido == "" || intTelefono == "" ){
      swal("Atencion","No deje espacios en blanco","error");
       return false;  
    }else {
   if(strContraseña == strContra){
   var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Perfil/setUsuario';
   var formData = new FormData(formuser);
   request.open("POST",ajaxUrl,true);
   request.send(formData);
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
           swal({
            title: "Usuario",
            text: objData.msg,
            confirmButtonText: "Ok",
             },function(Confirm){
              if(Confirm){
                location.reload();
             }
             });
        }else{
               swal("Error",objData.msg, "error");
           }
    }

     } 
 }else{ swal("Atencion","La Contraseña no coincide","error");
    document.querySelector("#contraseñareset").value = "";
       
       }
}
    
}

function solonumeros(evt){
 if(window.event){
     keynum = evt.keyCode;
 }else{
     keynum = evt.which;
 }if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13){
     return true;
 }else{
      swal({
            title: "¡Advertencia!",
            text: "Ingrese solo numeros",
            confirmButtonText: "Ok",
         });
 }
     
}
function sololetras(e){
   key = e.keyCode || e.which;
   tecla = String.fromCharCode(key).toString();
   letras= "ABCDEFGHIJKLMNÑOPQRSOPQTWXYZabcdefghijklmñnopqrstuvwxyzáéíóú";
   especiales = [8,13];
   tecla_especial = false
   for(var i in especiales){
       if(key == especiales[i]){
         tecla_especial = true;
         break;
       }
   }
   if(letras.indexOf(tecla)== -1 && !tecla_especial){
      swal({
            title: "Nombre y/o Apellido",
            text: "Ingrese solo letras",
            confirmButtonText: "Ok",
         }); 
         return false;
   }
       
}

