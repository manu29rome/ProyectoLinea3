function openModal(){
    document.querySelector('#idsubCa').value="";
    document.querySelector('#titleModal').innerHTML="Nueva Subcategoria";
    document.querySelector('#btnText').innerHTML="Guardar";
    document.querySelector('.modal-header').classList.replace("headerUpdate","headerResgister")
    document.querySelector('#btnActionForm').classList.replace("btn-info","btn-primary");
    document.querySelector('#subidCama').value = "";
    document.querySelector("#subtxtNombreca").value = "";
    document.querySelector("#subtxtDescripcionca").value = "";
    var imagen = '<label>Imagen(809x1200)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg">';         
   document.querySelector(".imag").innerHTML=imagen;
    document.querySelector("#boton").innerHTML='';
    $('#modalFormsubCategorias').modal('show');
     var imagenes = '';         
   document.querySelector(".ima").innerHTML=imagenes;
   document.querySelector("#nom").value = "0";
    document.querySelector("#nom1").value = "0";
}

var tableRoles;
document.addEventListener('DOMContentLoaded',function(){
tablaRoles = $('#tablesubCategorias').dataTable({
    "aProcesing":true,
    "aServerSde":true,
    "language":{
        "url":"//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
    },
    "ajax":{
        "url":base_url+"Subcategoria/setsubCategorias",
        "dataSrc":""
    },
    "columns":[
        {"data":"idsubca"},
        {"data":"subcategoria"},
        {"data":"descripcion"},
        {"data":"categorias"},
        {"data":"status"},
        {"data":"imagen"},
        {"data":"options"}
    ],
    "resonsive":"true",
    "bDestroy":true,
    "iDisplayLength":9999999999999999999999999999999,
    "order":[[0,"desc"]]
}); 
var formsub = document.querySelector("#formsubCategorias");
formsub.onsubmit = function(e){
   e.preventDefault(); 
   var intIdRol = document.querySelector('#idsubCa').value;
   var strNombre = document.querySelector("#subtxtNombreca").value;
   var strDescripcion = document.querySelector("#subtxtDescripcionca").value;
   var intStatus = document.querySelector("#sublistStatusca").value;
   var categoria = document.querySelector("#Listsubca").value;
   if(strNombre == '' || strDescripcion == ''|| intStatus == '' ){
       swal("Atencion","Todos los campos son obligatorios","error");
       return false;
   }else if(categoria == 0){
      swal("Atencion","Elija una Categoria","error");
   }
    else{
   var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Subcategoria/getsubCategorias';
   var formData = new FormData(formsub);
   request.open("POST",ajaxUrl,true);
   request.send(formData);
  
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
           $('#modalFormsubCategorias').modal("hide");
            
           swal({
            title: "Subcategoria",
            text: objData.msg,
            confirmButtonText: "Ok",
         },function(Confirm){
            if(Confirm){
                location.reload();
             }
         });
           
           }else{
               swal("Error", objData.msg, "error");
           }     
}} }};

});
$(document).on("click",".imag",function(){
   $("#subimagenca").click(); 
})

$(document).on("change","#subimagenca",function(){
   
   var file = this.files;
   var element;
   var supporteimagenes=["image/jpeg","image/png","image/gif"];
   var seencontrarolElemteos = false;
   for(var i = 0;i < file.length; i++){
       element = file[i];
       if(supporteimagenes.indexOf(element.type) != -1){
         create(element);  
       }
   }
       
   
})

function no(){
   var imagenes = '';         
   document.querySelector(".ima").innerHTML=imagenes;
   document.querySelector("#boton").innerHTML='';
   document.querySelector("#subimagenca").value= "";
   let total = document.querySelector("#nom").value;
   
   if(total == 0){
      var imagen = '<label>Foto(809x1200)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg">';         
   document.querySelector(".imag").innerHTML=imagen;  
   }else{
       let nombre = document.querySelector("#nom1").value;
     var imagen = '<label>Imagen '+nombre+'</label><br><img style=" width: 80%" src="'+total+'">';   
      document.querySelector(".ima").innerHTML='<input type="checkbox" onclick="valor()" id="valorima" name="valorima">  Ninguna imagen';
   document.querySelector(".imag").innerHTML=imagen;     
   }
}

function create(file){
    var imgCodified = URL.createObjectURL(file);
    var valor = document.querySelector("#subidCama").value;
    if(valor == 0){
    var imagenes = '<br><img style="width: 80%;" src="'+imgCodified+'">';         
   document.querySelector(".imag").innerHTML=imagenes;
    document.querySelector("#boton").innerHTML='<button type="button" onclick="no()" style="background-color: transparent;border: none">X</button>';
}else{
   var imagenes = '<br><img style="width: 80%;" src="'+imgCodified+'">';         
   document.querySelector(".imag").innerHTML=imagenes;
    document.querySelector("#boton").innerHTML='<button type="button" onclick="no()" style="background-color: transparent;border: none">X</button>';
}

}
function fntEditsubCategoria(){
     var btnEditCategoria= document.querySelectorAll(".btnEditsubCategoria");
     btnEditCategoria.forEach(function(btnEditCategoria){
         btnEditCategoria.addEventListener('click',function(){
            document.querySelector('#titleModal').innerHTML="Actualizar Subcategoria";
            document.querySelector('#btnText').innerHTML="Actualizar";
            document.querySelector('.modal-header').classList.replace("headerResgister","headerUpdate");
            document.querySelector('#btnActionForm').classList.replace("btn-primary","btn-info");
            document.querySelector("#boton").innerHTML='';
              document.querySelector("#subimagenca").value= "";
              document.querySelector("#nom").value = "0";
              document.querySelector("#nom1").value = "0";
            var idrol = this.getAttribute("rl");
            document.querySelector(".ima").innerHTML='';
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Subcategoria/getsubCategoria/'+idrol;
            request.open("GET",ajaxUrl,true);
            request.send();
            request.onreadystatechange = function(){
                if(request.readyState == 4 && request.status == 200){
                    var objData = JSON.parse(request.responseText);
                    if(objData.status){
                      document.querySelector("#idsubCa").value = objData.msg.idsubca;
                      document.querySelector("#subtxtNombreca").value = objData.msg.subcategoria;
                      document.querySelector("#subtxtDescripcionca").value = objData.msg.descripcion;
                      document.querySelector("#sublistStatusca").value = objData.msg.status;
                      document.querySelector("#Listsubca").value = objData.msg.idca;
                      document.querySelector("#subfoto").value = objData.msg.imagenes;
                      
                      var a = objData.msg.imagen;
                      let b = objData.msg.imagenes;
                      
                      if(a != "Assets/Images/subCategorias/"){
                      var imagen = '<label >Imagen '+b+'</label><br><img src="'+a+'" style="width: 80%"><br>';         
                          document.querySelector(".imag").innerHTML=imagen;
                          document.querySelector(".ima").innerHTML='<input type="checkbox" onclick="valor()" id="valorima" name="valorima">  Ninguna imagen';
                          document.querySelector("#nom").value = objData.msg.imagen;
                           document.querySelector("#nom1").value = b;
                        }else{
                       var imagen = '<label>Foto(809x1200)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg"><br> ';         
                          document.querySelector(".imag").innerHTML=imagen; 
                          document.querySelector(".ima").innerHTML='';
                          document.querySelector("#nom").value = "0";
                          document.querySelector("#nom1").value = "0";
                      }
                     $('#modalFormsubCategorias').modal('show');
                    }else{
                        swal("Error",objData.msg,"error");
                    }
                }
            } });});
        }
        
        function valor(){
    var valor = document.querySelector("#subidCama").value;
    if(valor == 1){
      document.querySelector("#subidCama").value = "0";
      
    }else if(valor == 0){
      document.querySelector("#subidCama").value = "1";  
      
    }}

$(document).ready(function(){
    setTimeout(() => { 
  fntEditsubCategoria();
  ftnDelsubCategoria();
}, 500);
})

 function ftnDelsubCategoria(){
                var btnDelCategoria = document.querySelectorAll(".btnDesubCategoria");
                btnDelCategoria.forEach(function(btnDelCategoria){
                    btnDelCategoria.addEventListener('click',function(){
                       var idrol = this.getAttribute("rl");
                       swal({
                       title: "Eliminar Categoria",
                       text: "¿Esta seguro de querer Eliminar la Categoria?",
                       type: "warning",
                       showCancelButton: true,
                       confirmButtonText: "Si, eliminar!",
                       cancelButtonText: "No, cancelar!",
                       closeOnConfirm: false,
                       closedOnCancel:true
                       },function(isConfirm){
                       if(isConfirm){
                        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
                        var ajaxUrl = base_url+'Subcategoria/DelsubCategoria';
                        var strData = "subidCa="+idrol;
                        request.open("POST",ajaxUrl,true);
                        request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                        request.send(strData);
                        request.onreadystatechange = function(){
                        if(request.readyState == 4 && request.status == 200){
                        var objData = JSON.parse(request.responseText);
                         if(objData.status){
                             swal({
                                title: "Eliminar!",
                                text: objData.msg,
                                confirmButtonText: "Ok",
                             },function(Confirm){
                                if(Confirm){
                                    location.reload();
                                 }
                             });
                             
                         }else{
                             swal("Atencion!", objData.msg , "error");
                         }
                        }   
                        }
                       }
                       } );
                });
               });
            }

