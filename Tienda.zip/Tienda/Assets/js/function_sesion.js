document.addEventListener('DOMContentLoaded',function(){
   $(document.querySelector("#formlogin"));
   let FormLogin = document.querySelector("#formlogin");
   FormLogin.onsubmit = function(e){
    e.preventDefault();
    
    let strEmail = document.querySelector("#txtEmail").value;
    let strContraseña = document.querySelector("#txtContraseña").value;
    document.querySelector("#txtEmailReset").value = strEmail;
    
    if(strEmail == "" || strContraseña == ""){
        swal("Por favor","No deje Espacion en Blanco","error");
        return false;  
    }else{
   var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Sesion/loginUser';
   var formData = new FormData(FormLogin);
   request.open("POST",ajaxUrl,true);
   request.send(formData);
   
   request.onreadystatechange = function(){
   if(request.readyState != 4)return;
   if(request.status == 200){
       var objData = JSON.parse(request.responseText);
       if(objData.status){
           
             window.location = base_url+'home';
             
           
       }else{
           swal("Atencion",objData.msg, "error");
           document.querySelector("#txtContraseña").value = "";
       }
   }else{
       swal("Atencion","Error en el proceso","error")
   }
   }
    }
   }
},false);

var formReset = document.querySelector("#recuperar_contraseña");
formReset.onsubmit = function(o){
   o.preventDefault(); 
 let strEmailReset = document.querySelector("#txtEmailReset").value;
 
 if(strEmailReset == ""){
   swal("Por favor","No deje Espacion en Blanco","error");
   return false;  
 }else{
   var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Sesion/email';
   var formData = new FormData(formReset);
   request.open("POST",ajaxUrl,true);
   request.send(formData);  
   
   request.onreadystatechange = function(){
   if(request.readyState != 4)return;
   if(request.status == 200){
       var objData = JSON.parse(request.responseText);
       if(objData.status){
           
           swal("Atencion",objData.msg,"success"); 
           
          
       }else{
           swal("Atencion",objData.msg, "error");
       }
   }else{
       swal("Atencion","Error en el proceso","error")
   }
   }
 }
}


   

var formuser = document.querySelector("#formregistro");
formuser.onsubmit = function(e){
   e.preventDefault(); 
   var strNombre = document.querySelector("#txtnombre").value;
   var intIdentificacion = document.querySelector("#txtidentificacion").value;
   var strApellido= document.querySelector("#txtapellido").value;
   var intTelefono = document.querySelector("#txttelefono").value;
   var strEmail = document.querySelector("#txtemail").value;
   var strContraseña = document.querySelector("#contraseña").value;
   var strContra = document.querySelector("#contraseñareset").value;
    if(strNombre == "" || intIdentificacion == "" || strApellido == "" || intTelefono == "" || strEmail == "" || strContraseña == "" || strContra == "" ){
      swal("Atencion","No deje espacios en blanco","error");
       return false;  
    }else {
   if(strContraseña == strContra){
   var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Sesion/getUsuario';
   var formData = new FormData(formuser);
   request.open("POST",ajaxUrl,true);
   request.send(formData);
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
    document.querySelector("#txtEmail").value = strEmail;        
    document.querySelector("#txtnombre").value = "";
    document.querySelector("#txtidentificacion").value = "";
    document.querySelector("#txtapellido").value = "";
    document.querySelector("#txttelefono").value = "";
    document.querySelector("#txtemail").value = "";
    document.querySelector("#contraseña").value = "";
    document.querySelector("#contraseñareset").value = "";
          swal("Atencion",objData.msg+" Inicie sesion por favor", "success");  
          document.querySelector("#txtEmail").focus();
        }else{
               swal("Error",objData.msg, "error");
           }
    }

     } 
 }else{ swal("Atencion","La Contraseña no coincide","error");
    document.querySelector("#contraseñareset").value = "";
       
       }
}
    
}

function solonumeros(evt){
 if(window.event){
     keynum = evt.keyCode;
 }else{
     keynum = evt.which;
 }if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13){
     return true;
 }else{
      swal({
            title: "¡Advertencia!",
            text: "Ingrese solo numeros",
            confirmButtonText: "Ok",
         });
 }
     
}
function sololetras(e){
   key = e.keyCode || e.which;
   tecla = String.fromCharCode(key).toString();
   letras= "ABCDEFGHIJKLMNÑOPQRSOPQTWXYZabcdefghijklmñnopqrstuvwxyzáéíóú";
   especiales = [8,13];
   tecla_especial = false
   for(var i in especiales){
       if(key == especiales[i]){
         tecla_especial = true;
         break;
       }
   }
   if(letras.indexOf(tecla)== -1 && !tecla_especial){
      swal({
            title: "Nombre y/o Apellido",
            text: "Ingrese solo letras",
            confirmButtonText: "Ok",
         }); 
         return false;
   }
       
}
