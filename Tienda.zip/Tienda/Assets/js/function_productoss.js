function openModal(){
    document.querySelector('#idsubCa').value="";
    document.querySelector('#titleModal').innerHTML="Nuevo Producto";
    document.querySelector('#btnText').innerHTML="Guardar";
    document.querySelector('.modal-header').classList.replace("headerUpdate","headerResgister")
    document.querySelector('#btnActionForm').classList.replace("btn-info","btn-primary");
    document.querySelector('#subidCama').value = "";
    document.querySelector("#subtxtNombreca").value = "";
    document.querySelector("#txtCodigo").value = "";
    document.querySelector("#codg").value = "";
    document.querySelector("#txtPrecio").value = "";
    document.querySelector("#txtStock").value = "";
    document.querySelector('#edito').value = "";
    document.querySelector('#in').value = "";
    document.querySelector("#txtCodigo").disabled = false;
    var i = ' <button class="btn btn-info " type="button" onclick="imagenes()" >Agregar imagen <i class="fa fa-plus" aria-hidden="true"></i></button>';
    document.querySelector("#i").innerHTML=i;
    var imagen = '<span></span>'
    document.querySelector(".imag").innerHTML=imagen;
    document.querySelector(".imag2").innerHTML=imagen;
    document.querySelector(".imag3").innerHTML=imagen;  
    document.querySelector('#codigoBarras').innerHTML='<span></span>';
    eliminar();
    $('#modalFormProductos').modal('show');
    var imagenes = '';         
    document.querySelector(".ima").innerHTML=imagenes;
     document.querySelector("#nom").value = "0";
    document.querySelector("#nom1").value = "0";
     document.querySelector("#nom2").value = "0";
    document.querySelector("#nom3").value = "0";
     document.querySelector("#nom4").value = "0";
    document.querySelector("#nom5").value = "0";
    document.querySelector("#boton").innerHTML='';
    document.querySelector("#boton2").innerHTML='';
    document.querySelector("#boton1").innerHTML='';
}


var tableRoles;
document.addEventListener('DOMContentLoaded',function(){
tablaRoles = $('#tableProductos').dataTable({
    "aProcesing":true,
    "aServerSde":true,
    "language":{
        "url":"//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
    },
    "ajax":{
        "url":base_url+"Productos/setProductos",
        "dataSrc":""
    },
    "columns":[
        {"data":"codigo"},
        {"data":"producto"},
        {"data":"stock"},
        {"data":"precio"},
        {"data":"subcategorias"},
        {"data":"status"},
        {"data":"options"}
    ],
    "resonsive":"true",
    "bDestroy":true,
    "iDisplayLength":9999999999999999999999999999999,
    "order":[[0,"desc"]]
});
   var formpro = document.querySelector("#formsProductos");
   formpro.onsubmit = function(e){
   e.preventDefault(); 
   guardar();
   var intIdRol = document.querySelector('#idsubCa').value;
   var strNombre = document.querySelector("#subtxtNombreca").value;
   var strDescripcion = document.querySelector("#edito").value;
   var codigo = document.querySelector('#txtCodigo').value;
   var precio = document.querySelector("#txtPrecio").value;
   var cantidad = document.querySelector("#txtStock").value;
  
   if(strNombre == '' || strDescripcion == '<p><br></p>'|| codigo == '' || precio == ''|| cantidad == '' ){
       swal("Atencion","Todos los campos son obligatorios","error");
       return false;
   }
    else{
   var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Productos/getProductos';
   var formData = new FormData(formpro);
   request.open("POST",ajaxUrl,true);
   request.send(formData);
  
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
           $('#modalFormProductos').modal("hide");
            
           swal({
            title: "Subcategoria",
            text: objData.msg,
            confirmButtonText: "Ok",
         },function(Confirm){
            if(Confirm){
                location.reload();
             }
         });
           
           }else{
               swal("Error", objData.msg, "error");
           }     
}} }}; });

function vercodigo(){
 let a = document.querySelector("#txtCodigo").value;
 if(a > 9999 && a < 100000) {
 document.querySelector('#codigoBarras').innerHTML='<div id="barras"> <svg id="barcode"></svg> </div><button type="button" onclick="imprimir()" class="btn badge-primary">Imprimir<i class="fa fa-print" aria-hidden="true"></i></button>';
 JsBarcode("#barcode", a, {
            format: "codabar",
            lineColor: "#000",
            width: 3,
            height: 60,
            displayValue: true  });
    }else{
 document.querySelector('#codigoBarras').innerHTML='<span></span>';
 swal({
    title: "¡Advertencia!",
            text: "Ingrese solo 5 numeros",
            confirmButtonText: "Ok",
         });
             }
}

function imprimir(){
  var a = document.querySelector('#barras');
  var ventana = window.open('', 'PRINT', 'height=400,width=600');
  ventana.document.write('<html><head><title>' + document.title + '</title>');
  ventana.document.write('</head><body >');
  ventana.document.write(a.innerHTML);
  ventana.document.write('</body></html>');
  ventana.document.close();
  ventana.focus();
  ventana.print();
  ventana.close();
  return true;

}

function solonumeros(evt){
 if(window.event){
     keynum = evt.keyCode;
 }else{
     keynum = evt.which;
 }if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13){ 
     
 return true;
 }else{

      swal({
            title: "¡Advertencia!",
            text: "Ingrese solo numeros",
            confirmButtonText: "Ok",
         });
 } 
}
$(document).on("click",".imag",function(){
   $("#subimagenca").click(); 
})

$(document).on("change","#subimagenca",function(){
   console.log(this.files); 
   var file = this.files;
   var elemento;
   var supporteimagene=["image/jpeg","image/png","image/gif"];
   var seencontrarolElemteos = false;
   for(var i = 0;i < file.length; i++){
       elemento = file[i];
       if(supporteimagene.indexOf(elemento.type) != -1){
         create(elemento);  
       }else{
          swal({
            title: "¡Advertencia!",
            text: "No es una imagen",
            confirmButtonText: "Ok",
         }); 
       }
   }
})

function no(){
   var imagenes = '';         
   document.querySelector(".ima").innerHTML=imagenes;
   document.querySelector("#boton").innerHTML='';
   document.querySelector("#subimagenca").value= "";
   let total = document.querySelector("#nom").value;
   
   if(total == 0){
      var imagen = '<label>Imagen(1200x1486)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg">';         
   document.querySelector(".imag").innerHTML=imagen;  
   }else{
       let nombre = document.querySelector("#nom1").value;
     var imagen = '<label>Imagen '+nombre+'</label><br><img style=" width: 80%" src="'+total+'">';   
      document.querySelector(".ima").innerHTML='<input type="checkbox" onclick="valor()" id="valorima" name="valorima">  Ninguna imagen';
   document.querySelector(".imag").innerHTML=imagen;     
   }
}
function no2(){
   var imagenes = '';         
   document.querySelector(".ima2").innerHTML=imagenes;
   document.querySelector("#boton1").innerHTML='';
   document.querySelector("#subimagenca2").value= "";
   let total = document.querySelector("#nom2").value;
   
   if(total == 0){
      var imagen = '<label>Imagen(1200x1486)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg">';         
   document.querySelector(".imag2").innerHTML=imagen;  
   }else{
       let nombre = document.querySelector("#nom3").value;
     var imagen = '<label>Imagen '+nombre+'</label><br><img style=" width: 80%" src="'+total+'">';   
      document.querySelector(".ima2").innerHTML='<input type="checkbox" onclick="valor()" id="valorima" name="valorima">  Ninguna imagen';
   document.querySelector(".imag2").innerHTML=imagen;     
   }
}

function no3(){
   var imagenes = '';         
   document.querySelector(".ima3").innerHTML=imagenes;
   document.querySelector("#boton2").innerHTML='';
   document.querySelector("#subimagenca3").value= "";
   let total = document.querySelector("#nom4").value;
   
   if(total == 0){
      var imagen = '<label>Imagen(1200x1486)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg">';         
   document.querySelector(".imag3").innerHTML=imagen;  
   }else{
       let nombre = document.querySelector("#nom5").value;
     var imagen = '<label>Imagen '+nombre+'</label><br><img style=" width: 80%" src="'+total+'">';   
      document.querySelector(".ima3").innerHTML='<input type="checkbox" onclick="valor()" id="valorima" name="valorima">  Ninguna imagen';
   document.querySelector(".imag3").innerHTML=imagen;     
   }
}

function create(file){
    var imgCodified = URL.createObjectURL(file);
    var valor = document.querySelector("#subidCama").value;
    if(valor == ""){
    var imagenes = '<br><img style="width: 80%;" src="'+imgCodified+'">';         
   document.querySelector(".imag").innerHTML=imagenes;
    document.querySelector("#boton").innerHTML='<button type="button" onclick="no()" style="background-color: transparent;border: none">X</button>';
}else{
    var imagenes = '<br><img style="width: 80%;" src="'+imgCodified+'">';         
   document.querySelector(".imag").innerHTML=imagenes;
    document.querySelector("#boton").innerHTML='<button type="button" onclick="no()" style="background-color: transparent;border: none">X</button>';
}
}
$(document).on("click",".imag2",function(){
   $("#subimagenca2").click(); 
})

$(document).on("change","#subimagenca2",function(){
   console.log(this.files); 
   var file = this.files;
   
   var elemento;
   var supporteimagene=["image/jpeg","image/png","image/gif"];
   var seencontrarolElemteos = false;
   for(var i = 0;i < file.length; i++){
       elemento = file[i];
       if(supporteimagene.indexOf(elemento.type) != -1){
         create2(elemento);  
       }else{
          swal({
            title: "¡Advertencia!",
            text: "No es una imagen",
            confirmButtonText: "Ok",
         }); 
       }
   }
})

function create2(file){
    var imgCodified = URL.createObjectURL(file);
    var valor = document.querySelector("#subidCama").value;
    
    if(valor == ""){
    var imagenes = '<br><img style="width: 80%;" src="'+imgCodified+'">';         
   document.querySelector(".imag2").innerHTML=imagenes;
   document.querySelector("#boton1").innerHTML='<button type="button" onclick="no2()" style="background-color: transparent;border: none">X</button>';
}else{
    var imagenes = '<br><img style="width: 80%;" src="'+imgCodified+'">';         
   document.querySelector(".imag2").innerHTML=imagenes;
   document.querySelector("#boton1").innerHTML='<button type="button" onclick="no2()" style="background-color: transparent;border: none">X</button>';
}
    
}
$(document).on("click",".imag3",function(){
   $("#subimagenca3").click(); 
})

$(document).on("change","#subimagenca3",function(){
   console.log(this.files); 
   var file = this.files;
   var elemento;
   var supporteimagene=["image/jpeg","image/png","image/gif"];
   var seencontrarolElemteos = false;
   for(var i = 0;i < file.length; i++){
       elemento = file[i];
       if(supporteimagene.indexOf(elemento.type) != -1){
         create3(elemento);  
       }else{
          swal({
            title: "¡Advertencia!",
            text: "No es una imagen",
            confirmButtonText: "Ok",
         }); 
       }
   }
})

function create3(file){
    var imgCodified = URL.createObjectURL(file);
    var valor = document.querySelector("#subidCama").value;
    if(valor == ""){
    var imagenes = '<br><img style="width: 80%;" src="'+imgCodified+'">';         
   document.querySelector(".imag3").innerHTML=imagenes;
   document.querySelector("#boton2").innerHTML='<button type="button" onclick="no3()" style="background-color: transparent;border: none">X</button>';
}else{
    var imagenes = '<br><img style="width: 80%;" src="'+imgCodified+'">';         
   document.querySelector(".imag3").innerHTML=imagenes;
   document.querySelector("#boton2").innerHTML='<button type="button" onclick="no3()" style="background-color: transparent;border: none">X</button>';
}
}
function imagenes(){
    var imagen = '<label>Imagen(1200x1486)label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg">';         
    var boton = '<span></span>';
    var f = document.querySelector('#in').value;
    var n = f+1;
    document.querySelector('#in').value = n;
   
    if(n == 1){
    document.querySelector(".imag").innerHTML=imagen;
  } if(n == 11){
    document.querySelector(".imag2").innerHTML=imagen;
    }if(n == 111){
    document.querySelector(".imag3").innerHTML=imagen; 
    document.querySelector("#i").innerHTML=boton; 
    }
   
}


function fntEditProducto(){
    var btnEditProductos= document.querySelectorAll(".btnEditProducto");
    btnEditProductos.forEach(function(btnEditProductos){
         btnEditProductos.addEventListener('click',function(){
            document.querySelector('#titleModal').innerHTML="Actualizar Producto";
            document.querySelector('#btnText').innerHTML="Actualizar";
            document.querySelector('.modal-header').classList.replace("headerResgister","headerUpdate");
            document.querySelector('#btnActionForm').classList.replace("btn-primary","btn-info"); 
            var idrol = this.getAttribute("rl");
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Productos/getProducto/'+idrol;
            request.open("GET",ajaxUrl,true);
            request.send();
            request.onreadystatechange = function(){
                if(request.readyState == 4 && request.status == 200){
                    var objData = JSON.parse(request.responseText);
                    if(objData.status){
                      document.querySelector("#idsubCa").value = idrol;
                      document.querySelector("#subtxtNombreca").value = objData.msg.producto;
                      document.querySelector("#sublistStatusca").value = objData.msg.status;
                      document.querySelector("#Listsubca").value = objData.msg.idca;
                      document.querySelector("#txtCodigo").value = objData.msg.codigo;
                      document.querySelector("#txtPrecio").value = objData.msg.precio;
                      document.querySelector("#txtCodigo").disabled = true;
                      document.querySelector("#codg").value = objData.msg.codigo;
                      document.querySelector("#txtStock").value = objData.msg.stock;
                      document.querySelector("#imagen1").value = "0";
                      document.querySelector("#imagen2").value = "0";
                      document.querySelector("#imagen3").value = "0";
                      document.querySelector('#codigoBarras').innerHTML='<span></span>';
                      document.querySelector("#subimagenca").value= "";
            document.querySelector("#nom").value = "0";
            document.querySelector("#nom1").value = "0";
            document.querySelector("#subimagenca2").value= "";
            document.querySelector("#nom2").value = "0";
            document.querySelector("#nom3").value = "0";
            document.querySelector("#subimagenca3").value= "";
            document.querySelector("#nom4").value = "0";
            document.querySelector("#nom5").value = "0";
                      mostrar(objData.msg.descripcion);
                      
                      var boton = '<span></span>';
                      document.querySelector("#i").innerHTML=boton; 
                      var imagen = '<label>Imagen(1200x1486)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg">';
                      document.querySelector(".imag").innerHTML=imagen;
                      document.querySelector(".imag2").innerHTML=imagen;
                      document.querySelector(".imag3").innerHTML=imagen; 
                       
                      var a = objData.msg.imagen1;
                      let b = objData.msg.imagen11;
                      var a2 = objData.msg.imagen2;
                      let b2 = objData.msg.imagen22;
                      var a3 = objData.msg.imagen3;
                      let b3 = objData.msg.imagen33;
                      
                      if(a != null){
                      var imagen = '<label >Imagen '+b+'</label><br><img src="'+a+'" style="width: 80%"><br>';         
                          document.querySelector(".imag").innerHTML=imagen;
                          document.querySelector(".ima").innerHTML='<input type="checkbox" onclick="valor1()" id="valorima" name="valorima">  Ninguna imagen';
                          document.querySelector("#nom").value = a;
                           document.querySelector("#nom1").value = b;
                        }else{
                       var imagen = '<label>Imagen(1200x1486)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg"><br> ';         
                          document.querySelector(".imag").innerHTML=imagen; 
                          document.querySelector(".ima").innerHTML='';
                          document.querySelector("#nom").value = '';
                           document.querySelector("#nom1").value = '';
                      }
                      if(a2 != null){
                      var imagen = '<label >Imagen '+b2+'</label><br><img src="'+a2+'" style="width: 80%"><br>';         
                          document.querySelector(".imag2").innerHTML=imagen;
                          document.querySelector(".ima2").innerHTML='<input type="checkbox" onclick="valor2()" id="valorima" name="valorima">  Ninguna imagen';
                          document.querySelector("#nom2").value = a2;
                           document.querySelector("#nom3").value = b2;
                        }else{
                       var imagen = '<label>Imagen(1200x1486)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg"><br> ';         
                          document.querySelector(".imag2").innerHTML=imagen; 
                          document.querySelector(".ima2").innerHTML='';
                          document.querySelector("#nom2").value = '';
                           document.querySelector("#nom3").value = '';
                      }
                      if(a3 != null){
                      var imagen = '<label >Imagen '+b3+'</label><br><img src="'+a3+'" style="width: 80%"><br>';         
                          document.querySelector(".imag3").innerHTML=imagen;
                          document.querySelector(".ima3").innerHTML='<input type="checkbox" onclick="valor3()" id="valorima" name="valorima">  Ninguna imagen';
                          document.querySelector("#nom4").value = a3;
                           document.querySelector("#nom5").value = b3;
                        }else{
                       var imagen = '<label>Imagen(1200x1486)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg"><br> ';         
                          document.querySelector(".imag3").innerHTML=imagen; 
                          document.querySelector(".ima3").innerHTML='';
                          document.querySelector("#nom4").value = '';
                           document.querySelector("#nom5").value = '';
                      }
                      
                     $('#modalFormProductos').modal('show');
                    }else{
                        swal("Error",objData.msg,"error");
                    }
                }
            }
         })})       
}

$(document).ready(function(){
    setTimeout(() => { 
  fntEditProducto();
  ftnDelProductos();
   }, 500);
})

function valor1(){
    var valor = document.querySelector("#imagen1").value;
    if(valor == 1){
      document.querySelector("#imagen1").value = "0";
      
    }else if(valor == 0){
      document.querySelector("#imagen1").value = "1";  
   }   }
   
function valor2(){
    var valor = document.querySelector("#imagen2").value;
    if(valor == 1){
      document.querySelector("#imagen2").value = "0";
      
    }else if(valor == 0){
      document.querySelector("#imagen2").value = "1";  
   }}
   
 function valor3(){
    var valor = document.querySelector("#imagen3").value;
    if(valor == 1){
      document.querySelector("#imagen3").value = "0";
      
    }else if(valor == 0){
      document.querySelector("#imagen3").value = "1";  
   }}
   
  function ftnDelProductos(){
                var btnDelCategoria = document.querySelectorAll(".btnDeProducto");
                btnDelCategoria.forEach(function(btnDelCategoria){
                    btnDelCategoria.addEventListener('click',function(){
                       var idrol = this.getAttribute("rl");
                       swal({
                       title: "Eliminar Producto",
                       text: "¿Esta seguro de querer Eliminar el Producto?",
                       type: "warning",
                       showCancelButton: true,
                       confirmButtonText: "Si, eliminar!",
                       cancelButtonText: "No, cancelar!",
                       closeOnConfirm: false,
                       closedOnCancel:true
                       },function(isConfirm){
                       if(isConfirm){
                        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
                        var ajaxUrl = base_url+'Productos/DelProductos';
                        var strData = "subidCa="+idrol;
                        request.open("POST",ajaxUrl,true);
                        request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                        request.send(strData);
                        request.onreadystatechange = function(){
                        if(request.readyState == 4 && request.status == 200){
                        var objData = JSON.parse(request.responseText);
                         if(objData.status){
                             swal({
                                title: "Eliminar!",
                                text: objData.msg,
                                confirmButtonText: "Ok",
                             },function(Confirm){
                                if(Confirm){
                                    location.reload();
                                 }
                             });
                             
                         }else{
                             swal("Atencion!", objData.msg , "error");
                         }
                        }   
                        }
                       }
                       } );
                });
               });
            }
