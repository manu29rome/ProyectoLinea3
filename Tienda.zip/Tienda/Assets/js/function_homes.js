setTimeout(() => {
  fntEditCategoria();
  filtrar();
},1000);

 function fntEditCategoria(){
     var btnEditCategoria= document.querySelectorAll(".btnEditCategoria");
     btnEditCategoria.forEach(function(btnEditCategoria){
         btnEditCategoria.addEventListener('click',function(){       
             window.location = base_url+'tienda';   
             });});
        }

    $('.js-show-modal1').on('click',function(e){
        e.preventDefault();
        var idrol = this.getAttribute("rl");
        
        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Home/getProducto/'+idrol;
            request.open("GET",ajaxUrl,true);
            request.send();
            
            request.onreadystatechange = function(){
            if(request.readyState == 4 && request.status == 200){
                    var objData = JSON.parse(request.responseText);
                    if(objData.status){
                         document.querySelector("#titulo").innerHTML=""+objData.msg.producto;
                         document.querySelector("#idpro").value =""+objData.msg.idpro;
                         document.querySelector("#num-product").value = "1";
                         document.querySelector("#precio").innerHTML="COP  "+objData.msg.valor;
                         document.querySelector("#detalle").innerHTML=""+objData.msg.descripcion;
                         document.querySelector("#cantidad").innerHTML="UNDS DISPONIBLES: <br>"+objData.msg.stock+" paquetes";
                         document.querySelector("#imagenes").innerHTML=""+objData.msg.imagenes;
                         hacer();
                      $('.js-modal1').addClass('show-modal1');  
                      
                    }
              
                }
            }
           
       
    });
    
    function hacer(){
         $('.wrap-slick3').each(function(){
            $(this).find('.slick3').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                fade: true,
                infinite: true,
                autoplay: false,
                autoplaySpeed: 6000,

                arrows: true,
                appendArrows: $(this).find('.wrap-slick3-arrows'),
                prevArrow:'<button type="button" class="arrow-slick3 prev-slick3"><i class="fa fa-angle-left" aria-hidden="true"></i></button>',
                nextArrow:'<button type="button" class="arrow-slick3 next-slick3"><i class="fa fa-angle-right" aria-hidden="true"></i></button>',

                dots: true,
                appendDots: $(this).find('.wrap-slick3-dots'),
                dotsClass:'slick3-dots',
                customPaging: function(slick, index) {
                    var portrait = $(slick.$slides[index]).data('thumb');
                    return '<img src=" ' + portrait + ' "/><div class="slick3-dot-overlay"></div>';
                },  
            });
        });
    }

    $('.js-hide-modal1').on('click',function(){
        $('.js-modal1').removeClass('show-modal1');
    });
    
function filtrar(){
   var btnEditCategoria= document.querySelectorAll(".filtro");
     btnEditCategoria.forEach(function(btnEditCategoria){
         btnEditCategoria.addEventListener('click',function(){
            var idrol = this.getAttribute("rl"); 
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'ProductoBuscar/getProducto/'+idrol;
            request.open("GET",ajaxUrl,true);
            request.send();
            
             request.onreadystatechange = function(){
            if(request.readyState == 4 && request.status == 200){
                    var objData = JSON.parse(request.responseText);
                    if(objData.status){
                         document.querySelector("#productos").innerHTML=""+objData.msg.productos;
                      
                    }else{
                      swal("Error",objData.msg,"error");  
                    }
                }
            }
            
            
             });});
}

