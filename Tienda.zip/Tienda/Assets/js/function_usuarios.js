var tableUsuarios;
document.addEventListener('DOMContentLoaded',function(){
tableUsuarios = $('#tableUsuario').dataTable({
    "aProcesing":true,
    "aServerSde":true,
    "language":{
        "url":"//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
    },
    "ajax":{
        "url":""+base_url+"Usuarios/getUsuarios",
        "dataSrc":""
        
    },
    "columns":[
        {"data":"idus"},
        {"data":"identificacionus"},
        {"data":"nombreus"},
        {"data":"apellidous"},
        {"data":"roles"},
        {"data":"status"},
        {"data":"options"}
    ],
    "resonsive":"true",
    "bDestroy":true,
    "iDisplayLength":9999999999999999999999999999999,
    "order":[[0,"desc"]]
}); 

var formUsuario = document.querySelector("#formUsuario");
formUsuario.onsubmit = function(e){
   e.preventDefault(); 
   var intidUsuario = document.querySelector('#idUsuario').value;
   var strNombre = document.querySelector("#txtNombre").value;
   var intIdentificacion = document.querySelector("#txtIdentificacion").value;
   var strApellido= document.querySelector("#txtApellido").value;
   var intTelefono = document.querySelector("#txtTelefono").value;
   var strEmail = document.querySelector("#txtEmail").value;
   var intRolid = document.querySelector("#rol").value;
   var intStatus = document.querySelector("#ListStatus").value;
   var strPassword = document.querySelector("#txtPassword").value;
   if(strNombre == '' || intIdentificacion == ''|| strApellido == '' || intTelefono == '' || strEmail == '' || strPassword == '' || intRolid == '' || intStatus == ''){
       swal("Atencion","Todos los campos son obligatorios","error");
       return false;
   }
   var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Usuarios/setUsuario';
   var formDatos = new FormData(formUsuario);
   request.open("POST",ajaxUrl,true);
   request.send(formDatos);
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
           $('#formUsuario').modal("hide");
            formUsuario.reset();
           swal({
            title: "Usuario",
            text: objData.msg,
            confirmButtonText: "Ok",
         },function(Confirm){
            if(Confirm){
                location.reload();
             }
         });
           }else{
               swal("Error", objData.msg, "error");
           }
          $('#tableUsuario').DataTable();
  

           
}}}

});
$('#tableUsuario').DataTable();

function openModal(){
    document.querySelector("#idUsuario").value = "";
    document.querySelector(".modal-header").className.replace("headerUpdate","headerRegistro");
    document.querySelector("#btnActionForm").className.replace("tn-info","btn-primary");
    document.querySelector("#btnText").innerHTML = "Guardar";
    document.querySelector("#titleModal").innerHTML = "Nuevo Usuario";
    document.querySelector("#formUsuario").reset();
    $('#modalFormUsuario').modal('show');
    
}

function fntEditUsuario(){    
     var btnEditUsuario = document.querySelectorAll(".btnEditUsuario");
     btnEditUsuario.forEach(function(btnEditUsuario){
         btnEditUsuario.addEventListener('click',function(){
    document.querySelector("#idUsuario").value = "";
    document.querySelector(".modal-header").className.replace("headerUpdate","headerRegistro");
    document.querySelector("#btnActionForm").className.replace("btn-primary","tn-info");
    document.querySelector("#btnText").innerHTML = "Actualizar";
    document.querySelector("#titleModal").innerHTML = "Actualizar Usuario";
    document.querySelector("#formUsuario").reset();
            var idusuario = this.getAttribute("rl");
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Usuarios/getUsuario/'+idusuario;
            request.open("GET",ajaxUrl,true);
            request.send();
            
            request.onreadystatechange = function(){
                if(request.readyState == 4 && request.status == 200){
                    var objData = JSON.parse(request.responseText);
                    if(objData.status){
                      document.querySelector("#idUsuario").value = objData.msg.idus;
                      document.querySelector("#txtNombre").value = objData.msg.nombreus;
                      document.querySelector("#txtApellido").value = objData.msg.apellidous;
                      document.querySelector("#txtEmail").value = objData.msg.email;
                      document.querySelector("#txtTelefono").value = objData.msg.telefono;
                      document.querySelector("#rol").value = objData.msg.rolid;
                      document.querySelector("#txtPassword").value = objData.msg.contra;
                      document.querySelector("#ListStatus").value = objData.msg.status;
                      document.querySelector("#txtIdentificacion").value = objData.msg.identificacionus;  

                       if(objData.msg.status == 1){
                          var optioSelect = '<option value="1" >Activo</option>\n\
                                           <option value="2"  >Inactivo</option>';
                          document.querySelector("#ListStatus").innerHTML=optioSelect;
                         }else{
                         var optioSelect = '<option value="2" >Inactivo</option>\n\
                                           <option value="1"  >Activo</option>';
                         document.querySelector("#ListStatus").innerHTML=optioSelect;
                         }
                        
                     $('#modalFormUsuario').modal('show');
                    }else{
                        swal("Error",objData.msg,"error");
                    }
                }
            } });});
        } 

 function ftnDelUsuario(){
                var btnDeUsuario = document.querySelectorAll(".btnDeUsuario");
                btnDeUsuario.forEach(function(btnDeUsuario){
                    btnDeUsuario.addEventListener('click',function(){
                       var idusuario = this.getAttribute("rl");
                       swal({
                       title: "Eliminar Usuario",
                       text: "¿Esta seguro de querer Eliminar el Usuario?",
                       type: "warning",
                       showCancelButton: true,
                       confirmButtonText: "Si, eliminar!",
                       cancelButtonText: "No, cancelar!",
                       closeOnConfirm: false,
                       closedOnCancel:true
                       },function(isConfirm){
                       if(isConfirm){
                        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
                        var ajaxUrl = base_url+'Usuarios/delUsuario';
                        var strData = "idUsuario="+idusuario;
                        request.open("POST",ajaxUrl,true);
                        request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                        request.send(strData);
                        request.onreadystatechange = function(){
                        if(request.readyState == 4 && request.status == 200){
                        var objData = JSON.parse(request.responseText);
                         if(objData.status){
                             swal({
                                title: "Eliminar!",
                                text: objData.msg,
                                confirmButtonText: "Ok",
                             },function(Confirm){
                                if(Confirm){
                                    location.reload();
                                 }
                             });
                             
                         }else{
                             swal("Atencion!", objData.msg , "error");
                         }
                        }   
                        }
                       }
                       } );
                });
               });
            }
            
function fntVerUsuario(){
     var btnVerUsuario = document.querySelectorAll(".btnVerUsuario");
     btnVerUsuario.forEach(function(btnVerUsuario){
         btnVerUsuario.addEventListener('click',function(){
            var idrol = this.getAttribute("rl");
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Usuarios/getUsuario/'+idrol;
            request.open("GET",ajaxUrl,true);
            request.send();  
            request.onreadystatechange = function(){
                if(request.readyState == 4 && request.status == 200){
                    var objData = JSON.parse(request.responseText);
                    if(objData.status){
                      document.querySelector("#idUsuario1").value = objData.msg.idus;
                      document.querySelector("#txtNombre1").value = objData.msg.nombreus;
                      document.querySelector("#txtApellido1").value = objData.msg.apellidous;
                      document.querySelector("#txtEmail1").value = objData.msg.email;
                      document.querySelector("#txtTelefono1").value = objData.msg.telefono;
                      document.querySelector("#rol1").value = objData.msg.rolid;
                      document.querySelector("#txtPassword1").value = objData.msg.contra;
                      document.querySelector("#txtIdentificacion1").value = objData.msg.identificacionus; 
                     buscarrol();
                       if(objData.msg.status == 1){
                         document.querySelector("#ListStatus1").value = "Activo";
                         }else{
                         document.querySelector("#ListStatus1").value = "Inactivo"; 
                         }
                        
                        
                     $('#modalFormUsuarioVer').modal('show');
                    }else{
                        swal("Error",objData.msg,"error");
                    }
                }
            } });});
        } 
 function buscarrol(){
    var intRol = document.querySelector("#rol1").value ; 
           var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Usuarios/getRol/'+intRol;
            request.open("GET",ajaxUrl,true);
            request.send();  
            request.onreadystatechange = function(){
                if(request.readyState == 4 && request.status == 200){
                    var objData = JSON.parse(request.responseText);
                    if(objData.status){
                      document.querySelector("#ListRolid1").value = objData.msg.nombrerol;  
                    }}}
}

$(document).ready(function(){
    setTimeout(() => { 
    fntEditUsuario();
    ftnDelUsuario();
    fntVerUsuario();
  }, 1000);
})

function solonumeros(evt){
 if(window.event){
     keynum = evt.keyCode;
 }else{
     keynum = evt.which;
 }if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13){
     return true;
 }else{
      swal({
            title: "¡Advertencia!",
            text: "Ingrese solo numeros",
            confirmButtonText: "Ok",
         });
 }
     
}
function sololetras(e){
   key = e.keyCode || e.which;
   tecla = String.fromCharCode(key).toString();
   letras= "ABCDEFGHIJKLMNÑOPQRSOPQTWXYZabcdefghijklmñnopqrstuvwxyzáéíóú";
   especiales = [8,13];
   tecla_especial = false
   for(var i in especiales){
       if(key == especiales[i]){
         tecla_especial = true;
         break;
       }
   }
   if(letras.indexOf(tecla)== -1 && !tecla_especial){
      swal({
            title: "Nombre y/o Apellido",
            text: "Ingrese solo letras",
            confirmButtonText: "Ok",
         }); 
         return false;
   }
       
}


