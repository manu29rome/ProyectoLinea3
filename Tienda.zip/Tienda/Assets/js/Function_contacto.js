var formReset = document.querySelector("#mensaje");
formReset.onsubmit = function(o){
   o.preventDefault(); 
   let strEmail = document.querySelector("#email").value;
   let strsolicitud = document.querySelector("#msg").value;
    if(strEmail == "" || strsolicitud == ""){
        swal("Por favor","No deje Espacion en Blanco","error");
        return false;  
    }else{
   var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Contacto/Mensaje';
   var formData = new FormData(formReset);
   request.open("POST",ajaxUrl,true);
   request.send(formData);
   
   request.onreadystatechange = function(){
   if(request.readyState != 4)return;
   if(request.status == 200){
       var objData = JSON.parse(request.responseText);
       if(objData.status){
            swal("Atencion",objData.msg,"success"); 
            document.querySelector("#email").value = "";
           document.querySelector("#msg").value = "";
       }else{
           swal("Atencion",objData.msg, "error");
           
       }
   }else{
       swal("Atencion","Error en el proceso","error")
   }
   }
    }
}

