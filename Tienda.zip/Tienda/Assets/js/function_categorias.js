var tableRoles;
document.addEventListener('DOMContentLoaded',function(){
tablaRoles = $('#tableCategorias').dataTable({
    "aProcesing":true,
    "aServerSde":true,
    "language":{
        "url":"//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
    },
    "ajax":{
        "url":""+base_url+"Categorias/setCategorias",
        "dataSrc":""
    },
    "columns":[
        {"data":"idca"},
        {"data":"categoria"},
        {"data":"descripcionca"},
        {"data":"status"},
        {"data":"imagen"},
        {"data":"options"}
    ],
    "resonsive":"true",
    "bDestroy":true,
    "iDisplayLength":9999999999999999999999999999999,
    "order":[[0,"desc"]]
});  
var formRol = document.querySelector("#formCategorias");
formRol.onsubmit = function(e){
   e.preventDefault(); 
   var intIdRol = document.querySelector('#idCa').value;
   var strNombre = document.querySelector("#txtNombreca").value;
   var strDescripcion = document.querySelector("#txtDescripcionca").value;
   var intStatus = document.querySelector("#listStatusca").value;
   if(strNombre == '' || strDescripcion == ''|| intStatus == ''){
       swal("Atencion","Todos los campos son obligatorios","error");
       return false;
   }else{
   var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Categorias/getCategorias';
   var formData = new FormData(formRol);
   request.open("POST",ajaxUrl,true);
   request.send(formData);
  
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
           $('#modalFormCategorias').modal("hide");
            
           swal({
            title: "Roles de usuario",
            text: objData.msg,
            confirmButtonText: "Ok",
         },function(Confirm){
            if(Confirm){
                location.reload();
             }
         });
           
           }else{
               swal("Error", objData.msg, "error");
           }     
}} }}

});
function openModal(){
    document.querySelector('#idCa').value="";
    document.querySelector('#titleModal').innerHTML="Nueva Categoria";
    document.querySelector('#btnText').innerHTML="Guardar";
    document.querySelector('.modal-header').classList.replace("headerUpdate","headerResgister")
    document.querySelector('#btnActionForm').classList.replace("btn-info","btn-primary");
    document.querySelector('#idCama').value = "";
    document.querySelector("#txtNombreca").value = "";
    document.querySelector("#txtDescripcionca").value = "";
    document.querySelector("#imagenca").value = "";
    var imagen = '<label>Foto(809x1200)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg">';         
   document.querySelector(".imag").innerHTML=imagen;
    $('#modalFormCategorias').modal('show');
     var imagenes = '';         
   document.querySelector(".ima").innerHTML=imagenes;
    document.querySelector("#nom").value = "0";
    document.querySelector("#nom1").value = "0";
}

$(document).on("click",".imag",function(){
   $("#imagenca").click(); 
})

$(document).on("change","#imagenca",function(){
   var file = this.files;
   var element;
   var supporteimagenes=["image/jpeg","image/png","image/gif"];
   var seencontrarolElemteos = false;
   for(var i = 0;i < file.length; i++){
       element = file[i];
       if(supporteimagenes.indexOf(element.type) != -1){
         create(element);  
       }
   }
       
   function no(){
   var imagenes = '';         
   document.querySelector(".ima").innerHTML=imagenes;
   document.querySelector("#boton").innerHTML='';
   document.querySelector("#imagenca").value= "";
   let total = document.querySelector("#nom").value;
   
   if(total == 0){
      var imagen = '<label>Imagen(809x1200)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg">';         
   document.querySelector(".imag").innerHTML=imagen;  
   }else{
       let nombre = document.querySelector("#nom1").value;
     var imagen = '<label>Imagen '+nombre+'</label><br><img style=" width: 80%" src="'+total+'">';   
      document.querySelector(".ima").innerHTML='<input type="checkbox" onclick="valor()" id="valorima" name="valorima">  Ninguna imagen';
   document.querySelector(".imag").innerHTML=imagen;     
   }
}
})



function create(file){
    var imgCodified = URL.createObjectURL(file);
    var valor = document.querySelector("#idCama").value;
    if(valor == 0){
    var imagenes = '<br><img style="width: 80%;" src="'+imgCodified+'">';         
   document.querySelector(".imag").innerHTML=imagenes;
     document.querySelector("#boton").innerHTML='<button type="button" onclick="no()" style="background-color: transparent;border: none">X</button>';
}else{
    var imagenes = '<br><img style="width: 80%;" src="'+imgCodified+'">';         
   document.querySelector(".imag").innerHTML=imagenes;
     document.querySelector("#boton").innerHTML='<button type="button" onclick="no()" style="background-color: transparent;border: none">X</button>';
}

}

 function fntEditCategoria(){
     var btnEditCategoria= document.querySelectorAll(".btnEditCategoria");
     btnEditCategoria.forEach(function(btnEditCategoria){
         btnEditCategoria.addEventListener('click',function(){
            document.querySelector('#titleModal').innerHTML="Actualizar Categoria";
            document.querySelector('#btnText').innerHTML="Actualizar";
            document.querySelector('.modal-header').classList.replace("headerResgister","headerUpdate");
            document.querySelector('#btnActionForm').classList.replace("btn-primary","btn-info");
            document.querySelector("#imagenca").value= "";
            document.querySelector("#nom").value = "0";
            document.querySelector("#nom1").value = "0";
            var idrol = this.getAttribute("rl");
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'Categorias/getCategoria/'+idrol;
            request.open("GET",ajaxUrl,true);
            request.send();
            request.onreadystatechange = function(){
                if(request.readyState == 4 && request.status == 200){
                    var objData = JSON.parse(request.responseText);
                    if(objData.status){
                      document.querySelector("#idCa").value = objData.msg.idca;
                      document.querySelector("#txtNombreca").value = objData.msg.categoria;
                      document.querySelector("#txtDescripcionca").value = objData.msg.descripcionca;
                      document.querySelector("#listStatusca").value = objData.msg.status;
                      document.querySelector("#foto").value = objData.msg.imagenes;
                     let  a = objData.msg.imagen;
                      let b = objData.msg.imagenes;
                      
                      if(a != "Assets/Images/Categorias/"){
                      var imagen = '<label >Imagen '+b+'</label><br><img src="'+a+'" style="width: 80%"><br>';         
                          document.querySelector(".imag").innerHTML=imagen;
                          document.querySelector(".ima").innerHTML='<input type="checkbox" onclick="valor()" id="valorima" name="valorima">  Ninguna imagen';
                          document.querySelector("#nom").value = objData.msg.imagen;
                           document.querySelector("#nom1").value = b;
                        }else{
                       var imagen = '<label>Imagen(809x1200)</label><br><img style=" width: 80%" src="Assets/Images/Categorias/Implementos/camara.jpg"><br> ';         
                          document.querySelector(".imag").innerHTML=imagen; 
                          document.querySelector(".ima").innerHTML='';
                          document.querySelector("#nom").value = "0";
                          document.querySelector("#nom1").value = "0";
                        }
                     $('#modalFormCategorias').modal('show');
                    }else{
                        swal("Error",objData.msg,"error");
                    }
                }
            } });});
        }
$(document).ready(function(){
    setTimeout(() => { 
  fntEditCategoria();
  ftnDelCategoria();
}, 500);
})

function valor(){
    var valor = document.querySelector("#idCama").value;
    if(valor == 1){
      document.querySelector("#idCama").value = "0";
      
    }else if(valor == 0){
      document.querySelector("#idCama").value = "1";  
      
    }
}

  function ftnDelCategoria(){
                var btnDelCategoria = document.querySelectorAll(".btnDeCategoria");
                btnDelCategoria.forEach(function(btnDelCategoria){
                    btnDelCategoria.addEventListener('click',function(){
                       var idrol = this.getAttribute("rl");
                       swal({
                       title: "Eliminar Categoria",
                       text: "¿Esta seguro de querer Eliminar la Categoria?",
                       type: "warning",
                       showCancelButton: true,
                       confirmButtonText: "Si, eliminar!",
                       cancelButtonText: "No, cancelar!",
                       closeOnConfirm: false,
                       closedOnCancel:true
                       },function(isConfirm){
                       if(isConfirm){
                        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
                        var ajaxUrl = base_url+'Categorias/DelCategoria';
                        var strData = "idCa="+idrol;
                        request.open("POST",ajaxUrl,true);
                        request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                        request.send(strData);
                        request.onreadystatechange = function(){
                        if(request.readyState == 4 && request.status == 200){
                        var objData = JSON.parse(request.responseText);
                         if(objData.status){
                             swal({
                                title: "Eliminar!",
                                text: objData.msg,
                                confirmButtonText: "Ok",
                             },function(Confirm){
                                if(Confirm){
                                    location.reload();
                                 }
                             });
                             
                         }else{
                             swal("Atencion!", objData.msg , "error");
                         }
                        }   
                        }
                       }
                       } );
                });
               });
            }



