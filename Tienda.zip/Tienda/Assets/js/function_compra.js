ddocument.addEventListener('DOMContentLoaded',function(){
mun();    
});

function comprar(){
    
                        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
                        var ajaxUrl = base_url+'Compra/getComprar';
                        request.open("POST",ajaxUrl,true);
                        request.send();  
                        request.onreadystatechange = function(){
                        if(request.readyState == 4 && request.status == 200){
                        var objData = JSON.parse(request.responseText);
                         if(objData.status){
                                    location.reload();
                             
                         }else{
                             swal("Atencion!", objData.msg , "error");
                         }
                        }   
                        }
                       
                       
}
function mun(){
   var formc = document.querySelector(".muni");
   
    var request =(window.XMLHttpRequest) ? new XMLHttpRequest() :ActiveXObject('Microsoft.XMLHTTP');
   var ajaxUrl = base_url+'Compra/getciudad';
   var formData = new FormData(formc);
   request.open("POST",ajaxUrl,true);
   request.send(formData);
   request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
        var objData = JSON.parse(request.responseText);
        if(objData.status){
           document.querySelector("#n").innerHTML=objData.msg.p;
           }else{
               swal("Error", objData.msg, "error");
           }     
}}
}

function ftnDelProductos(){
                var btnDelCategoria = document.querySelectorAll(".btnDeProducto");
                btnDelCategoria.forEach(function(btnDelCategoria){
                    btnDelCategoria.addEventListener('click',function(){
                       var idrol = this.getAttribute("rl");
                       swal({
                       title: "Eliminar Producto",
                       text: "¿Esta seguro de querer Eliminar el Producto?",
                       type: "warning",
                       showCancelButton: true,
                       confirmButtonText: "Si, eliminar!",
                       cancelButtonText: "No, cancelar!",
                       closeOnConfirm: false,
                       closedOnCancel:true
                       },function(isConfirm){
                       if(isConfirm){
                        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
                        var ajaxUrl = base_url+'Productos/DelProductos';
                        var strData = "subidCa="+idrol;
                        request.open("POST",ajaxUrl,true);
                        request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                        request.send(strData);
                        request.onreadystatechange = function(){
                        if(request.readyState == 4 && request.status == 200){
                        var objData = JSON.parse(request.responseText);
                         if(objData.status){
                             swal({
                                title: "Eliminar!",
                                text: objData.msg,
                                confirmButtonText: "Ok",
                             },function(Confirm){
                                if(Confirm){
                                    location.reload();
                                 }
                             });
                             
                         }else{
                             swal("Atencion!", objData.msg , "error");
                         }
                        }   
                        }
                       }
                       } );
                });
               });
            }